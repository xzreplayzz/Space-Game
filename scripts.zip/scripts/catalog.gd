extends RefCounted

const Landscape=preload("res://scripts/landscape.gd")

const JOBS = ["extractors", "abductors", "gunners", "engineers", "navigators"]
const JOB_NAMES = ["EXTRACTORS", "ABDUCTORS", "GUNNERS", "ENGINEERS", "NAVIGATORS"]
const BIOMES = [
 {"name":"PELAGIC", "land":Color("64765c"), "low":Color("153f52"), "high":Color("c7c8a2"), "air":Color("438da4"), "ocean":0.50},
 {"name":"FERRIC", "land":Color("a55e3d"), "low":Color("352e34"), "high":Color("d7ad76"), "air":Color("a76c48"), "ocean":0.29},
 {"name":"CRYOGENIC", "land":Color("8babb0"), "low":Color("254658"), "high":Color("e1e6d6"), "air":Color("76a6b8"), "ocean":0.39},
 {"name":"VOLCANIC", "land":Color("4d4745"), "low":Color("7c2515"), "high":Color("887060"), "air":Color("995a43"), "ocean":0.33},
 {"name":"SULPHUR", "land":Color("afa16b"), "low":Color("435a43"), "high":Color("d3c8a0"), "air":Color("8a935c"), "ocean":0.36},
 {"name":"OBSIDIAN", "land":Color("4b4962"), "low":Color("242d43"), "high":Color("b8a8aa"), "air":Color("736b9a"), "ocean":0.31}
]

const UPGRADES = [
 {"id":"drill", "name":"RESONANCE DRILLS", "tag":"EXTRACTION", "description":"Extraction output ×1.45. Your crews fracture deposits with tuned seismic pulses.", "stat":"45% MORE EXTRACTION", "color":"79c5b5"},
 {"id":"abduct", "name":"FOLDSPACE ARKS", "tag":"POPULATION", "description":"Abduction output ×1.6. Compression chambers carry entire population groups.", "stat":"60% MORE CAPTURES", "color":"b4a0d3"},
 {"id":"turret", "name":"SENTINEL ARRAY", "tag":"DEFENCE", "description":"Interceptor fire cycles accelerate with each level. Onboard gunners determine the firing rate.", "stat":"FASTER INTERCEPTORS", "color":"dfae6f"},
 {"id":"hull", "name":"LAMINATED BULWARK", "tag":"SURVIVAL", "description":"Maximum hull +40. Repairs 40 hull immediately.", "stat":"+40 MAXIMUM HULL", "color":"dfae6f"},
 {"id":"shuttle", "name":"VECTOR COURIERS", "tag":"LOGISTICS", "description":"Deployment and recall travel time ×0.7. Recover exposed crews sooner.", "stat":"30% FASTER TRANSIT", "color":"79c5b5"},
 {"id":"cloak", "name":"SIGNATURE BAFFLES", "tag":"STEALTH", "description":"Extraction detection chance ×0.72. Civilisations still report an attack immediately.", "stat":"28% LESS DETECTION", "color":"b4a0d3"},
 {"id":"core", "name":"DEEP CRUST RIG", "tag":"EXTRACTION", "description":"Excavation radius +13%. Level III with Planetbreaker III lets deep bores open crustal faults.", "stat":"13% WIDER EXCAVATIONS", "color":"dfae6f"},
 {"id":"cargo", "name":"MATTER REFINERY", "tag":"ECONOMY", "description":"Resource sale value ×1.35. Valuable cargo funds more upgrades and repairs.", "stat":"35% MORE SALE VALUE", "color":"79c5b5"},
 {"id":"link", "name":"SYNAPTIC RELAY", "tag":"COMMAND", "description":"Extraction and abduction ×1.2. Deployed engineers provide twice their usual support.", "stat":"20% MORE CREW OUTPUT", "color":"b4a0d3"},
 {"id":"repair", "name":"LIVING ALLOY", "tag":"ENGINEERING", "description":"Onboard engineers repair hull three times faster, even during combat.", "stat":"×3 REPAIR OUTPUT", "color":"79c5b5"},
 {"id":"thruster", "name":"SLIPSTREAM DRIVE", "tag":"FLIGHT", "description":"Orbital movement and boost speed +30%. Reposition and evade incoming fire.", "stat":"30% MORE FLIGHT SPEED", "color":"dfae6f"},
 {"id":"bore", "name":"PLANETBREAKER", "tag":"DESTRUCTION", "description":"Excavation radius +22%; crew output +15%. Destabilise eight deep crustal sectors to fragment a world.", "stat":"22% WIDER EXCAVATIONS", "color":"dfae6f"}
]

static func system_name(rng: RandomNumberGenerator) -> String:
 var starts = ["Vael", "Orr", "Khe", "Tal", "Ish", "Neme", "Syr", "Astra", "Ul", "Dra", "Cer", "Xan", "Ere", "Mor"]
 var ends = ["ara", "ion", "eth", "os", "une", "adis", "esh", "orum", "eia", "ak", "ilis", "oa"]
 return starts[rng.randi_range(0, starts.size()-1)] + ends[rng.randi_range(0,ends.size()-1)]

static func system_identity(rng: RandomNumberGenerator, depth: int) -> Dictionary:
 var count=rng.randi_range(3,6)
 if depth>0 and rng.randf()<0.055: count=1
 return {"name":system_name(rng),"count":count}

static func generate_system(seed_number: int, depth: int, first_profile=-1) -> Dictionary:
 var rng=RandomNumberGenerator.new()
 rng.seed=seed_number
 var identity=system_identity(rng,depth)
 var count=identity.count
 var result={"name":identity.name,"seed":seed_number,"count":count,"planets":[],"depth":depth,"star_color":Color("ffd8a0") if rng.randf()<0.7 else Color("b9daef"),"star_radius":29000.0,"alert":{},"time":0.0}
 var profiles=[0,1,2,3,4,5]
 for j in range(profiles.size()-1,0,-1):
  var k=rng.randi_range(0,j)
  var swap=profiles[j];profiles[j]=profiles[k];profiles[k]=swap
 if first_profile in profiles:
  profiles.erase(first_profile);profiles.push_front(first_profile)
 for i in count:
  var biome=profiles[i]
  var inhabited=rng.randf()<0.20
  if depth==0 and i==0: inhabited=false
  var distribution={}
  var weight_sum=0.0
  for job in JOBS:
   distribution[job]=pow(rng.randf_range(0.08,1.0),rng.randf_range(1.0,5.0))
   weight_sum+=distribution[job]
  var top_job=JOBS[0]
  for job in JOBS:
   distribution[job]/=weight_sum
   if distribution[job]>distribution[top_job]: top_job=job
  var body={"seed":rng.randi(),"name":system_name(rng)+" "+["I","II","III","IV","V","VI"][i],"biome":biome,"radius":rng.randf_range(10000,18500),"relief":rng.randf_range(180,850),"rings":rng.randf()<0.28,"moons":rng.randi_range(0,2),"inhabited":inhabited,"population":rng.randi_range(6000,90000) if inhabited else 0,"species":system_name(rng)+"i","skills":distribution,"top_job":top_job,"risk":clampi(1+int(count/3)+int(depth/4)+(1 if inhabited else 0),1,5),"integrity":1.0,"visited":false,"edits":[],"deposits":[],"features":[],"hotspots":[],"removed_volume":0.0,"ore_recovered":0.0,"fractured":false,"orbit_radius":95000.0+i*85000.0+rng.randf_range(-8000,8000),"orbit_phase":float(i)*2.27+0.1,"orbit_speed":rng.randf_range(0.003,0.009)/sqrt(i+1.0),"orbit_tilt":rng.randf_range(-0.15,0.15),"ground_color":BIOMES[biome].land}
  var profile=Landscape.PROFILES[biome]
  body.radius*=[1.0,0.67,1.23,0.82,1.10,0.74][i]
  body["landscape"]=biome
  body["terrain_revision"]=4
  body["landscape_name"]=profile.name
  body["landscape_scale"]=rng.randf_range(0.88,1.16)
  body["landscape_relief"]=rng.randf_range(0.88,1.14)
  body["landscape_yaw"]=rng.randf_range(-0.18,0.18)
  body["ground_color"]=profile.soil
  body["air_color"]=profile.air
  body["atmosphere_density"]=[0.7,0.42,0.65,0.35,0.8,0.32][biome]
  var geology=preload("res://scripts/geology.gd").new(body)
  for f in 13:
   var normal=Vector3.UP
   if f<6:
    var offset=Vector3(0,0,0) if f==0 else Vector3(cos(f*1.71),0,sin(f*1.71))*float(f)*170.0
    normal=(Vector3.UP*body.radius+offset).normalized()
   else: normal=Vector3(rng.randfn(),rng.randfn(),rng.randfn()).normalized()
   var ground=geology.surface(normal)
   var tangent=normal.cross(Vector3.FORWARD).normalized()
   if tangent.length_squared()<0.1: tangent=Vector3.RIGHT
   var material=3 if f%4==3 else 2
   var width=rng.randf_range(14,25)
   var centers=[]
   for segment in 3:
    centers.append(ground-normal*(width+4.0)+tangent*(segment-1)*width*1.1)
   var deposit={"name":system_name(rng)+[" Crown"," Reach"," Hollow"," Scar"," Ridge"," Basin"][f%6],"material":material,"width":width,"centers":centers,"surface":ground,"normal":normal}
   body.deposits.append(deposit)
   body.features.append({"name":deposit.name,"type":"Cobalt pocket" if material==3 else "Ferrite seam","kind":"mineral","position":ground,"normal":normal,"material":material,"scanned":false})
  if inhabited:
   for city in 3:
    var normal=(Vector3.UP*body.radius+Vector3(330+city*400,0,-150-city*100)).normalized()
    body.features.append({"name":system_name(rng)+[" Anchorage"," City"," Enclave"][city],"type":"City" if city==1 else "Settlement","kind":"city","position":geology.surface(normal),"normal":normal,"radius":100.0+city*30,"scanned":false,"population":int(body.population/3)})
  result.planets.append(body)
 return result

static func upgrade_offer(rng: RandomNumberGenerator, levels: Dictionary) -> Array:
 var candidates = []
 for item in UPGRADES:
  candidates.append(item.duplicate())
 var choices = []
 for i in 3:
  var pick = rng.randi_range(0,candidates.size()-1)
  choices.append(candidates[pick])
  candidates.remove_at(pick)
 return choices
