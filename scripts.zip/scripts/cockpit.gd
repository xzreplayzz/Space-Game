extends Node3D
var game
var monitors=[]

func _ready():
 var shell=_metal(Color("171e23"),0.45)
 var bevel=_metal(Color("39454b"),0.7)
 var trim=_metal(Color("667071"),0.65)
 var rubber=_metal(Color("0b1013"),0.1)
 var light=_metal(Color("83b7b5"),0.2,true)
 # Swept, tapered canopy rails stay outside the aiming and survey area.
 var rail=[Vector2(-100,-90),Vector2(60,52),Vector2(180,177),Vector2(261,326),Vector2(313,509),Vector2(345,686),Vector2(365,754)]
 for side in [0,1]:
  for i in range(rail.size()-1):
   var a=rail[i];var b=rail[i+1]
   if side==1: a.x=1600-a.x;b.x=1600-b.x
   _strut(_p(a,1.55),_p(b,1.55),0.018+i*0.0015,shell,8)
   _strut(_p(a+Vector2(-5 if side==0 else 5,0),1.526),_p(b+Vector2(-5 if side==0 else 5,0),1.526),0.0034,bevel,6)
  # Sidewall ribs, padded sill and the inset ventilation grilles.
  var poly=[Vector2(-70,745),Vector2(125,666),Vector2(331,718),Vector2(393,925),Vector2(-70,925)]
  if side==1:
   for j in poly.size(): poly[j].x=1600-poly[j].x
  _plate(poly,1.50,0.095,shell,bevel)
  var start=Vector2(0 if side==0 else 1600,748)
  var finish=Vector2(330 if side==0 else 1270,728)
  _strut(_p(start,1.43),_p(finish,1.43),0.016,rubber,8)
  for j in 7:
   var x=80+j*19 if side==0 else 1520-j*19
   _strut(_p(Vector2(x,801),1.36),_p(Vector2(x+12,827),1.36),0.003,rubber,4)
 # Instrument coaming: angular but bevelled, with a clear central sightline.
 _plate([Vector2(304,742),Vector2(388,686),Vector2(629,704),Vector2(685,908),Vector2(258,908)],1.46,0.09,shell,bevel)
 _plate([Vector2(971,704),Vector2(1212,686),Vector2(1296,742),Vector2(1342,908),Vector2(915,908)],1.46,0.09,shell,bevel)
 _plate([Vector2(647,787),Vector2(700,754),Vector2(900,754),Vector2(953,787),Vector2(1014,930),Vector2(586,930)],1.36,0.1,shell,bevel)
 # Small inset displays are real emissive surfaces with their own render targets.
 _monitor([Vector2(353,745),Vector2(613,746),Vector2(645,856),Vector2(321,856)],1.397,"crew")
 _monitor([Vector2(987,746),Vector2(1247,745),Vector2(1279,856),Vector2(955,856)],1.397,"flight")
 _monitor([Vector2(697,798),Vector2(903,798),Vector2(929,887),Vector2(671,887)],1.297,"systems")
 for side in [0,1]:
  for j in 5:
   var x=365+j*48 if side==0 else 1235-j*48
   _plate([Vector2(x,870),Vector2(x+20,870),Vector2(x+20,879),Vector2(x,879)],1.37,0.005,light if j==0 else rubber,bevel)
  for x in ([333,626] if side==0 else [974,1267]):
   _strut(_p(Vector2(x,726),1.38),_p(Vector2(x,729),1.38),0.0035,trim,8)
 # Thin overhead edge only; no crossbar over the windscreen.
 _strut(_p(Vector2(80,-18),1.6),_p(Vector2(1520,-18),1.6),0.018,shell,8)

func _p(pixel: Vector2,depth: float) -> Vector3:
 var half=tan(deg_to_rad(70.0)*0.5)*depth
 return Vector3((pixel.x/800.0-1.0)*half*1600.0/900.0,(1-pixel.y/450.0)*half,-depth)

func _metal(color: Color,metal: float,emissive=false):
 var mat=StandardMaterial3D.new()
 mat.albedo_color=color;mat.metallic=metal;mat.roughness=0.55
 mat.cull_mode=BaseMaterial3D.CULL_DISABLED
 if emissive: mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
 return mat

func _strut(a: Vector3,b: Vector3,radius: float,mat,sides=8):
 var mesh=CylinderMesh.new();mesh.top_radius=radius;mesh.bottom_radius=radius;mesh.height=a.distance_to(b);mesh.radial_segments=sides;mesh.rings=1
 var node=MeshInstance3D.new();node.mesh=mesh;node.material_override=mat
 add_child(node);node.position=(a+b)*0.5
 node.quaternion=Quaternion(Vector3.UP,(b-a).normalized())
 node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 return node

func _plate(points: Array,depth: float,thickness: float,face_mat,edge_mat):
 var center=Vector2.ZERO
 for p in points: center+=p
 center/=points.size()
 var front=[];var back=[]
 for p in points:
  front.append(_p(p.lerp(center,0.023),depth))
  back.append(_p(p,depth+thickness))
 var front_tool=SurfaceTool.new();front_tool.begin(Mesh.PRIMITIVE_TRIANGLES)
 for i in range(1,points.size()-1):
  for p in [front[0],front[i],front[i+1]]: front_tool.add_vertex(p)
 front_tool.generate_normals()
 var node=MeshInstance3D.new();node.mesh=front_tool.commit();node.material_override=face_mat;add_child(node)
 var edge_tool=SurfaceTool.new();edge_tool.begin(Mesh.PRIMITIVE_TRIANGLES)
 for i in points.size():
  var j=(i+1)%points.size()
  for p in [front[i],back[i],back[j],front[i],back[j],front[j]]: edge_tool.add_vertex(p)
 edge_tool.generate_normals()
 var edge_node=MeshInstance3D.new();edge_node.mesh=edge_tool.commit();edge_node.material_override=edge_mat;add_child(edge_node)

func _monitor(points: Array,depth: float,kind: String):
 var viewport=SubViewport.new();viewport.size=Vector2i(640,256);viewport.transparent_bg=false
 viewport.render_target_update_mode=SubViewport.UPDATE_ALWAYS
 add_child(viewport)
 var display=preload("res://scripts/cockpit_display.gd").new();display.game=game;display.kind=kind;viewport.add_child(display)
 var material=StandardMaterial3D.new();material.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
 material.albedo_texture=viewport.get_texture();material.cull_mode=BaseMaterial3D.CULL_DISABLED
 material.texture_filter=BaseMaterial3D.TEXTURE_FILTER_LINEAR
 var tool=SurfaceTool.new();tool.begin(Mesh.PRIMITIVE_TRIANGLES)
 var uv=[Vector2(0,0),Vector2(1,0),Vector2(1,1),Vector2(0,1)]
 for index in [0,1,2,0,2,3]: tool.set_uv(uv[index]);tool.add_vertex(_p(points[index],depth))
 tool.generate_normals()
 var node=MeshInstance3D.new();node.mesh=tool.commit();node.material_override=material;add_child(node)
 monitors.append(display)
