extends Control

const PLEX=preload("res://assets/ui/PlexSans.ttf")
const CONDENSED=preload("res://assets/ui/PlexCondensed.ttf")
const NUMBERS=preload("res://assets/ui/PlexMono.ttf")
const PAPER=Color("fff1dc")
const QUIET=Color("cad3c7")
const AMBER=Color("ffc089")
const MINT=Color("b7e0ca")
const ALARM=Color("ff9e88")
const EDGE=Color("435955")
var game
var kind="crew"
var tick=0.0

func _ready():
 mouse_filter=MOUSE_FILTER_IGNORE

func _process(dt):
 tick+=dt
 if tick>0.10:
  tick=0.0
  queue_redraw()

func label(value,x: float,y: float,size: int,ink: Color,face=PLEX):
 var ui_scale: float=game.ui.text_scale if game.ui!=null else 1.0
 var actual=roundi(size*minf(ui_scale,1.18))
 var remaining=619.0-x
 while actual>22 and face.get_string_size(str(value),HORIZONTAL_ALIGNMENT_LEFT,-1,actual).x>remaining: actual-=1
 draw_string(face,Vector2(x,y),str(value),HORIZONTAL_ALIGNMENT_LEFT,-1,actual,ink)

func bar(y: float,ratio: float,ink: Color):
 draw_rect(Rect2(28,y,584,8),EDGE)
 draw_rect(Rect2(28,y,584*clampf(ratio,0.0,1.0),8),ink)

func _draw():
 draw_rect(Rect2(0,0,640,256),Color("101b1e"))
 draw_line(Vector2(27,65),Vector2(613,65),EDGE,3)
 if game==null or game.world==null: return
 if kind=="crew":
  var ratio=game.hull/maxf(1.0,game.max_hull)
  var status=ALARM if ratio<0.35 else MINT
  label("HULL",26,49,39,QUIET,CONDENSED)
  label("%d%%"%roundi(ratio*100.0),24,152,86,status,CONDENSED)
  bar(170,ratio,status)
  label("%d crew aboard"%[game.total_workers()-game.deployed_workers()],26,232,43,PAPER,CONDENSED)
 elif kind=="flight":
  var speed=game.world.ship_velocity.length()
  var altitude=maxf(0,game.world.volume.geology.base_sdf(game.world.ship_position)) if game.world.volume!=null else 0.0
  label("BOOST" if game.world.boost_active else "FLIGHT",26,49,39,AMBER if game.world.boost_active else QUIET,CONDENSED)
  label("%d"%roundi(speed),24,154,88,PAPER,CONDENSED)
  label("m/s",345,148,47,QUIET,CONDENSED)
  label("%.1f km altitude"%(altitude/1000.0) if altitude>=1000 else "%d m altitude"%roundi(altitude),26,231,44,MINT,CONDENSED)
 else:
  var op=game.operation_for(game.selected)
  if op!=null and op.state=="complete": op=null
  if op==null:
   for candidate in game.operations:
    if candidate.state!="complete": op=candidate;break
  if op==null:
   label("FIELD SYSTEMS",26,49,39,QUIET,CONDENSED)
   label("Standby",25,148,78,PAPER,CONDENSED)
   label("%.1f cargo aboard"%game.cargo,28,231,44,MINT,CONDENSED)
   return
  var mining: bool=op.crew.extractors>0
  var heading="EXTRACTION" if mining else ("ABDUCTION" if op.crew.abductors>0 else "FIELD CREW")
  label(heading,26,49,39,QUIET,CONDENSED)
  var state=str({"outbound":"En route","working":"On site","return":"Recalling","blocked":"Rig stopped"}.get(op.state,op.state))
  if mining and op.state=="working":
   label("%d / %d cuts"%[op.strokes,op.max_strokes],24,146,72,PAPER,CONDENSED)
   bar(168,float(op.strokes)/maxi(1,op.max_strokes),AMBER)
   label("%.1f recovered"%game.planet.hotspots[op.site].extracted,28,231,43,MINT,CONDENSED)
  else:
   label(state,24,148,74,ALARM if op.state=="blocked" else PAPER,CONDENSED)
   var count=0
   for n in op.crew.values(): count+=int(n)
   label("%d crew assigned"%count,28,231,43,MINT,CONDENSED)
