extends RefCounted

const STAGES = [
 ["system", "system", "merchant"],
 ["merchant", "system", "signal"],
 ["system", "system", "system"],
 ["system", "merchant", "system"],
 ["signal", "system", "merchant"],
 ["", "system", ""]
]

const CONNECTIONS = [
 [[0, 1], [1, 2], [2]],
 [[0], [0, 1], [1, 2]],
 [[0, 1], [1], [1, 2]],
 [[0], [0, 1, 2], [2]],
 [[1], [1], [1]],
 [[0, 1, 2], [0, 1, 2], [0, 1, 2]]
]

static func kind(depth: int, lane: int) -> String:
 if depth<1 or lane<0 or lane>2: return ""
 return STAGES[(depth-1)%STAGES.size()][lane]

static func onward(depth: int, lane: int) -> Array:
 if depth==0: return [0,1,2]
 return CONNECTIONS[(depth-1)%STAGES.size()][lane]
