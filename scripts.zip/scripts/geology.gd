extends RefCounted

const MATERIALS=["Regolith","Basalt","Ferrite","Cobalt crystal"]
const VALUES=[0.0,0.001,0.026,0.072]
const COLORS=[Color("8d7960"),Color("454d50"),Color("a87042"),Color("4e9da4")]
var data: Dictionary
const Landscape=preload("res://scripts/landscape.gd")
var landscape
var cut_cells={}
var indexed_edits=0

func _init(body: Dictionary):
 data=body
 landscape=Landscape.new(body)

func base_sdf(p: Vector3) -> float:
 var length=p.length()
 if length<0.001: return -float(data.radius)
 return length-data.radius-landscape.height(p/length)

func surface(normal: Vector3) -> Vector3:
 return normal*(data.radius+landscape.height(normal))

func density(p: Vector3) -> float:
 _index_edits()
 var result=base_sdf(p)
 for cut in cut_cells.get(Vector3i((p/64.0).floor()),[]):
  result=maxf(result,cut.radius-p.distance_to(cut.center))
 return result

func _index_edits():
 var edits=data.get("edits",[])
 while indexed_edits<edits.size():
  var cut=edits[indexed_edits]
  var low=Vector3i(((cut.center-Vector3.ONE*cut.radius)/64.0).floor())
  var high=Vector3i(((cut.center+Vector3.ONE*cut.radius)/64.0).floor())
  for x in range(low.x,high.x+1):
   for y in range(low.y,high.y+1):
    for z in range(low.z,high.z+1):
     var key=Vector3i(x,y,z)
     if not cut_cells.has(key): cut_cells[key]=[]
     cut_cells[key].append(cut)
  indexed_edits+=1

func edited_surface(normal: Vector3) -> Vector3:
 var radius=surface(normal).length()
 # Radial silhouette sampling preserves open cuts in distant fracture geometry.
 for repeat in 2:
  for cut in data.get("edits",[]):
   var projection=cut.center.dot(normal)
   var side=cut.center.length_squared()-projection*projection
   if side>=cut.radius*cut.radius: continue
   var reach=sqrt(maxf(0,cut.radius*cut.radius-side))
   if radius>=projection-reach and radius<=projection+reach+0.05: radius=projection-reach
 return normal*radius

func material_at(p: Vector3) -> int:
 var depth=-base_sdf(p)
 if depth<3.5: return 0
 for deposit in data.get("deposits",[]):
  for center in deposit.centers:
   if p.distance_squared_to(center)<deposit.width*deposit.width:
    return deposit.material
 return 1

func hardness_at(p: Vector3) -> float:
 return [0.65,1.8,1.15,2.8][material_at(p)]

func nearest_deposit(p: Vector3):
 var closest=null
 var distance=INF
 for deposit in data.get("deposits",[]):
  var d=p.distance_to(deposit.surface)
  if d<distance: closest=deposit;distance=d
 return closest

func sample_cut(center: Vector3, radius: float) -> Dictionary:
 var result={"volume":0.0,"yield":0.0,"materials":[0.0,0.0,0.0,0.0],"hardness":0.0}
 var step=clampf(radius/3.5,0.75,5.0)
 var lower=center-Vector3.ONE*radius
 var count=int(ceil(radius*2.0/step))
 for x in count:
  for y in count:
   for z in count:
    var p=lower+(Vector3(x,y,z)+Vector3.ONE*0.5)*step
    if p.distance_squared_to(center)>radius*radius or density(p)>=-0.05: continue
    var m=material_at(p)
    var v=step*step*step
    result.volume+=v
    result.materials[m]+=v
    result.yield+=v*VALUES[m]
    result.hardness+=v*[0.65,1.8,1.15,2.8][m]
 if result.volume>0: result.hardness/=result.volume
 return result

func record_cut(center: Vector3, radius: float, result: Dictionary):
 data.edits.append({"center":center,"radius":radius})
 data.removed_volume=data.get("removed_volume",0.0)+result.volume
 data.ore_recovered=data.get("ore_recovered",0.0)+result.yield

func graph() -> VoxelGeneratorGraph:
 var generator=VoxelGeneratorGraph.new()
 var g=generator.get_main_function()
 var xyz=[]
 for type in [VoxelGraphFunction.NODE_INPUT_X,VoxelGraphFunction.NODE_INPUT_Y,VoxelGraphFunction.NODE_INPUT_Z]:
  xyz.append(g.create_node(type,Vector2.ZERO))
 var sdf=landscape.density_graph(g,xyz)
 var output=g.create_node(VoxelGraphFunction.NODE_OUTPUT_SDF,Vector2.ZERO)
 g.add_connection(sdf,0,output,0)
 # The material volume is generated independently from the excavation SDF.
 var ore_distance=-1
 var cobalt_distance=-1
 for deposit in data.get("deposits",[]):
  for center in deposit.centers:
   var coords=[]
   for axis in 3:
    var sub=g.create_node(VoxelGraphFunction.NODE_SUBTRACT,Vector2.ZERO)
    g.add_connection(xyz[axis],0,sub,0)
    g.set_node_default_input(sub,1,center[axis])
    coords.append(sub)
   var ball=g.create_node(VoxelGraphFunction.NODE_SDF_SPHERE,Vector2.ZERO)
   for axis in 3: g.add_connection(coords[axis],0,ball,axis)
   g.set_node_default_input_by_name(ball,"radius",deposit.width)
   if deposit.material==3: cobalt_distance=_min_node(g,cobalt_distance,ball)
   else: ore_distance=_min_node(g,ore_distance,ball)
 var material_index=g.create_node(VoxelGraphFunction.NODE_SELECT,Vector2.ZERO)
 g.set_node_default_input_by_name(material_index,"a",2.0)
 g.set_node_default_input_by_name(material_index,"b",1.0)
 g.set_node_param_by_name(material_index,"threshold",0.0)
 if ore_distance>=0: g.add_connection(ore_distance,0,material_index,g.get_node_input_index(material_index,"t"))
 else: g.set_node_default_input_by_name(material_index,"t",10.0)
 var cobalt_select=g.create_node(VoxelGraphFunction.NODE_SELECT,Vector2.ZERO)
 g.set_node_default_input_by_name(cobalt_select,"a",3.0)
 g.add_connection(material_index,0,cobalt_select,g.get_node_input_index(cobalt_select,"b"))
 g.set_node_param_by_name(cobalt_select,"threshold",0.0)
 if cobalt_distance>=0: g.add_connection(cobalt_distance,0,cobalt_select,g.get_node_input_index(cobalt_select,"t"))
 else: g.set_node_default_input_by_name(cobalt_select,"t",10.0)
 var final_index=g.create_node(VoxelGraphFunction.NODE_SELECT,Vector2.ZERO)
 g.add_connection(cobalt_select,0,final_index,g.get_node_input_index(final_index,"a"))
 g.set_node_default_input_by_name(final_index,"b",0.0)
 g.add_connection(sdf,0,final_index,g.get_node_input_index(final_index,"t"))
 g.set_node_param_by_name(final_index,"threshold",-3.5)
 var material_output=g.create_node(VoxelGraphFunction.NODE_OUTPUT_SINGLE_TEXTURE,Vector2.ZERO)
 g.add_connection(final_index,0,material_output,0)
 generator.texture_mode=VoxelGeneratorGraph.TEXTURE_MODE_SINGLE
 var result=generator.compile()
 if not result.get("success",false): push_error("Planet graph compilation failed: "+str(result))
 return generator

func _min_node(g,previous: int,value: int) -> int:
 if previous<0: return value
 var node=g.create_node(VoxelGraphFunction.NODE_MIN,Vector2.ZERO)
 g.add_connection(previous,0,node,0);g.add_connection(value,0,node,1)
 return node
