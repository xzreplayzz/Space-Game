extends RefCounted
const Catalog=preload("res://scripts/catalog.gd")
const Volume=preload("res://scripts/planet_volume.gd")
const Geology=preload("res://scripts/geology.gd")
var g

func check(condition: bool,label: String): g._assert_test(condition,label)
func frames(count: int):
 for i in count: await g.get_tree().process_frame

func wait_for_disk_sdf(disk, center: Vector3, expect_air: bool) -> bool:
 var deadline=Time.get_ticks_msec()+10000
 while Time.get_ticks_msec()<deadline:
  if disk.can_edit(center,4.0):
   var sdf: float=disk.tool.get_voxel_f(Vector3i(center))
   if (sdf>0.05 if expect_air else sdf < -0.05): return true
  await g.get_tree().create_timer(0.015).timeout
 return false

func waypoint(p: Vector3,normal: Vector3,kind="mineral"):
 g.world.target_hit={"position":p,"normal":normal}
 g.world.place_waypoint()
 g.planet.hotspots[g.selected].kind=kind
 return g.selected

func run(game):
 g=game
 g.new_run(12345)
 check(g.total_workers()==100,"starting population is 100")
 check(g.bore_cost(4)==0 and g.bore_cost(16)>6,"starter excavation is free while powerful bores consume credits")
 g.enter_node(0)
 # Keep the 0.4.1 seeded fixture for legacy terrain and checkpoint checks.
 g.system_data=Catalog.generate_system(g.node_seed(1,1),0)
 g.route_log[1].name=g.system_data.name
 g.world.build_system(g.system_data)
 check(g.system_data.planets.size()>=3,"system contains multiple physical planets")
 check(g.world.solar_planets.size()==g.system_data.planets.size(),"all system bodies have 3D representations")
 g.world.step(0)
 var before_orbit=g.world.camera.position
 g.world.view_yaw+=0.7;g.world.step(0)
 check(g.world.camera.position.distance_to(before_orbit)>10000 and (-g.world.camera.basis.z).dot(-g.world.camera.position.normalized())>0.999,"system camera pans around the sun as its fixed centre")
 check(g.planet.is_empty() and g.system_data.planets[0].atmosphere_density>0,"generated worlds include atmospheric density")
 var again=Catalog.generate_system(g.system_data.seed,0)
 check(again.planets[0].seed==g.system_data.planets[0].seed,"seeded planets are deterministic")
 var distinct={}
 for body in g.system_data.planets: distinct[body.landscape]=true
 check(distinct.size()==g.system_data.planets.size(),"planets in one system have different landform recipes")
 _check_landforms()
 g.enter_planet(0)
 check(g.mode=="APPROACH","planet selection begins cinematic approach")
 g.world._approach_step(12)
 check(g.mode=="ENCOUNTER" and g.world.camera.position.distance_to(g.world.ship_position)<40,"approach finishes at physical first-person ship")
 check(g.world.volume.geology.base_sdf(g.world.ship_position)>8000.0,"approach ends outside the atmosphere")
 await _check_surface_handoff()
 var v=g.world.volume
 var p=g.planet.features[0].position
 var n=g.planet.features[0].normal
 _check_flight(p,n)
 v.focus("pilot",p,true,3000)
 await frames(100)
 var under=p-n*2.5
 var sdf_before=v.tool.get_voxel_f(Vector3i(under))
 check(sdf_before<0,"native volume contains solid ground")
 var cut=v.excavate(under,4.0)
 await frames(15)
 check(cut.ready and cut.volume>0,"native spherical excavation removes solid material")
 check(v.tool.get_voxel_f(Vector3i(under))>0,"excavated terrain becomes native empty space")
 var repeated=v.excavate(under,4.0)
 check(repeated.volume==0 and repeated.yield==0,"repeat cut in empty space yields nothing")
 check(v.geology.material_at(p-n*1)==0 and v.geology.material_at(p-n*8)!=0,"material changes below the regolith layer")
 var ore=g.planet.deposits[0].centers[1]
 check(v.geology.material_at(ore)==2,"deposit volume contains ferrite at depth")
 var ray=v.raycast(p+n*60,-n,150)
 check(not ray.is_empty() and ray.position.distance_to(p)>2,"surface targeting follows excavated holes")
 var site=waypoint(p,n)
 check(g.deploy(site,"extractors",10),"custom surface waypoint accepts extractor crew")
 check(g.available("extractors")==28 and g.deployed_workers()==10,"deployed crew leave onboard stations")
 g._tick_operations(5)
 for i in 12:
  g._tick_operations(12)
  await frames(2)
 var op=g.operation_for(site)
 check(op.state=="complete" and op.strokes==12,"excavation stops at the bounded pass limit")
 check(g.cargo>0,"crew couriers deliver resources from actual excavations")
 var edit_count=g.planet.edits.size()
 g._tick_operations(80)
 check(g.planet.edits.size()==edit_count,"completed crew do not keep mining without an order")
 g.extend_order()
 check(op.state=="working" and op.strokes==0,"another pass requires an explicit order")
 v.focus("pilot",-p,true,3000)
 g._tick_operations(12)
 check(g.planet.edits.size()>edit_count,"remote crew continue excavating after the ship leaves")
 check(g.recall(site),"allocation waypoint accepts recall")
 g._tick_operations(6)
 check(g.available("extractors")==38 and g.operations.is_empty(),"recall restores crew to onboard stations")
 check(not g.deploy(site,"abductors",5),"abductors require a settlement")
 # Verify the persistent database independently of the portable save ledger.
 var persisted_data=g.planet.duplicate(true)
 persisted_data.edits=[]
 var store="user://terrain-integration-%d-%d"%[OS.get_process_id(),Time.get_ticks_msec()]
 var disk=Volume.new();g.world.add_child(disk);disk.setup(persisted_data,store)
 disk.focus("test",p,true,3000)
 var disk_center: Vector3=p-n*2
 # Streaming is asynchronous. An unloaded block's default SDF is air, so
 # both passes must establish that the exact edit region is resident first.
 var loaded=await wait_for_disk_sdf(disk,disk_center,false)
 var stored_cut=disk.excavate(disk_center,4) if loaded else {"ready":false,"volume":0.0}
 if not loaded: print("SQLite QA: timed out waiting for the original solid voxel at ",disk_center)
 check(stored_cut.ready and stored_cut.volume>0,"SQLite-backed volume accepts excavation")
 await disk.flush()
 disk.free()
 await frames(8)
 persisted_data.edits=[]
 disk=Volume.new();g.world.add_child(disk);disk.setup(persisted_data,store);disk.focus("test",p,true,3000)
 var reloaded=await wait_for_disk_sdf(disk,disk_center,true)
 check(stored_cut.ready and reloaded,"native excavation survives database reload without ledger replay")
 var floating=p+n*80
 disk.focus("test",floating,true,3000)
 for wait_frame in 180:
  if disk.can_edit(floating,18): break
  await frames(1)
 disk.tool.mode=VoxelTool.MODE_ADD
 if disk.can_edit(floating,3.5): disk.tool.do_sphere(floating,3.5)
 disk.tool.mode=VoxelTool.MODE_REMOVE
 await frames(30)
 var pieces=disk.detach_local(floating,18)
 check(pieces.size()>0,"disconnected local terrain becomes actual rigid-body fragments")
 disk.free()
 # Same city, independent abduction and terrain interactions.
 var city_pos=v.geology.surface((n+Vector3.RIGHT*0.03).normalized())
 g.planet.inhabited=true;g.planet.population=9000
 g.planet.features.append({"name":"Test settlement","type":"Settlement","kind":"city","position":city_pos,"normal":city_pos.normalized(),"radius":80.0,"population":3000,"scanned":true})
 var city_site=waypoint(city_pos,city_pos.normalized(),"city")
 var count=g.total_workers()
 var before=g.planet.edits.size()
 g.deploy(city_site,"abductors",10);g._tick_operations(5);g._tick_operations(8)
 check(g.detected,"inhabited world reports abduction immediately")
 check(g.total_workers()>count and g.planet.edits.size()==before,"abduction adds specialised workers without excavating terrain")
 g.recall(city_site);g._tick_operations(6)
 check(g.police_response_seconds(5,1)==120.0 and g.police_response_seconds(1,0)==195.0,"risk-adjusted ISP response gives two to three minutes after detection")
 for i in 90:
  g._encounter_step(0.5)
  g.world._combat_step(0.5)
 check(not g.police_arrived and g.hull>80.0,"the initial work window survives light local defence without ISP pressure")
 g.world._build_settlements()
 check(g.world.buildings.size()>0,"inhabited worlds contain physical settlement buildings")
 var building=g.world.buildings[0]
 v.excavate(building.base-building.base.normalized()*1.5,5.5)
 g.world.settlement_damage(building.base,6)
 check(building.fallen and not building.feature.destroyed_buildings.is_empty(),"terrain undercut collapses a building and persists its destruction")
 g.deploy(site,"extractors",10)
 var workers_before=g.workers.extractors
 g.warp("SYSTEM")
 check(g.workers.extractors==workers_before-10 and g.last_abandoned==10,"emergency warp abandons all unrecalled crews")
 check(g.carried_stars==0,"escape before ISP arrival clears trail")
 g._finish_warp();g.credits=1000
 var old=g.credits
 check(g.choose_upgrade(0) and g.credits==old-g.offer_price and g.levels.size()==1,"sale funds one choice from three upgrades")
 check(g.mode=="SYSTEM","in-system departure returns to the physical solar system")
 g.enter_planet(0);g.mode="ENCOUNTER"
 g.alert_police();g.alert_age=g.arrival_time-0.01
 g._encounter_step(0.02)
 check(g.police_arrived and g.stars==5,"ISP escalation reaches maximum wanted level")
 var health=g.hull;g._encounter_step(1)
 check(g.hull<health-15,"ISP fire overwhelms hull")
 g.warp();check(g.carried_stars==1,"late escape retains a lookout star")
 g._finish_warp()
 var saved=g.workers.duplicate();var earned=g.credits
 check(g.save_run("user://integration-v4.save") and g.save_run("user://integration-v4.save"),"checkpoint creates a primary save and rolls the previous checkpoint into backup")
 g.workers.extractors=0;g.credits=0
 check(g.load_run("user://integration-v4.save") and g.workers==saved and g.credits==earned,"save restores workforce, economy and planetary edit ledger")
 check(not g.planet.edits.is_empty(),"revisited planet retains persistent excavation history")
 var corrupted=FileAccess.open("user://integration-v4.save",FileAccess.WRITE)
 corrupted.store_string("incomplete checkpoint")
 corrupted.close()
 check(g.load_run("user://integration-v4.save") and g.credits==earned and g.route_log[1].status=="completed","corrupt primary recovers the previous complete checkpoint")
 g.bank_reward()
 g.reopen_system()
 g.enter_planet(0)
 g.world._approach_step(12)
 # The endgame is tied to deep bores distributed around the crust, not ore depletion.
 g.levels={"core":3,"bore":3}
 g.planet.fracture_sectors=[];g.world.shattered=false
 for i in 8:
  var angle=(i+0.5)*TAU/8.0
  var direction=Vector3(cos(angle),0.22,sin(angle)).normalized()
  var deep=g.world.volume.geology.surface(direction)-direction*(g.planet.radius*0.12)
  g._check_fracture(deep)
 check(g.world.shattered and g.planet.fractured and g.world.fragment_nodes.size()>0,"distributed deep crustal faults trigger whole-world fragmentation")
 g.world.clear_combat()
 await _check_harrow()
 var failed=g.test_results.filter(func(t):return not t.passed).size()
 print("SELF_TEST_RESULT "+JSON.stringify({"passed":g.test_results.size()-failed,"failed":failed,"tests":g.test_results}))
 g.get_tree().quit(1 if failed else 0)

func _check_harrow():
 g.new_run(5508)
 g.enter_node(1)
 check(g.system_data.name=="Cinder Reach" and g.system_data.planets.size()==3,"Cinder Reach opens from its chart branch with three authored bodies")
 g.enter_planet(0)
 var w=g.world
 var v=w.volume
 check(g.planet.radius==240000.0 and w.buildings.size()==9,"Harrow is 480 km across and contains the modeled industrial district")
 w._approach_step(12)
 check(v.geology.base_sdf(w.ship_position)>8000.0 and w.ship_position.length()>w._atmosphere_radius(g.planet),"Harrow hands over the cockpit outside its atmosphere")
 for i in 1400:
  w._propulsion(0.05,Vector2(0,1),0.0,false,true,false)
  if v.geology.base_sdf(w.ship_position)<1200.0: break
 var feature=g.planet.features[0]
 check(w.ship_position.distance_to(feature.position)<3200.0,"starter descent reaches the surveyed mining corridor")
 var ground: Vector3=feature.position
 var up: Vector3=feature.normal
 w.ship_position=ground+up*95.0
 w.ship_velocity=Vector3.ZERO
 w._cockpit_pose()
 v.focus("pilot",ground)
 for i in 320:
  if v.can_edit(ground,12.0): break
  await frames(1)
 var spot=waypoint(ground,up)
 check(g.deploy(spot,"extractors",18),"crew deployment reaches a Harrow mineral seam")
 g._tick_operations(5)
 for i in 12:
  g._tick_operations(7)
  await frames(2)
 check(g.planet.edits.size()>0 and g.cargo>0.0,"Harrow excavation recovers material from the edited volume")
 for i in 150:
  w.step(0.016)
  if w.cut_patch.visible: break
  await frames(1)
 check(w.cut_patch.visible and w.spherical_surface.visible,"editable mesh appears locally in the continuous spherical surface")

func _check_landforms():
 var signatures=[]
 var native_match=true
 var rift_valid=true
 var whole_globe=true
 for profile in Geology.Landscape.PROFILES.size():
  var body=Catalog.generate_system(2017,0,profile).planets[0]
  var geo=Geology.new(body)
  var generator=geo.graph()
  if profile==0:
   for distance in [1100.0,1800.0,2500.0]:
    var elevations=[]
    for x in [-1820.0,0.0,2080.0]:
     var local=Vector2(x,-distance).rotated(body.landscape_yaw)*body.landscape_scale
     var unit=(Vector3.UP*body.radius+Vector3(local.x,0,local.y)).normalized()
     elevations.append(geo.surface(unit).length())
    if minf(elevations[0],elevations[2])<elevations[1]+300.0: rift_valid=false
  var signature=[]
  for offset in [Vector3(0,0,-1300),Vector3(-1450,0,-2000),Vector3(1400,0,-2500),Vector3(850,0,-3200),Vector3(0,0,-5100)]:
   var normal=(Vector3.UP*body.radius+offset).normalized()
   var surface=geo.surface(normal)
   signature.append(surface.length()-body.radius)
   var buffer=VoxelBuffer.new();buffer.create(7,7,7)
   buffer.set_channel_depth(VoxelBuffer.CHANNEL_SDF,VoxelBuffer.DEPTH_32_BIT)
   buffer.set_channel_depth(VoxelBuffer.CHANNEL_INDICES,VoxelBuffer.DEPTH_8_BIT)
   var origin=Vector3i(surface.round())-Vector3i.ONE*3
   generator.generate_block(buffer,origin,0)
   for y in [1,3,5]:
    var point=Vector3(origin+Vector3i(3,y,3))
    var native=buffer.get_voxel_f(3,y,3,VoxelBuffer.CHANNEL_SDF)
    if absf(native-geo.base_sdf(point))>0.08: native_match=false
  signatures.append(signature)
  for axis in [Vector3.DOWN,Vector3.LEFT,Vector3.RIGHT,Vector3.FORWARD,Vector3.BACK]:
   var lowest=INF
   var highest=-INF
   for x in range(-3,4):
    for z in range(-3,4):
     var tangent=(Vector3.UP if absf(axis.y)<0.9 else Vector3.RIGHT).cross(axis).normalized()
     var direction=(axis+tangent*x*0.16+axis.cross(tangent)*z*0.16).normalized()
     var height=geo.surface(direction).length()-body.radius
     lowest=minf(lowest,height)
     highest=maxf(highest,height)
   if highest-lowest<250.0: whole_globe=false
 check(rift_valid,"rift has a continuous low floor between raised mountain ranges")
 var distinct=true
 for i in signatures.size():
  for j in range(i):
   var total=0.0
   for k in signatures[i].size(): total+=absf(signatures[i][k]-signatures[j][k])
   if total<250: distinct=false
 check(distinct,"six world profiles differ in elevation geometry as well as colour")
 check(native_match,"all six native voxel graphs match the analytic terrain used for mining and flight")
 check(whole_globe,"all six terrain profiles have substantial elevation variation outside the landing hemisphere")
 var first=Geology.new(Catalog.generate_system(2017,0,1).planets[0])
 var second_body=first.data.duplicate(true)
 second_body.seed+=3107
 var second=Geology.new(second_body)
 var difference=0.0
 for offset in [Vector3(-1730,0,-3120),Vector3(1680,0,-3350),Vector3(170,0,-5250),Vector3(-880,0,-2510)]:
  var normal=(Vector3.UP*first.data.radius+offset).normalized()
  difference+=first.surface(normal).distance_to(second.surface(normal))
 check(difference>150.0,"two sandstone worlds vary their mesa shapes and placement, not just their palettes")

func _check_surface_handoff():
 var w=g.world
 var volume=w.volume
 var arrival=w.ship_position
 var up=arrival.normalized()
 var ground=volume.geology.surface(up)
 var proxy=w.solar_planets[w.solar_target].get_meta("surface_mesh")
 w.ship_position=ground+up*1589.0
 w.step(0)
 check(proxy.visible and not volume.terrain.visible,"cold descent retains the orbital surface until native terrain is available")
 w.ship_position=arrival
 w.step(0)
 for i in 1000:
  if volume.has_surface_coverage(up): break
  await frames(1)
 check(proxy.visible and not volume.terrain.visible and volume.has_surface_coverage(up),"terrain preloads behind the visible orbital surface")
 w.ship_position=ground+up*1589.0
 for i in 1000:
  w.step(0)
  if volume.terrain.visible: break
  await frames(1)
 check(volume.terrain.visible and not proxy.visible,"descent swaps to streamed ground once the active meshes cover the view")
 w.ship_position=arrival
 w.step(0)
 check(proxy.visible and not volume.terrain.visible,"climbing back to orbit restores the orbital surface")

func _check_flight(p: Vector3,n: Vector3):
 var w=g.world
 var previous=w.ship_position
 var pitch=w.flight_pitch
 var toggle=InputEventKey.new();toggle.pressed=true;toggle.keycode=KEY_B
 g._unhandled_input(toggle)
 var enabled=w.cruise_boost
 g._unhandled_input(toggle)
 check(enabled and not w.cruise_boost,"B engages and disengages latched boost during flight")
 for frame in range(600):
  w._propulsion(0.05,Vector2(0,1),0.0,false,true,false)
 var descended=w.volume.geology.base_sdf(w.ship_position)
 check(descended<3800.0 and descended>=w.MIN_CLEARANCE-0.05,"the player can boost from orbital arrival to streamed terrain in thirty seconds")
 w.ship_velocity=Vector3.ZERO
 w.flight_pitch=0.0
 w.ship_position=p+n*2700.0
 for i in 100: w._propulsion(0.05,Vector2(0,1),0.0,false,false,false)
 var standard=w.ship_velocity.length()
 w.ship_velocity=Vector3.ZERO;w.ship_position=p+n*2700.0
 for i in 100: w._propulsion(0.05,Vector2(0,1),0.0,false,true,false)
 var boosted=w.ship_velocity.length()
 check(absf(boosted/standard-10.0)<0.03,"cruise travels ten times faster than ordinary starter thrust")
 for i in 8: w._propulsion(0.05,Vector2(0,1),0.0,false,true,true)
 check(not w.boost_active and w.ship_velocity.length()<standard,"strong brakes take priority over boost")
 var lowest=INF
 w.ship_position=w.surface_start;w.ship_velocity=Vector3.ZERO;w.flight_yaw=0.8
 for i in 260:
  w._propulsion(0.05,Vector2(0,1),0.0,false,true,false)
  lowest=minf(lowest,w.volume.geology.base_sdf(w.ship_position))
 check(lowest>=w.MIN_CLEARANCE-0.05,"boost maintains clearance when crossing hills and ridges")
 w.ship_position=previous;w.ship_velocity=Vector3.ZERO;w.flight_yaw=0.0;w.flight_pitch=pitch;w.boost_active=false
 w._cockpit_pose()
