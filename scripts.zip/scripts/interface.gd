extends Control

const Catalog=preload("res://scripts/catalog.gd")
const INK=Color("070e18")
const PANEL=Color("0d1824")
const EDGE=Color("2a3a47")
const WHITE=Color("e4e7df")
const MUTED=Color("8899a6")
const CYAN=Color("79c5b5")
const GOLD=Color("dfae6f")
const RED=Color("e9826c")
const PURPLE=Color("b4a0d3")
var game
var font: Font
var mono: Font
var title_font: Font
var buttons=[]
var mouse=Vector2.ZERO

func _ready():
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 mouse_filter=Control.MOUSE_FILTER_PASS
 font=SystemFont.new()
 font.font_names=PackedStringArray(["Segoe UI","Arial"])
 mono=SystemFont.new()
 mono.font_names=PackedStringArray(["Consolas","Courier New"])
 title_font=SystemFont.new()
 title_font.font_names=PackedStringArray(["Bahnschrift","Segoe UI"])
 title_font.font_weight=600

func txt(value, x: float, y: float, size=18, color=WHITE, face=null):
 draw_string(font if face==null else face,Vector2(x,y),str(value),HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func centered(value, x: float, y: float, size=18, color=WHITE, face=null):
 var selected_font=font if face==null else face
 var width=selected_font.get_string_size(str(value),HORIZONTAL_ALIGNMENT_LEFT,-1,size).x
 txt(value,x-width*0.5,y,size,color,selected_font)

func wrapped(value: String, x: float, y: float, width: float, size=18, color=MUTED, spacing=27):
 var row=""
 var yy=y
 for word in value.split(" "):
  var trial=row+word+" "
  if font.get_string_size(trial,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x>width and row!="":
   txt(row,x,yy,size,color)
   yy+=spacing
   row=word+" "
  else: row=trial
 if row!="": txt(row,x,yy,size,color)
 return yy

func rectangle(x: float,y: float,w: float,h: float,color: Color):
 draw_rect(Rect2(x,y,w,h),color)

func panel(x: float,y: float,w: float,h: float):
 rectangle(x,y,w,h,Color(PANEL,0.94))
 draw_rect(Rect2(x,y,w,h),EDGE,false,1.0)

func rule(x: float,y: float,w: float,color=EDGE):
 draw_line(Vector2(x,y),Vector2(x+w,y),color,1.0,true)

func button(label: String, rect: Rect2, action: String, payload=null, primary=false, enabled=true):
 var hover=rect.has_point(mouse) and enabled
 var fill=Color("233d41") if primary else Color("152430")
 if hover: fill=Color("315052") if primary else Color("243a46")
 if not enabled: fill=Color("101b25")
 draw_rect(rect,fill)
 draw_rect(rect,CYAN if primary and enabled else (MUTED if hover else EDGE),false,1.0)
 centered(label,rect.get_center().x,rect.position.y+rect.size.y*0.5+6,16,WHITE if enabled else Color("4e6271"),mono)
 if enabled: buttons.append({"rect":rect,"action":action,"payload":payload})

func symbol(kind: String, at: Vector2, radius: float, color: Color):
 if kind=="system":
  draw_circle(at,radius*0.46,color,false,1.5,true)
  draw_arc(at,radius*0.86,-0.35,2.3,24,color,1.2,true)
  draw_arc(at,radius*0.86,2.8,5.8,24,color,1.2,true)
  draw_circle(at+Vector2(radius*0.75,-radius*0.4),2.4,color)
 elif kind=="merchant":
  var points=PackedVector2Array([at+Vector2(0,-radius),at+Vector2(radius,0),at+Vector2(0,radius),at+Vector2(-radius,0),at+Vector2(0,-radius)])
  draw_polyline(points,color,1.5,true)
  draw_line(at+Vector2(-radius*0.45,0),at+Vector2(radius*0.45,0),color,1.5)
 else:
  draw_rect(Rect2(at-Vector2.ONE*radius*0.65,Vector2.ONE*radius*1.3),color,false,1.5)
  draw_line(at-Vector2(radius,0),at+Vector2(radius,0),color,1.2)
  draw_line(at-Vector2(0,radius),at+Vector2(0,radius),color,1.2)

func star(at: Vector2, radius: float, color: Color, filled=true):
 var points=PackedVector2Array()
 for i in 10:
  var angle=-PI*0.5+float(i)*PI/5.0
  points.append(at+Vector2(cos(angle),sin(angle))*radius*(1.0 if i%2==0 else 0.43))
 if filled: draw_colored_polygon(points,color)
 else:
  points.append(points[0])
  draw_polyline(points,color,1.2,true)

func header():
 rule(34,91,1532)
 symbol("merchant",Vector2(49,45),12,GOLD)
 txt("VOIDWAKE",75,53,27,WHITE,title_font)
 txt("EXPEDITION / %04d"%game.planets_visited,272,51,13,MUTED,mono)
 if game.mode!="TITLE":
  txt("CREW",1135,37,11,MUTED,mono)
  txt(str(game.total_workers()),1135,63,24,WHITE,title_font)
  txt("CREDITS",1270,37,11,MUTED,mono)
  txt("%s cr"%game.credits,1270,63,24,GOLD,title_font)
 button("F1  GUIDE",Rect2(1430,30,135,36),"help")

func _draw():
 if game==null: return
 mouse=get_global_mouse_position()
 buttons.clear()
 match game.mode:
  "TITLE": _title()
  "MAP": _map()
  "SYSTEM": _system()
  "ENCOUNTER": _encounter()
  "WARP": _warp()
  "REWARD": _reward()
  "MERCHANT": _merchant()
  "SIGNAL": _signal()
  "LOST": _lost()
 if game.mode!="TITLE" and game.mode!="ENCOUNTER" and game.mode!="WARP":
  txt("M  AUDIO "+("OFF" if game.muted else "ON"),35,875,12,MUTED,mono)
  txt("FIELD BUILD 0.1  /  PROGRESS SAVES AUTOMATICALLY",1050,875,12,MUTED,mono)
 if game.mode=="ENCOUNTER":
  var yy=725.0
  for message in game.messages:
   centered(message.text,780,yy,14,Color(message.color,minf(1.0,message.time)),mono)
   yy+=24
 if game.tutorial_open: _tutorial()
 if game.paused: _pause()
 if game.help_open: _help()

func _title():
 rectangle(0,0,780,900,Color(INK,0.90))
 txt("INDEPENDENT EXPEDITION / 001",80,166,14,GOLD,mono)
 txt("VOIDWAKE",72,292,105,WHITE,title_font)
 rule(80,329,540)
 txt("TAKE WHAT YOU CAN.",80,390,32,WHITE,title_font)
 txt("LEAVE BEFORE THEY ARRIVE.",80,431,32,WHITE,title_font)
 wrapped("Build your ship. Deploy your people. Strip alien worlds under the shadow of an approaching intergalactic police force.",80,491,505,19,MUTED,30)
 button("BEGIN EXPEDITION   →",Rect2(80,626,350,56),"new",null,true)
 if FileAccess.file_exists(game.SAVE_PATH):
  button("CONTINUE EXPEDITION",Rect2(80,696,350,48),"continue")
 button("FLIGHT MANUAL",Rect2(448,626,185,56),"help")
 txt("A SPACE CONQUEST ROGUELITE",80,832,13,MUTED,mono)
 txt("FIRST PLAYABLE / 0.1",80,857,12,MUTED,mono)
 txt("UNREGISTERED VESSEL",1135,720,12,GOLD,mono)
 txt("SIGNATURE UNKNOWN",1135,747,18,WHITE,mono)
 rule(1135,765,280)
 txt("DEEP SPACE / OUTSIDE ISP JURISDICTION",1135,790,11,MUTED,mono)

func _map():
 rectangle(0,0,1600,900,Color(INK,0.91))
 header()
 txt("THE NEXT HORIZON",56,164,46,WHITE,title_font)
 txt("Choose a connected destination. System contents are revealed on arrival.",58,204,18,MUTED)
 var x_start=176.0
 var x_spacing=244.0
 var rows=[352.0,510.0,668.0]
 for column in 5:
  for row in 3:
   for next in 3:
    if abs(next-row)>1: continue
    var start=Vector2(x_start+column*x_spacing,rows[row])
    var end=Vector2(x_start+(column+1)*x_spacing,rows[next])
    draw_line(start,end,Color("1e303d"),1.2,true)
 for column in 6:
  var depth=game.route_step+column+1
  var x=x_start+column*x_spacing
  centered("JUMP %02d"%depth,x,270,12,MUTED,mono)
  for row in 3:
   var active=column==0 and (game.route_step==0 or abs(row-game.lane)<=1)
   var kind=game.node_type(depth,row)
   var at=Vector2(x,rows[row])
   var color=GOLD if kind=="merchant" else (PURPLE if kind=="signal" else CYAN)
   var hover=at.distance_to(mouse)<42 and active
   draw_circle(at,37,Color("152a35") if active else Color("0c1722"))
   draw_circle(at,37,color if active else EDGE,false,1.5,true)
   if hover: draw_circle(at,43,color,false,1.0,true)
   symbol(kind,at,18,color if active else Color("62727d"))
   var label="ASTEROID MERCHANT" if kind=="merchant" else ("UNKNOWN SIGNAL" if kind=="signal" else game.node_name(depth,row).to_upper())
   centered(label,x,rows[row]+61,12,WHITE if active else MUTED,mono)
   if active: buttons.append({"rect":Rect2(at-Vector2(48,48),Vector2(96,123)),"action":"node","payload":row})
 rule(56,777,1488)
 symbol("system",Vector2(71,817),12,CYAN)
 txt("SOLAR SYSTEM",95,822,12,MUTED,mono)
 symbol("merchant",Vector2(290,817),12,GOLD)
 txt("ASTEROID MERCHANT",315,822,12,MUTED,mono)
 symbol("signal",Vector2(565,817),12,PURPLE)
 txt("UNKNOWN SIGNAL",590,822,12,MUTED,mono)
 txt("ENDLESS FRONTIER  →",1315,822,12,GOLD,mono)
 if game.carried_stars>0:
  star(Vector2(1048,171),10,GOLD)
  txt("ISP ON THE LOOKOUT",1071,177,15,GOLD,mono)

func _planet_icon(at: Vector2, radius: float, data: Dictionary):
 var biome=Catalog.BIOMES[data.biome]
 draw_circle(at,radius,biome.low)
 var random=RandomNumberGenerator.new()
 random.seed=data.seed
 for i in 20:
  var offset=Vector2(random.randf_range(-radius*0.7,radius*0.7),random.randf_range(-radius*0.7,radius*0.7))
  var size=random.randf_range(2.0,radius*0.30)
  if offset.length()+size<radius:
   draw_circle(at+offset,size,biome.land)
 draw_arc(at,radius,-2.4,0.7,36,biome.high,1.5,true)
 if data.rings:
  draw_ellipse_ring(at,radius*1.5,radius*0.36,biome.high)

func draw_ellipse_ring(at: Vector2, rx: float, ry: float, color: Color):
 var points=PackedVector2Array()
 for i in 65:
  var angle=float(i)*TAU/64.0
  points.append(at+Vector2(cos(angle)*rx,sin(angle)*ry).rotated(-0.24))
 draw_polyline(points,color,1.5,true)

func _system():
 rectangle(0,0,1600,900,Color(INK,0.85))
 header()
 txt(game.system_data.name.to_upper(),56,160,48,WHITE,title_font)
 txt("%d WORLDS  /  SELECT YOUR PLANETARY OPERATION"%game.system_data.count,58,202,14,MUTED,mono)
 txt("More worlds increase the system's detection risk.",1000,195,15,MUTED)
 for i in game.system_data.planets.size():
  var data=game.system_data.planets[i]
  var x=54+float(i%4)*378
  var y=240+float(int(i/4))*286
  panel(x,y,358,264)
  _planet_icon(Vector2(x+57,y+58),31,data)
  txt(Catalog.BIOMES[data.biome].name,x+109,y+39,11,CYAN,mono)
  txt(data.name,x+109,y+72,25,WHITE,title_font)
  txt("RISK",x+22,y+117,11,MUTED,mono)
  for tick in 5: rectangle(x+71+tick*16,y+107,10,10,GOLD if tick<data.risk else EDGE)
  txt("INHABITED" if data.inhabited else "UNINHABITED",x+172,y+117,11,PURPLE if data.inhabited else MUTED,mono)
  if data.inhabited:
   txt("DOMINANT JOB",x+22,y+156,10,MUTED,mono)
   txt(data.top_job.to_upper()+"  %d%%"%int(data.skills[data.top_job]*100),x+22,y+180,15,PURPLE,mono)
  else:
   txt("MINERAL SURVEY",x+22,y+156,10,MUTED,mono)
   txt("9 RESOURCE SIGNATURES",x+22,y+180,15,CYAN,mono)
  button("APPROACH PLANET   →",Rect2(x+18,y+207,322,40),"planet",i,true)
 txt("Survey freely before extraction. Any operation may expose your signature.",56,850,15,MUTED)

func _wanted():
 var color=RED if game.police_arrived else GOLD
 for i in 5: star(Vector2(690+i*34,40),11,color if i<game.stars else Color("344450"),i<game.stars)
 var status="SIGNATURE CONCEALED"
 if game.carried_stars>0 and not game.detected: status="ISP ON THE LOOKOUT"
 if game.detected:
  status="SIGNATURE DETECTED"
  if game.alert_age>game.arrival_time*0.55: status="ISP RESPONSE INBOUND"
  if game.alert_age>game.arrival_time*0.8: status="ARRIVAL IMMINENT · RECALL CREW"
 if game.police_arrived: status="ISP ARRIVED · WARP NOW"
 centered(status,758,73,11,color if game.stars>0 else MUTED,mono)

func _encounter():
 rectangle(0,0,1600,96,Color(INK,0.88))
 rule(28,95,1544)
 txt(game.planet.name.to_upper(),30,40,25,WHITE,title_font)
 txt(game.system_data.name.to_upper()+" / "+Catalog.BIOMES[game.planet.biome].name,30,70,12,MUTED,mono)
 _wanted()
 txt("HULL %d / %d"%[int(game.hull),int(game.max_hull)],1190,36,13,WHITE,mono)
 rectangle(1190,49,226,7,EDGE)
 rectangle(1190,49,226*game.hull/game.max_hull,7,RED if game.hull/game.max_hull<0.3 else CYAN)
 button("F1 GUIDE",Rect2(1450,28,120,36),"help")
 # Surface markers are anchored to actual 3D positions and hidden behind the horizon.
 for i in game.planet.hotspots.size():
  if not game.world.site_visible(i): continue
  var point=game.world.site_screen(i)
  if point.x<310 or point.x>1225 or point.y<115 or point.y>780: continue
  var spot=game.planet.hotspots[i]
  var color=PURPLE if spot.kind=="city" else (GOLD if spot.kind=="core" else CYAN)
  var radius=16.0 if i==game.selected else 10.0
  draw_circle(point,radius+4,Color(INK,0.7))
  draw_circle(point,radius,color,false,1.5,true)
  draw_line(point-Vector2(4,0),point+Vector2(4,0),color,1.0)
  draw_line(point-Vector2(0,4),point+Vector2(0,4),color,1.0)
  var op=game.operation_for(i)
  if op!=null:
   draw_arc(point,radius+7,-PI*0.5,game.world.clock*0.5+PI,24,GOLD if op.state=="return" else CYAN,2.0,true)
  if i==game.selected or point.distance_to(mouse)<35:
   txt(spot.label,point.x+23,point.y-8,12,color,mono)
   txt("POPULATION" if spot.kind=="city" else ("DEEP CORE" if spot.kind=="core" else "MINERAL SEAM"),point.x+23,point.y+11,10,MUTED,mono)
  buttons.append({"rect":Rect2(point-Vector2(22,22),Vector2(44,44)),"action":"site","payload":i})
 # Onboard crew dashboard.
 panel(28,122,268,327)
 txt("SHIP COMPLEMENT",46,153,13,WHITE,mono)
 txt("AVAILABLE / TOTAL",46,177,10,MUTED,mono)
 rule(46,191,232)
 for i in Catalog.JOBS.size():
  var job=Catalog.JOBS[i]
  var yy=222+i*42
  txt(Catalog.JOB_NAMES[i],46,yy,12,CYAN if game.selected_job==job else MUTED,mono)
  txt("%d / %d"%[game.available(job),game.workers[job]],187,yy,14,WHITE,mono)
 txt("%d DEPLOYED"%game.deployed_workers(),46,431,11,GOLD,mono)
 panel(28,469,268,165)
 txt("CARGO IN HOLD",46,500,11,MUTED,mono)
 txt("%.1f"%game.cargo,46,543,35,WHITE,title_font)
 txt("EST. SALE  %d cr"%int(game.cargo*3*pow(1.35,game.levels.get("cargo",0))),46,573,12,GOLD,mono)
 txt("Delivered by returning couriers",46,611,11,MUTED)
 var discovered=0
 for spot in game.planet.hotspots:
  if spot.revealed: discovered+=1
 txt("SURVEY %d / 9"%discovered,46,670,12,CYAN,mono)
 txt("PLANET INTEGRITY",46,702,10,MUTED,mono)
 rectangle(46,715,230,4,EDGE)
 rectangle(46,715,230*game.planet.integrity,4,GOLD)
 txt("A / D  orbit",46,758,12,MUTED,mono)
 txt("Q / E  rise / descend",46,780,12,MUTED,mono)
 txt("W / S  approach / retreat",46,802,12,MUTED,mono)
 _allocation_panel()
 # Hostile contact markers.
 for entity in game.world.combat:
  if game.world.camera.is_position_behind(entity.node.position): continue
  var at=game.world.camera.unproject_position(entity.node.position)
  if at.x>310 and at.x<1220 and at.y>100 and at.y<810:
   draw_rect(Rect2(at-Vector2(13,13),Vector2(26,26)),RED,false,1.0)
   txt("MISSILE" if entity.type=="missile" else "FIGHTER",at.x+18,at.y+5,10,RED,mono)
 # Personal gun reticle follows the mouse inside the viewport.
 if not pointer_over_panel() and mouse.y>100 and mouse.y<820:
  for sign_value in [-1,1]:
   draw_line(mouse+Vector2(sign_value*7,0),mouse+Vector2(sign_value*13,0),WHITE,1.0)
   draw_line(mouse+Vector2(0,sign_value*7),mouse+Vector2(0,sign_value*13),WHITE,1.0)
 rectangle(0,844,1600,56,Color(INK,0.94))
 rule(28,844,1544)
 txt("RMB DRAG  survey    SHIFT  boost    LMB  fire    TAB  next hotspot",30,878,12,MUTED,mono)
 txt("ESC  pause / save",1010,878,12,MUTED,mono)
 if game.world.hit_flash>0:
  draw_rect(Rect2(2,2,1596,896),Color(RED,minf(0.8,game.world.hit_flash*2)),false,5)

func _allocation_panel():
 var x=1246.0
 var spot=game.planet.hotspots[game.selected]
 panel(x,122,326,620)
 txt("ALLOCATION NODE %02d"%(game.selected+1),x+20,154,11,GOLD,mono)
 txt(spot.label,x+20,191,25,WHITE,title_font)
 var type_label="POPULATION CENTRE" if spot.kind=="city" else ("CORE FISSURE" if spot.kind=="core" else "MINERAL DEPOSIT")
 txt(type_label,x+20,217,12,PURPLE if spot.kind=="city" else CYAN,mono)
 if spot.kind=="city":
  txt("%s"%game.planet.species,x+20,251,17,WHITE)
  txt("%d inhabitants"%int(game.planet.population),x+20,276,13,MUTED,mono)
 else:
  txt("%.0f / %.0f extracted"%[spot.extracted,spot.reserve],x+20,253,13,MUTED,mono)
  rectangle(x+20,270,286,4,EDGE)
  rectangle(x+20,270,286*minf(1,spot.extracted/spot.reserve),4,CYAN)
 rule(x+20,297,286)
 txt("ASSIGN JOB TYPE",x+20,323,11,MUTED,mono)
 var jobs=["extractors","abductors","gunners","engineers"]
 for i in jobs.size():
  var job=jobs[i]
  button(str(i+1)+" "+job.to_upper(),Rect2(x+18+(i%2)*148,337+int(i/2)*43,141,35),"job",job,game.selected_job==job)
 txt("WORKERS TO DISPATCH",x+20,454,11,MUTED,mono)
 button("−",Rect2(x+20,469,46,38),"less")
 centered(str(game.dispatch_count),x+153,495,24,WHITE,title_font)
 button("+",Rect2(x+240,469,46,38),"more")
 txt("%d %s available"%[game.available(game.selected_job),game.selected_job],x+20,533,12,MUTED)
 button("DEPLOY   [ENTER]",Rect2(x+18,550,290,45),"deploy",null,true,game.available(game.selected_job)>0)
 var op=game.operation_for(game.selected)
 if op!=null:
  var total=0
  for job in Catalog.JOBS: total+=op.crew[job]
  var state_text="%d WORKING ON SURFACE"%total
  if op.state=="outbound": state_text="%d IN TRANSIT"%total
  if op.state=="return": state_text="%d RETURNING · %.1fs"%[total,op.travel]
  txt(state_text,x+20,626,12,GOLD,mono)
  if op.state=="return":
   rectangle(x+20,638,286,3,EDGE)
   rectangle(x+20,638,286*(1.0-op.travel/op.travel_max),3,CYAN)
  button("RECALL THIS NODE   [R]",Rect2(x+18,663,290,45),"recall",null,false,op.state!="return")
 else:
  wrapped("Crews leave their onboard stations while deployed.",x+20,631,280,15,MUTED,23)
 var deployed=game.deployed_workers()
 txt("%d WORKERS WILL BE LEFT BEHIND"%deployed if deployed>0 else "ALL WORKERS ABOARD",x,776,11,RED if deployed>0 else CYAN,mono)
 button("WARP OUT   [SPACE]",Rect2(x,791,326,45),"warp",null,true)

func _warp():
 txt("VOIDWAKE / TRANSIT",56,67,17,WHITE,mono)
 centered("FOLDSPACE ENGAGED",800,430,43,WHITE,title_font)
 centered("SIGNATURE LOST" if game.last_clean else "ISP LOOKOUT REMAINS ACTIVE",800,477,14,CYAN if game.last_clean else GOLD,mono)
 if game.last_abandoned>0:
  centered("%d DEPLOYED WORKERS LEFT BEHIND"%game.last_abandoned,800,520,13,RED,mono)

func _reward():
 rectangle(0,0,1600,900,Color(INK,0.95))
 header()
 txt("MAKE THE NEXT WORLD TREMBLE",62,164,43,WHITE,title_font)
 txt("Your haul has been sold. Choose one upgrade, or bank your credits.",64,204,18,MUTED)
 var metrics=[["AUTOMATIC SALE","+%d cr"%game.last_sale,GOLD],["SHIP COMPLEMENT",str(game.total_workers())+" workers",WHITE],["WORKERS ABANDONED",str(game.last_abandoned),RED if game.last_abandoned>0 else MUTED],["PURSUIT","TRAIL BROKEN" if game.last_clean else "LOOKOUT ACTIVE",CYAN if game.last_clean else GOLD]]
 for i in metrics.size():
  var xx=65+i*385
  txt(metrics[i][0],xx,258,11,MUTED,mono)
  txt(metrics[i][1],xx,293,25,metrics[i][2],title_font)
 for i in game.offer.size():
  var item=game.offer[i]
  var x=62+i*497
  var color=Color(item.color)
  panel(x,333,478,414)
  rectangle(x,333,478,3,color)
  symbol("signal" if item.tag in ["COMMAND","STEALTH","POPULATION"] else "system",Vector2(x+44,379),16,color)
  txt(item.tag,x+77,383,12,color,mono)
  txt("LV %d"%(game.levels.get(item.id,0)+1),x+391,383,12,MUTED,mono)
  txt(item.name,x+24,439,27,WHITE,title_font)
  txt(item.stat,x+24,479,14,color,mono)
  wrapped(item.description,x+24,526,425,18,MUTED,28)
  rule(x+24,644,430)
  button("INSTALL [%d]   ·   %d cr"%[i+1,game.offer_price],Rect2(x+23,674,432,48),"upgrade",i,true,game.credits>=game.offer_price)
 button("BANK CREDITS & CHOOSE NEXT DESTINATION  →",Rect2(849,786,685,47),"bank")
 txt("Stack upgrades to transform your ship's capabilities.",64,814,16,MUTED)

func _merchant():
 rectangle(0,0,1600,900,Color(INK,0.94))
 header()
 symbol("merchant",Vector2(97,170),27,GOLD)
 txt("THE DRIFTING EXCHANGE",150,184,44,WHITE,title_font)
 txt("A merchant has hollowed out an asteroid. No questions. Payment first.",62,246,19,MUTED)
 var entries=[["HULL RESTORATION","Recover up to 60 hull integrity.","25 cr","repair",game.credits>=25 and game.hull<game.max_hull],["COMPRESSED RECRUITS","15 workers: three of every job type.","40 cr","recruit",game.credits>=40],["EQUIPMENT CACHE","Inspect a fresh set of three upgrades.","%d cr"%(55+game.route_step*8),"cache",game.credits>=55+game.route_step*8]]
 for i in 3:
  var x=62+i*497
  panel(x,336,478,310)
  txt(entries[i][0],x+24,392,25,WHITE,title_font)
  wrapped(entries[i][1],x+24,448,425,18,MUTED,28)
  button(entries[i][2]+"   →",Rect2(x+24,568,430,50),entries[i][3],null,true,entries[i][4])
 button("RETURN TO THE FRONTIER  →",Rect2(1040,742,492,55),"map",null,true)

func _signal():
 rectangle(0,0,1600,900,Color(INK,0.94))
 header()
 symbol("signal",Vector2(800,245),39,PURPLE)
 centered("A SILENT CONVOY",800,354,52,WHITE,title_font)
 centered("An abandoned freighter. A sealed cargo hold. Ten survivors in compression.",800,411,20,MUTED)
 centered("CREDITS RECOVERED  /  +10 WORKERS  /  +15 HULL",800,478,16,CYAN,mono)
 button("CONTINUE EXPEDITION  →",Rect2(550,610,500,60),"map",null,true)

func _lost():
 rectangle(0,0,1600,900,Color(INK,0.96))
 centered("VESSEL LOST",800,292,76,WHITE,title_font)
 centered("THE ISP HAS TERMINATED YOUR EXPEDITION",800,349,14,RED,mono)
 centered("%d planetary operations   /   %d credits earned   /   %d workers abandoned"%[game.planets_visited,game.lifetime_credits,game.abandoned_total],800,445,18,MUTED)
 button("BEGIN ANOTHER EXPEDITION  →",Rect2(534,555,532,60),"new",null,true)
 centered("A different route. A different population. A different machine.",800,688,18,MUTED)

func _modal_base(x: float,y: float,w: float,h: float):
 rectangle(0,0,1600,900,Color(INK,0.94))
 buttons.clear()
 panel(x,y,w,h)

func _tutorial():
 _modal_base(325,167,950,557)
 txt("YOUR FIRST PLANETARY OPERATION",365,229,33,WHITE,title_font)
 var lines=["01  SURVEY     Orbit with A / D and Q / E. Find resource hotspots.","02  ALLOCATE   Click a deposit, choose EXTRACTORS, then DEPLOY.","03  DEFEND     Fire at incoming missiles. Deployed workers leave ship stations.","04  RECALL     Use the allocation node to bring your workers home.","05  ESCAPE     SPACE warps immediately. Unrecalled workers are abandoned."]
 for i in lines.size(): txt(lines[i],365,295+i*53,17,CYAN if i==4 else WHITE,mono)
 wrapped("Any extraction can expose you. Civilisations report an attack immediately. Leave before the ISP arrives to clear your wanted level.",365,592,860,17,GOLD,26)
 button("BEGIN SURVEY   →",Rect2(845,649,387,46),"tutorial",null,true)

func _pause():
 _modal_base(525,250,550,390)
 txt("OPERATION PAUSED",565,313,31,WHITE,title_font)
 button("RESUME",Rect2(565,355,470,52),"resume",null,true)
 button("SAVE & RETURN TO TITLE",Rect2(565,427,470,52),"save_title")
 button("AUDIO: "+("OFF" if game.muted else "ON"),Rect2(565,499,470,46),"sound")
 txt("Closing the window also saves your expedition.",565,597,14,MUTED)

func _help():
 _modal_base(200,95,1200,710)
 txt("FLIGHT MANUAL",244,157,37,WHITE,title_font)
 rule(244,180,1112)
 txt("FLIGHT & COMMAND",244,228,13,GOLD,mono)
 var controls=["A / D         Orbit left / right","Q / E         Change orbital latitude","W / S         Approach / retreat","SHIFT         Boost orbital movement","RMB + DRAG    Survey around the planet","LMB           Fire personal weapon / select site","TAB           Select next surveyed hotspot","1 / 2 / 3 / 4 Select worker job","[ / ]         Change dispatch amount","ENTER         Dispatch selected workers","R             Recall selected allocation node","SPACE         Immediate warp — leaves workers","ESC           Pause and save","M             Toggle audio"]
 for i in controls.size(): txt(controls[i],244,266+i*28,15,WHITE,mono)
 txt("KNOW YOUR OPERATION",855,228,13,GOLD,mono)
 wrapped("Resources return in courier deliveries. Only cargo in your hold is sold when you leave. Recall also returns an operation's undelivered cargo.",855,270,475,17,MUTED,26)
 wrapped("Workers have strict jobs. Gunners suppress surface defences; aboard, they operate interceptors. Deployed engineers boost extraction; aboard, they repair hull. Navigators operate warp propulsion.",855,397,475,17,MUTED,26)
 wrapped("Wanted stars warn of the police response. Leave before arrival to break the trail. An ISP arrival means overwhelming fire and a retained wanted star after escape.",855,575,475,17,GOLD,26)
 button("CLOSE MANUAL   [F1]",Rect2(986,729,370,45),"help",null,true)

func pointer_over_panel() -> bool:
 if game.help_open or game.paused or game.tutorial_open: return true
 if game.mode!="ENCOUNTER": return true
 var pos=get_global_mouse_position()
 return pos.x<310 or pos.x>1230 or pos.y<100 or pos.y>835

func _gui_input(event):
 if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT and event.pressed:
  for i in range(buttons.size()-1,-1,-1):
   var entry=buttons[i]
   if entry.rect.has_point(event.position):
    _act(entry.action,entry.payload)
    accept_event()
    queue_redraw()
    return

func _act(action: String, payload):
 if action!="warp": game.sound("select")
 match action:
  "new": game.new_run()
  "continue":
   if not game.load_run(): game.notify("Save could not be loaded.")
  "node": game.enter_node(payload)
  "planet": game.enter_planet(payload)
  "site": game.selected=payload
  "job": game.selected_job=payload
  "less": game.dispatch_count=maxi(1,game.dispatch_count-5)
  "more": game.dispatch_count=mini(500,game.dispatch_count+5)
  "deploy": game.deploy(game.selected,game.selected_job,game.dispatch_count)
  "recall": game.recall(game.selected)
  "warp": game.warp()
  "upgrade": game.choose_upgrade(payload)
  "bank": game.bank_reward()
  "help": game.help_open=not game.help_open
  "tutorial": game.tutorial_open=false
  "resume": game.paused=false
  "save_title":
   if game.save_run():
    game.paused=false
    game.mode="TITLE"
  "sound": game.toggle_sound()
  "repair": game.merchant_repair()
  "recruit": game.merchant_recruit()
  "cache": game.merchant_offer()
  "map": game.return_to_chart()
