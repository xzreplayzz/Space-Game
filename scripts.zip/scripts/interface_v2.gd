extends "res://scripts/interface.gd"

const PAPER=Color("f1e7d6")
const SOOT=Color("11191d")
const FIELD=Color("19272a")
const LINE=Color("3e5656")
const SILT=Color("a7b5ab")
const COPPER=Color("f2aa72")
const MINT=Color("a9caa8")
const LILAC=Color("cab6de")
const ALARM=Color("f28c76")
const PLEX=preload("res://assets/ui/PlexSans.ttf")
const CONDENSED=preload("res://assets/ui/PlexCondensed.ttf")
const NUMBERS=preload("res://assets/ui/PlexMono.ttf")
const EQUIPMENT={
 "hull":preload("res://assets/ui/equipment/hull.png"),
 "thruster":preload("res://assets/ui/equipment/thruster.png"),
 "repair":preload("res://assets/ui/equipment/repair.png"),
 "drill":preload("res://assets/ui/equipment/drill.png"),
 "abduct":preload("res://assets/ui/equipment/abduct.png"),
 "turret":preload("res://assets/ui/equipment/turret.png"),
 "shuttle":preload("res://assets/ui/equipment/shuttle.png"),
 "cloak":preload("res://assets/ui/equipment/cloak.png"),
 "core":preload("res://assets/ui/equipment/core.png"),
 "cargo":preload("res://assets/ui/equipment/cargo.png"),
 "link":preload("res://assets/ui/equipment/link.png"),
 "bore":preload("res://assets/ui/equipment/bore.png"),
}
const ROLES=["Extraction","Acquisition","Defence","Engineering","Navigation"]
const ROLE_COLORS=[Color("efac70"),Color("c4b1dc"),Color("d88872"),Color("a8c3a9"),Color("83b8c7")]
const SECTORS=["The Uncharted Reach","The Cinder Belt","Relay country","The Far Trade","The Ravel","Black water"]
const SPACING=263.0
const HEIGHTS=[[305,449,592],[286,404,555],[328,488,616],[280,427,583],[318,455,598],[302,414,550]]

var overlay=""
var previous_screen=""
var screen_time=1.0
var focus_index=-1
var focus_action=""
var chart_scroll=0.0
var chart_target=0.0
var chart_depth=-1
var chart_lane=-1
var chart_drag=false
var crew_role=0
var crew_page=0
var recent_crew={}
var display_volume=1.0
var text_scale=1.0
var reward_selection=0
var reward_screen=false
var settings=ConfigFile.new()

func _ready():
 super._ready()
 font=PLEX
 mono=NUMBERS
 title_font=CONDENSED
 if not game.tests_running and not "--capture" in OS.get_cmdline_user_args() and settings.load("user://interface.cfg")==OK:
  text_scale=clampf(float(settings.get_value("accessibility","text_scale",1.0)),1.0,1.3)
  display_volume=settings.get_value("audio","volume",1.0)
  AudioServer.set_bus_volume_db(0,linear_to_db(maxf(0.001,display_volume)))
  if settings.get_value("display","fullscreen",false):
   DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)

func _process(dt):
 screen_time=minf(screen_time+dt,1.0)
 chart_scroll=chart_target if _reduced_motion() else lerpf(chart_scroll,chart_target,1.0-exp(-dt*13.0))

func _visible_screen() -> String:
 if overlay!="": return overlay
 if game.help_open: return "manual"
 if game.paused: return "paused"
 if game.context_open and game.mode=="ENCOUNTER": return "allocation"
 return game.mode

func _draw():
 if game==null: return
 mouse=get_global_mouse_position()
 buttons.clear()
 if overlay=="crew" and game.mode in ["WARP","LOST","TITLE"]: _set_overlay("")
 var screen=_visible_screen()
 if game.mode=="MAP" and chart_depth<0: _center_chart();chart_scroll=chart_target
 if screen!=previous_screen:
  focus_index=-1
  screen_time=0.0
  if screen=="MAP" and previous_screen!="crew":
   _center_chart()
   chart_scroll=chart_target
  previous_screen=screen
 if game.mode=="REWARD" and not reward_screen: reward_selection=0
 reward_screen=game.mode=="REWARD"
 match game.mode:
  "TITLE": _title()
  "MAP": _map()
  "SYSTEM": _system()
  "APPROACH": _approach()
  "ENCOUNTER": _encounter()
  "WARP": _warp()
  "REWARD": _reward()
  "MERCHANT": _merchant()
  "SIGNAL": _signal()
  "LOST": _lost()
 if game.paused: _pause()
 if game.help_open: _help()
 if overlay=="crew": _crew()
 if overlay=="settings": _settings()
 if game.save_status!="": txt(game.save_status,58,869,17,ALARM)
 if screen_time<0.28 and not _reduced_motion() and screen in ["TITLE","MAP","SYSTEM","REWARD","MERCHANT","SIGNAL"]:
  rectangle(0,0,1600,900,Color(SOOT,0.45*(1.0-smoothstep(0.0,0.28,screen_time))))

func line(a: Vector2,b: Vector2,color: Color,width=1.0):
 draw_line(a,b,color,width,true)

func rule_at(x: float,y: float,w: float,color=LINE):
 line(Vector2(x,y),Vector2(x+w,y),color)

func _size(value: int) -> int:
 return roundi(value*text_scale)

func _width(value, size: int, face=null) -> float:
 var selected=font if face==null else face
 return selected.get_string_size(str(value),HORIZONTAL_ALIGNMENT_LEFT,-1,_size(size)).x

func txt(value, x: float, y: float, size=18, color=WHITE, face=null):
 draw_string(font if face==null else face,Vector2(x,y),str(value),HORIZONTAL_ALIGNMENT_LEFT,-1,_size(size),color)

func centered(value, x: float, y: float, size=18, color=WHITE, face=null):
 txt(value,x-_width(value,size,face)*0.5,y,size,color,face)

func wrapped(value: String, x: float, y: float, width: float, size=18, color=MUTED, spacing=27):
 var row=""
 var yy=y
 for word in value.split(" "):
  if row!="" and _width(row+" "+word,size)>width:
   txt(row,x,yy,size,color)
   yy+=spacing*text_scale
   row=word
  else:
   row=word if row=="" else row+" "+word
 if row!="": txt(row,x,yy,size,color)

func right(value,x: float,y: float,size=18,color=PAPER,face=null):
 var selected=font if face==null else face
 txt(value,x-_width(value,size,selected),y,size,color,selected)

func shade(rect: Rect2,a: Color,b: Color,vertical=false):
 var p=rect.position
 var q=rect.end
 var points=PackedVector2Array([p,Vector2(q.x,p.y),q,Vector2(p.x,q.y)])
 var colors=PackedColorArray([a,a,b,b]) if vertical else PackedColorArray([a,b,b,a])
 draw_polygon(points,colors)

func button(label: String,rect: Rect2,action: String,payload=null,primary=false,enabled=true):
 if enabled and focus_action==action:
  focus_index=buttons.size()
  focus_action=""
 var chosen=enabled and focus_index==buttons.size()
 var hover=enabled and (rect.has_point(mouse) or chosen)
 var ink=PAPER if enabled else Color(SILT,0.44)
 if primary:
  draw_rect(rect,(COPPER if hover else PAPER) if enabled else Color(FIELD,0.88))
  ink=SOOT if enabled else Color(SILT,0.77)
 elif hover:
  draw_rect(rect,Color(PAPER,0.08))
  line(rect.position,rect.position+Vector2(0,rect.size.y),COPPER,2)
 if chosen: draw_rect(rect.grow(3),PAPER,false,2.0)
 var width=rect.size.x-(39.0 if primary else 25.0)
 var size=22 if primary and rect.size.x>=220.0 else 19
 while size>12 and _width(label,size)>width: size-=1
 txt(label,rect.position.x+13,rect.get_center().y+_size(size)*0.36,size,ink)
 if primary and enabled:
  var p=Vector2(rect.end.x-18,rect.get_center().y)
  draw_polyline(PackedVector2Array([p+Vector2(-7,-4),p+Vector2(-3,0),p+Vector2(-7,4)]),ink,1.5,true)
 if enabled: buttons.append({"rect":rect,"action":action,"payload":payload})

func _hit(rect: Rect2,action: String,payload):
 if focus_action==action:
  focus_index=buttons.size()
  focus_action=""
 if focus_index==buttons.size(): draw_rect(rect.grow(3),PAPER,false,2.0)
 buttons.append({"rect":rect,"action":action,"payload":payload})

func _seal(p: Vector2,size: float,color: Color):
 var points=PackedVector2Array([Vector2(-1,-0.78),Vector2(-0.48,-0.78),Vector2(0,0.16),Vector2(0.48,-0.78),Vector2(1,-0.78),Vector2(0,1.0)])
 for i in points.size(): points[i]=p+points[i]*size
 draw_colored_polygon(points,color)

func _title():
 shade(Rect2(0,0,1060,900),Color("0e171b"),Color(0.06,0.09,0.11,0))
 shade(Rect2(0,650,1600,250),Color(SOOT,0),Color(SOOT,0.90),true)
 _seal(Vector2(102,147),28,COPPER)
 txt("Rook expedition",152,155,23,SILT,title_font)
 txt("VOIDWAKE",68,294,106,PAPER,title_font)
 rule_at(77,327,318,COPPER)
 wrapped("A mining vessel. A frontier worth the risk.",79,384,355,23,PAPER,32)
 if game.has_checkpoint():
  button("Continue expedition",Rect2(78,485,315,52),"continue",null,true)
  button("New expedition",Rect2(78,548,315,47),"new")
 else: button("New expedition",Rect2(78,485,315,52),"new",null,true)
 button("Settings",Rect2(78,615,149,43),"settings")
 button("Flight manual",Rect2(235,615,176,43),"help")
 txt("Cinder Reach",79,839,16,SILT)
 right("Build 0.7",1520,839,16,SILT,mono)

func _top(title: String,sub: String):
 rectangle(0,0,1600,146,SOOT)
 _seal(Vector2(78,55),14,COPPER)
 txt(sub,110,60,19,SILT)
 txt(title,62,114,51,PAPER,title_font)
 button("Crew",Rect2(1267,52,91,48),"crew")
 right("%d cr"%game.credits,1516,83,23,PAPER,mono)
 rule_at(63,143,1475)

func _chart_point(depth: int,lane: int) -> Vector2:
 var elevation=460.0 if depth==0 else float(HEIGHTS[(depth-1)%6][lane])
 return Vector2(176.0+depth*SPACING-chart_scroll,elevation)

func _atlas_field():
 shade(Rect2(0,144,1600,564),Color("28323b"),Color("151f28"),true)
 var first=maxi(0,floori(chart_scroll/SPACING)-2)
 for depth in range(first,first+11):
  var x=176+depth*SPACING-chart_scroll
  line(Vector2(x,217),Vector2(x,671),Color("344550"))
  var ink=Color("8a9ea4") if depth<=game.route_step+1 else Color("6e8189")
  if x>66 and x<1534: centered("Departure" if depth==0 else "Jump %02d"%depth,x,233,15,ink,title_font)
  for i in 13:
   var sy=253.0+fposmod(depth*87.0+i*73.0,421.0)
   var sx=x+fposmod(depth*42.0+i*51.0,257.0)
   draw_circle(Vector2(sx,sy),1.0+float(i%4==0)*0.8,Color(PAPER,0.09),true,-1,true)
  if depth%3==0:
   for band in 9:
    var ridge=PackedVector2Array()
    for step in 74:
     var t=float(step)/73.0
     var radius=1.0+0.16*cos(t*TAU*3.0+float(depth))+0.07*sin(t*TAU*7.0+depth*0.43)
     ridge.append(Vector2(x+370,414)+Vector2(cos(t*TAU)*(150+band*41.0),sin(t*TAU)*(76+band*26.0))*radius)
    draw_polyline(ridge,Color("34444f").lerp(Color("24323d"),float(band)*0.065),1.0,true)
 for y in [271,359,447,535,623]:
  line(Vector2(0,y),Vector2(1600,y),Color(PAPER,0.035))

func _path(a: Vector2,b: Vector2,color: Color,width: float,dashed=false):
 var points=PackedVector2Array()
 var x=(b.x-a.x)
 var start=a+Vector2(x*0.25,0)
 var end=b-Vector2(x*0.25,0)
 points.append(a)
 points.append(start)
 for i in range(1,10):
  points.append(start.bezier_interpolate(start+Vector2(x*0.11,0),end-Vector2(x*0.11,0),end,float(i)/10.0))
 points.append(end)
 points.append(b)
 if dashed:
  var length=0.0
  var previous=a
  for p in points:
   var segment=previous.distance_to(p)
   if segment<=0.0: continue
   var pos=0.0
   while pos<segment:
    var phase=fposmod(length+pos,15.0)
    var stride=minf(segment-pos,(6.0-phase if phase<5.999 else 15.0-phase))
    if stride<0.001: stride=minf(segment-pos,0.03)
    if phase<5.999:
     line(previous.lerp(p,pos/segment),previous.lerp(p,(pos+stride)/segment),color,width)
    pos+=stride
   previous=p
   length+=segment
 else:
  draw_polyline(points,Color("121b22"),width+4.0,true)
  draw_polyline(points,color,width,true)

func _node_symbol(kind: String,p: Vector2,ink: Color,scale=1.0):
 match kind:
  "harrow": _seal(p,15*scale,ink)
  "merchant":
   var shape=PackedVector2Array()
   for point in [Vector2(-13,-7),Vector2(13,-7),Vector2(15,2),Vector2(12,10),Vector2(-12,10),Vector2(-15,2),Vector2(-13,-7)]:
    shape.append(p+point*scale)
   draw_polyline(shape,ink,2.2,true)
   line(p+Vector2(-13,1)*scale,p+Vector2(13,1)*scale,ink,1.9)
   draw_arc(p+Vector2(0,-6)*scale,6*scale,PI,TAU,12,ink,2.0,true)
  "signal":
   for r in [9.0,15.0]: draw_arc(p,r*scale,-2.42,-0.72,18,ink,1.8,true)
   line(p+Vector2(0,-3)*scale,p+Vector2(0,9)*scale,ink,2.1)
   line(p+Vector2(-5,9)*scale,p+Vector2(5,9)*scale,ink,1.8)
  "depart":
   draw_colored_polygon(PackedVector2Array([p+Vector2(12,0),p+Vector2(-8,-10),p+Vector2(-4,0),p+Vector2(-8,10)]),ink)
  "unknown":
   draw_circle(p,3.4*scale,ink,false,1.8,true)
  _:
   draw_circle(p,7.0*scale,ink,true,-1,true)
   draw_arc(p,14*scale,-0.24,4.91,28,ink,1.65,true)
   draw_circle(p+Vector2(10,-10)*scale,3.0*scale,ink,true,-1,true)

func _route_title(depth: int,lane: int) -> String:
 if depth==0: return "Departure"
 var stored=game.route_log.get(depth,{})
 if stored.get("lane",-1)==lane and stored.has("name") and stored.get("kind")=="system": return stored.name
 if depth>game.route_step+4: return "Uncharted"
 match game.node_type(depth,lane):
  "merchant": return "Supply dock"
  "signal": return "Distress call"
 return game.node_name(depth,lane)

func _route_status(depth: int,lane: int) -> String:
 if depth==game.route_step and (depth==0 or game.lane==lane): return "current"
 if game.route_log.has(depth) and game.route_log[depth].get("lane",-1)==lane:
  return "completed" if game.route_log[depth].status=="completed" else "passed"
 if depth==game.route_step+1 and lane in game.available_routes(): return "accessible"
 if depth>game.route_step+4: return "unexplored"
 return "locked"

func _map():
 _atlas_field()
 var start=maxi(0,int((chart_scroll-180.0)/SPACING)-1)
 var stop=mini(game.route_step+16,start+10)
 for layer in 3:
  for depth in range(start,stop):
   for lane in 3:
    if depth==0 and lane!=1: continue
    if depth>0 and game.node_type(depth,lane)=="": continue
    var from=_chart_point(depth,lane)
    for next_lane in game.Route.onward(depth,lane):
     var to=_chart_point(depth+1,next_lane)
     var source=_route_status(depth,lane)
     var destination=_route_status(depth+1,next_lane)
     var open=source=="current" and destination=="accessible"
     var traveled=source in ["completed","passed","current"] and destination in ["completed","passed","current"]
     if layer==0 and not open and not traveled:
      _path(from,to,Color("586b77") if destination!="unexplored" else Color("72848c"),2.4,destination=="unexplored")
     elif layer==1 and traveled:
      _path(from,to,Color("98aaa7"),6.0)
      _path(from,to,Color("d5dcd0"),2.0)
     elif layer==2 and open:
      _path(from,to,COPPER,5.3)
      var tip=to-Vector2(38,0)
      draw_polyline(PackedVector2Array([tip+Vector2(-8,-6),tip,tip+Vector2(-8,6)]),PAPER,2.1,true)
 var shown=Vector2i(chart_depth,chart_lane)
 for depth in range(start,stop+1):
  for lane in 3:
   if depth==0 and lane!=1: continue
   var kind=game.node_type(depth,lane)
   if depth>0 and kind=="": continue
   var p=_chart_point(depth,lane)
   if p.x<35 or p.x>1564: continue
   var status=_route_status(depth,lane)
   var preferred=depth==1 and lane==1
   var ink={"current":PAPER,"completed":MINT,"passed":MINT.darkened(0.13),"accessible":COPPER,"locked":Color("a0b2b8"),"unexplored":Color("768b95")}[status]
   if kind=="signal" and status=="accessible": ink=LILAC
   var hit=Rect2(p-Vector2(53,33),Vector2(106,88))
   var over=hit.has_point(mouse)
   var selected=depth==chart_depth and lane==chart_lane
   var tile=PackedVector2Array()
   var size=30.0 if status=="current" or status=="accessible" else 23.0
   if kind=="merchant": tile=PackedVector2Array([Vector2(-size,-size*.68),Vector2(size,-size*.68),Vector2(size,size*.68),Vector2(-size,size*.68)])
   elif kind=="signal": tile=PackedVector2Array([Vector2(0,-size),Vector2(size,0),Vector2(0,size),Vector2(-size,0)])
   else:
    for i in 36: tile.append(Vector2.from_angle(float(i)*TAU/36.0)*size)
   for i in tile.size(): tile[i]+=p
   draw_colored_polygon(tile,PAPER if status=="current" else Color("1a252e"))
   tile.append(tile[0])
   draw_polyline(tile,ink,2.4 if status in ["current","accessible"] else 1.4,true)
   if selected or over:
    for side in [-1,1]:
     var corner=p+Vector2(side*(size+6),-size-5)
     draw_polyline(PackedVector2Array([corner+Vector2(-side*10,0),corner,corner+Vector2(0,10)]),PAPER,2.1,true)
   _node_symbol("depart" if depth==0 else ("unknown" if status=="unexplored" else ("harrow" if preferred else kind)),p,SOOT if status=="current" else ink,1.05)
   if status=="completed":
    draw_polyline(PackedVector2Array([p+Vector2(22,-23),p+Vector2(28,-17),p+Vector2(38,-29)]),MINT,2.4,true)
   elif status=="passed":
    rule_at(p.x+24,p.y-23,12,MINT)
   if (status!="unexplored" or over) and p.x>90 and p.x<1510:
    var name="Here · "+_route_title(depth,lane) if status=="current" else _route_title(depth,lane)
    var label_size=19 if status in ["current","accessible"] else 17
    var label_width=_width(name,label_size,title_font)+20
    rectangle(p.x-label_width*.5,p.y+34,label_width,32,Color("17212a"))
    centered(name,p.x,p.y+57,label_size,ink,title_font)
   _hit(hit,"route_preview",Vector2i(depth,lane))
 shade(Rect2(0,146,49,560),Color(SOOT,0.9),Color(SOOT,0))
 shade(Rect2(1551,146,49,560),Color(SOOT,0),Color(SOOT,0.9))
 _top("Expedition chart","Passage %02d  /  %s"%[int(game.route_step/6)+1,SECTORS[int(game.route_step/6)%SECTORS.size()]])
 line(Vector2(67,173),Vector2(104,173),MINT,4)
 txt("Travelled",115,180,17,SILT)
 line(Vector2(254,173),Vector2(291,173),COPPER,4)
 txt("Within reach",303,180,17,PAPER)
 line(Vector2(476,173),Vector2(513,173),Color("738995"),2)
 txt("Future route",524,180,17,SILT)
 rectangle(0,708,1600,192,SOOT)
 rule_at(63,707,1475)
 _chart_brief(shown.x,shown.y)
 _ledger_action("‹",Rect2(1407,155,52,43),"chart_previous")
 _ledger_action("›",Rect2(1470,155,52,43),"chart_next")
 rule_at(64,886,1472,Color(PAPER,0.12))
 rectangle(64+chart_scroll/maxf(1.0,_chart_max())*1280,884,192,3,COPPER)

func _chart_brief(depth: int,lane: int):
 var status=_route_status(depth,lane)
 var kind=game.node_type(depth,lane)
 var category="Solar system"
 var note="Survey planets on arrival for deposits, inhabitants and local risk."
 if depth==1 and lane==1: note="Harrow’s charted seams and industrial district. ISP risk 3 / 5."
 if kind=="merchant": category="Asteroid merchant";note="Repair the hull, recruit specialists or inspect an equipment cache."
 if kind=="signal": category="Distress signal";note="Investigate a transmission and recover supplies from the convoy."
 if depth==0: category="Departure";note="The Rook’s first jump into the frontier."
 if status=="unexplored": category="Uncharted";note="Survey data becomes available as you approach this region."
 var state=str({"current":"Current position","completed":"Completed","passed":"Passed through","accessible":"Within reach","locked":"Unreachable from here","unexplored":"Beyond survey range"}[status])
 _node_symbol(kind if depth>0 and status!="unexplored" else ("depart" if depth==0 else "unknown"),Vector2(84,774),COPPER if status=="accessible" else SILT,1.2)
 txt(category+"  /  "+state,119,749,18,COPPER if status=="accessible" else SILT)
 txt(_route_title(depth,lane),115,799,39,PAPER,title_font)
 txt(note,119,837,19,SILT)
 if _route_status(chart_depth,chart_lane)=="accessible":
  _ledger_action("Set course · "+_route_title(chart_depth,chart_lane),Rect2(1081,749,440,57),"node",chart_lane,true)
 elif not game.system_data.is_empty():
  _ledger_action("Return to "+game.system_data.name,Rect2(1081,749,440,57),"reopen_system",null,true)
 button("Center on current route",Rect2(1188,824,332,42),"chart_center")

func _chart_max() -> float:
 return maxf(0.0,(game.route_step+12)*SPACING)

func _center_chart():
 chart_target=maxf(0.0,(game.route_step-1.25)*SPACING)
 chart_depth=game.route_step+1
 var routes=game.available_routes()
 chart_lane=1 if 1 in routes else int(routes[0])

func _system():
 shade(Rect2(0,0,1600,148),Color(SOOT,0.91),Color(SOOT,0),true)
 shade(Rect2(0,657,1600,243),Color(SOOT,0),Color(SOOT,0.95),true)
 shade(Rect2(0,724,940,176),Color(SOOT,0.88),Color(SOOT,0.0))
 rule_at(62,725,460,Color("687572"))
 txt(game.system_data.name,60,80,46,PAPER,title_font)
 txt("%d celestial bodies"%game.system_data.planets.size(),63,111,19,SILT)
 button("Expedition chart",Rect2(1216,45,210,47),"map")
 button("Crew",Rect2(1440,45,92,47),"crew")
 var hover_body=-1
 var selected=game.destination_index
 var labels=[]
 var camera=game.world.camera
 if camera.position.length_squared()>1.0 and not camera.is_position_behind(Vector3.ZERO):
  var sun=camera.unproject_position(Vector3.ZERO)
  txt(game.system_data.get("star_name","Primary"),sun.x+45,sun.y-34,18,COPPER,title_font)
 for i in game.world.solar_planets.size():
  var position=game.world.solar_positions[i]
  if camera.is_position_behind(position): continue
  var p=camera.unproject_position(position)
  if p.x<40 or p.x>1520 or p.y<136 or p.y>725: continue
  var body=game.system_data.planets[i]
  var size=clampf(610.0*body.radius/maxf(1.0,camera.position.distance_to(position))+7.0,18,86)
  var hit=Rect2(p-Vector2(size,size),Vector2(size*2+72,size*2))
  if hit.has_point(mouse): hover_body=i
  labels.append([i,p,size,hit])
 for info in labels:
  var i=info[0]
  var p=info[1]
  var size=info[2]
  var body=game.system_data.planets[i]
  var active=i==selected or i==hover_body
  var ink=PAPER if active else Color(PAPER,0.74)
  line(p+Vector2(size,0),p+Vector2(size+17,12),ink)
  var label_x=clampf(p.x+size+22,38,1550-_width(body.name,22,title_font))
  if active:
   rectangle(label_x-7,p.y-13,_width(body.name,22,title_font)+16,38,Color(SOOT,0.88))
  txt(body.name,label_x,p.y+16,22 if active else 18,ink,title_font)
  if active:
   var track=PAPER if i==selected else COPPER
   draw_arc(p,size,-0.71,0.51,20,track,2.1 if i==selected else 1.2,true)
   draw_arc(p,size,PI-0.52,PI+0.49,20,track,2.1 if i==selected else 1.2,true)
  _hit(info[3],"inspect_body",i)
 var body=game.system_data.planets[selected]
 txt(body.name,63,766,43,PAPER,title_font)
 txt(body.landscape_name+"  ·  %d km across"%int(body.radius/500),65,801,20,PAPER)
 if body.get("sky_body",false):
  txt("Flyby body",65,835,19,SILT)
 else:
  var population="Uninhabited"
  if body.inhabited: population="%d inhabitants · Mostly %s"%[int(body.population),body.top_job]
  txt(population+"  ·  ISP risk %d / 5"%body.risk,65,835,19,SILT)
  var materials=[]
  for deposit in body.deposits:
   var name="Cobalt" if deposit.material==3 else "Ferrite"
   if not name in materials: materials.append(name)
  if not materials.is_empty(): txt("Survey estimates  ·  "+", ".join(materials),65,863,17,COPPER)
 var choice=game.system_data.planets[selected]
 if not choice.get("sky_body",false):
  _ledger_action("Body fractured" if choice.fractured else "Approach "+choice.name,Rect2(1136,779,398,54),"planet",selected,true,not choice.fractured)
 else:
  right("Flyby only · no landing sites",1534,811,22,PAPER,title_font)

func _approach():
 shade(Rect2(0,0,502,161),Color(SOOT,0.9),Color(SOOT,0),true)
 txt("Approach",62,55,18,COPPER)
 txt(game.planet.name,60,99,43,PAPER,title_font)
 rule_at(63,122,201,Color(PAPER,0.25))
 rule_at(63,122,201*clampf(game.world.approach_time/12.0,0,1),COPPER)

func _range_name(distance: float) -> String:
 return "%.1f km"%(distance/1000.0) if distance>=1000.0 else "%d m"%roundi(distance)

func _target_ticks(p: Vector2,ink: Color,scale: float,tracked=false):
 var k=12.0*scale
 var n=5.0*scale
 for side in [-1,1]:
  for vertical in [-1,1]:
   var d=Vector2(side,vertical)
   var corner=p+d*k
   var points=PackedVector2Array([corner-Vector2(n*side,0),corner,corner-Vector2(0,n*vertical)])
   draw_polyline(points,Color(SOOT,0.87),4.0 if tracked else 3.0,true)
   draw_polyline(points,ink,1.7 if tracked else 1.2,true)

func _target_plate(label: String,info: String,ink: Color):
 var width=maxf(_width(label,21,title_font),_width(info,18))+37.0
 var rect=Rect2(832,501,width,69.0*text_scale)
 draw_rect(rect,Color(SOOT,0.93))
 rectangle(rect.position.x,rect.position.y,2,rect.size.y,ink)
 txt(label,848,501+27*text_scale,21,PAPER,title_font)
 txt(info,848,501+53*text_scale,18,ink)

func _threat():
 if game.stars==0: return
 var seconds=maxi(0,ceili(game.arrival_time-game.alert_age))
 var urgent=game.police_arrived or (game.detected and seconds<=30)
 var ink=ALARM if urgent else (COPPER if game.detected else SILT)
 var title="ISP lookout"
 if game.police_arrived: title="ISP on station"
 elif game.detected: title="ISP inbound"
 var rect=Rect2(1160,36,382,60 if game.detected else 53)
 draw_rect(rect,Color("361f1d") if urgent else Color(SOOT,0.89))
 rectangle(rect.position.x,rect.position.y,3,rect.size.y,ink)
 if urgent:
  draw_circle(Vector2(1186,63),10,ink,false,1.5,true)
  centered("!",1186,69,14,ink,title_font)
 txt(title,1206 if urgent else 1181,73,23,ink,title_font)
 if game.detected and not game.police_arrived:
  for i in 5:
   var p=Vector2(1373+13*i,64)
   var star=PackedVector2Array()
   for side in 10: star.append(p+Vector2.from_angle(-PI*0.5+side*TAU/10.0)*(5.5 if side%2==0 else 2.5))
   if i<game.stars: draw_colored_polygon(star,ink)
   else:
    star.append(star[0])
    draw_polyline(star,Color(ink,0.5),1,true)
  right("%02d:%02d"%[int(seconds/60),seconds%60],1518,73,22,PAPER,mono)
 else:
  right("Level %d / 5"%game.stars,1518,73,19,PAPER,mono)
 if game.detected and not game.police_arrived:
  var width=382*clampf(float(seconds)/maxf(1.0,game.arrival_time),0.0,1.0)
  rectangle(1160,94,width,2,ink)

func _windshield(w,center: Vector2):
 var visible=Rect2(92,149,1416,505)
 var tracks=[]
 for feature in game.planet.features:
  var known=w.harrow and feature.name in ["Rook Shelf","Harrow Works"]
  var distance: float=feature.position.distance_to(w.ship_position)
  if not (known or feature.scanned) or distance>(18000.0 if known else (3550.0 if w.harrow else 2300.0)): continue
  if w.camera.is_position_behind(feature.position): continue
  var p: Vector2=w.camera.unproject_position(feature.position)
  if not visible.has_point(p): continue
  var detail=feature.type if feature.scanned or feature.kind=="city" else "Survey bearing"
  if feature.scanned and feature.has("cover"): detail+=" · %dm cover"%feature.cover
  var ink=LILAC if feature.kind=="city" else COPPER
  tracks.append({"p":p,"score":p.distance_to(center)+20.0,"label":feature.name,"detail":detail+" · "+_range_name(distance),"ink":ink,"active":false})
 for op in game.operations:
  if op.state=="complete" or not w.site_visible(op.site): continue
  var p: Vector2=w.site_screen(op.site)
  if not visible.has_point(p): continue
  var spot=game.planet.hotspots[op.site]
  var distance: float=spot.position.distance_to(w.ship_position)
  var task="Mining" if op.crew.extractors>0 else ("Abduction" if op.crew.abductors>0 else "Deployed")
  var state=str({"outbound":"Lander inbound","working":task,"return":"Crew returning","blocked":"Rig stopped"}.get(op.state,task))
  var detail=state+" · "+_range_name(distance)
  if op.state=="working" and op.crew.extractors>0:
   var material=str(spot.type).get_slice(" · ",0)
   detail=material+" · "+_range_name(distance)+" · %d/%d cuts"%[op.strokes,op.max_strokes]
  tracks.append({"p":p,"score":p.distance_to(center),"label":spot.label,"detail":detail,"ink":MINT,"active":true})
 tracks.sort_custom(func(a,b): return a.score<b.score)
 var marked=[]
 var focused=false
 for item in tracks:
  var p: Vector2=item.p
  var duplicate=false
  for previous in marked:
   if p.distance_to(previous)<32.0: duplicate=true;break
  if duplicate: continue
  if not focused and p.distance_to(center)<(166.0 if item.active else 108.0):
   focused=true
   if p.distance_to(center)>26.0: _target_ticks(p,item.ink,1.0,true)
   _target_plate(item.label,item.detail,item.ink)
  else:
   if marked.size()>=2 or p.distance_to(center)>380.0: continue
   _target_ticks(p,Color(item.ink,0.83),0.56)
  marked.append(p)
  if marked.size()==3: break
 if not focused and not w.target_hit.is_empty() and w.target_hit.has("distance"):
  var material=clampi(int(w.target_hit.get("material",0)),0,3)
  var name=preload("res://scripts/geology.gd").MATERIALS[material]
  _target_plate(name,"Surface · "+_range_name(w.target_hit.distance),SILT)
 var closest=INF
 var combat_position=Vector2.ZERO
 for entity in w.combat:
  if not is_instance_valid(entity.node) or w.camera.is_position_behind(entity.node.global_position): continue
  var p: Vector2=w.camera.unproject_position(entity.node.global_position)
  if not visible.has_point(p) or p.distance_to(center)>280.0: continue
  var distance: float=entity.node.global_position.distance_to(w.ship_position)
  if distance<closest: closest=distance;combat_position=p
 if closest<INF: _target_ticks(combat_position,ALARM,1.05,true)

func _encounter():
 var w=game.world
 var center=Vector2(800,450)
 var locked=not w.target_hit.is_empty()
 var reticle=PAPER if locked else Color(PAPER,0.76)
 var gap=10.0 if w.scan_wave<=0 else 10.0+w.scan_wave*5.0
 for side in [-1,1]:
  var a=center+Vector2(side*gap,0)
  var b=center+Vector2(side*(gap+7),0)
  line(a,b,Color(SOOT,0.87),3.4)
  line(a,b,reticle,1.3)
 draw_circle(center,1.4,reticle,true,-1,true)
 var planet_width=_width(game.planet.name,26,title_font)+39.0
 rectangle(42,36,planet_width,51,Color(SOOT,0.87))
 rectangle(42,36,2,51,COPPER)
 txt(game.planet.name,59,70,26,PAPER,title_font)
 _threat()
 if not game.context_open and overlay=="" and not game.paused and not game.help_open:
  _windshield(w,center)
 if w.scan_wave>0 and not _reduced_motion():
  draw_arc(center,(1.0-w.scan_wave)*590.0,-PI*0.13,PI*1.13,65,Color(MINT,w.scan_wave*0.37),1.3,true)
 if not game.messages.is_empty() and not game.context_open:
  var message=game.messages.back()
  var opacity=minf(message.time*2,1.0)
  var width=_width(message.text,19)
  rectangle(778-width*.5,116,width+44,40,Color(SOOT,opacity*0.93))
  centered(message.text,800,143,19,Color(PAPER,opacity))
 if game.context_open: _allocation()
 if w.hit_flash>0: rectangle(0,0,1600,900,Color(0.75,0.19,0.1,w.hit_flash*0.16))

func _site_population(spot: Dictionary) -> int:
 if str(spot.get("kind", "")) != "city": return -1
 for feature in game.planet.get("features", []):
  if str(feature.get("kind", "")) == "city" and str(feature.get("name", "")) == str(spot.get("label", "")):
   return maxi(0, int(feature.get("population", 0)))
 return -1

func _allocation():
 if game.planet.hotspots.is_empty(): return
 var site_index=clampi(game.selected,0,game.planet.hotspots.size()-1)
 var spot: Dictionary=game.planet.hotspots[site_index]
 var op=game.operation_for(site_index)
 var city=spot.get("kind", "") == "city"
 if not city and game.selected_job == "abductors": game.selected_job="extractors"
 var selected_job=str(game.selected_job)
 var available=game.available(selected_job)
 var send_count=clampi(game.dispatch_count,1,maxi(1,available))
 var population=_site_population(spot) if city else -1
 var distance=spot.position.distance_to(game.world.ship_position)
 var x=1008.0
 var y=66.0
 var w=544.0
 var h=662.0
 var accent=LILAC if city else COPPER
 draw_rect(Rect2(x,y,w,h),Color("101a1f",0.98))
 draw_rect(Rect2(x,y,w,h),Color("53686b",0.82),false,1.0)
 rectangle(x,y,4,h,accent)
 txt("FIELD DISPATCH  /  "+("POPULATION" if city else "GEOLOGY"),x+24,y+30,16,accent,mono)
 button("CREW",Rect2(x+w-111,y+12,64,32),"crew")
 button("×",Rect2(x+w-39,y+12,28,32),"close_context")
 var heading=str(spot.get("label", "Unsurveyed ground"))
 var heading_size=35
 while heading_size>22 and _width(heading,heading_size,title_font)>w-52: heading_size-=1
 txt(heading,x+24,y+70,heading_size,PAPER,title_font)
 var detail=str(spot.get("type", "Surface"))+"  ·  "+_range_name(distance)+"  ·  "+str(spot.get("status", "Ready"))
 var detail_size=16
 while detail_size>13 and _width(detail,detail_size)>w-52: detail_size-=1
 txt(detail,x+25,y+101,detail_size,SILT)
 rule_at(x+24,y+123,w-48,Color(PAPER,0.17))
 var metric_x=x+24.0
 var metric_y=y+125.0
 var metric_w=158.0
 var metric_gap=11.0
 var metric_labels=["RANGE","SITE CLASS","POPULATION" if city else "RECOVERED"]
 var site_type=str(spot.get("type", "")).to_lower()
 var site_class="POPULATION CENTRE" if city else ("SURFACE GROUND" if site_type.begins_with("regolith") or str(spot.get("label", ""))=="Unsurveyed ground" else "MINERAL DEPOSIT")
 var metric_values=[_range_name(distance),site_class,str(population) if city and population>=0 else ("UNKNOWN" if city else "%.1f"%float(spot.get("extracted",0.0)))]
 for i in 3:
  var mx=metric_x+i*(metric_w+metric_gap)
  draw_rect(Rect2(mx,metric_y,metric_w,58),Color("1b2a30"))
  txt(metric_labels[i],mx+10,metric_y+19,12,SILT,mono)
  var value_size=19
  while value_size>13 and _width(metric_values[i],value_size)>metric_w-18: value_size-=1
  txt(metric_values[i],mx+10,metric_y+43,value_size,PAPER,title_font)
 var warning=""
 if city:
  warning="Population centre · abduction exposes the vessel to an ISP response."
 elif game.planet.inhabited:
  warning="Inhabited world · extraction can expose the operation to local response."
 elif str(spot.get("label", ""))=="Unsurveyed ground":
  warning="Unsurveyed ground · no deposit signature at this point; surface material can still be excavated."
 else:
  warning="Deposit site · bore pattern controls how the crew advances through the ground."
 draw_rect(Rect2(x+24,y+190,w-48,38),Color("202a2c"))
 rectangle(x+24,y+190,3,38,accent)
 wrapped(warning,x+37,y+214,w-74,14,SILT,17)
 txt("CREW SPECIALISTS",x+24,y+252,15,PAPER,mono)
 right("AVAILABLE ABOARD",x+w-24,y+252,12,SILT,mono)
 var role_descriptions=["Bore and recover material","Collect inhabitants","Cover field operations","Improve extraction output"]
 for i in 4:
  var job=Catalog.JOBS[i]
  var role_x=x+24+float(i%2)*252.0
  var by=y+263+int(i/2)*61.0
  var rect=Rect2(role_x,by,242,54)
  var valid=job!="abductors" or city
  var role_active=selected_job==job
  var role_color=ROLE_COLORS[i]
  var fill=Color(role_color,0.16) if role_active else Color("1b292e")
  if not valid: fill=Color("151f23")
  draw_rect(rect,fill)
  draw_rect(rect,Color(role_color,0.68) if role_active else Color("46585c",0.55),false,1.0)
  if role_active: rectangle(role_x,by,3,54,role_color)
  txt(ROLES[i].to_upper(),role_x+11,by+21,15,PAPER if valid else Color(SILT,0.45),title_font)
  right("CITY ONLY" if not valid else "%d READY"%game.available(job),role_x+230,by+21,12,role_color if valid else Color(SILT,0.48),mono)
  txt(role_descriptions[i],role_x+11,by+42,12,SILT if valid else Color(SILT,0.42))
  if valid: _hit(rect,"job",job)
 rule_at(x+24,y+390,w-48,Color(PAPER,0.17))
 txt("CREW TO DISPATCH",x+24,y+417,13,SILT,mono)
 right("%d READY"%available,x+w-24,y+417,12,SILT,mono)
 button("−",Rect2(x+286,y+400,40,38),"dispatch_less",null,false,send_count>1)
 centered(str(send_count),x+378,y+426,24,PAPER,mono)
 button("+",Rect2(x+410,y+400,40,38),"dispatch_more",null,false,send_count<available)
 rule_at(x+24,y+445,w-48,Color(PAPER,0.17))
 if selected_job=="extractors":
  txt("BORE PATTERN",x+24,y+470,13,COPPER,mono)
  for i in 3:
   var pattern_x=x+24+i*160.0
   var pattern=Rect2(pattern_x,y+478,150,34)
   var pattern_active=spot.order==i
   draw_rect(pattern,Color(COPPER,0.16) if pattern_active else Color("1b292e"))
   draw_rect(pattern,Color(COPPER,0.75) if pattern_active else Color("46585c",0.55),false,1.0)
   if pattern_active: rectangle(pattern_x,pattern.end.y-3,150,3,COPPER)
   var pattern_size=15
   while pattern_size>11 and _width(game.order_names[i].to_upper(),pattern_size)>140: pattern_size-=1
   centered(game.order_names[i].to_upper(),pattern.get_center().x,pattern.position.y+22,pattern_size,PAPER if pattern_active else SILT,mono)
   _hit(pattern,"order",i)
  var radius=minf(32.0,3.4*pow(1.22,game.levels.get("bore",0))*pow(1.13,game.levels.get("core",0)))
  txt("12 cuts per pass  ·  %d cr / cut  ·  output ×%.2f"%[game.bore_cost(radius),game.extraction_multiplier()],x+24,y+525,12,SILT)
 elif selected_job=="abductors":
  txt("POPULATION RECOVERY",x+24,y+470,13,LILAC,mono)
  var pop_text="%d inhabitants currently recorded"%population if population>=0 else "Population estimate unavailable"
  wrapped(pop_text+". Abduction reduces this population and triggers an ISP response.",x+24,y+499,w-48,14,SILT,18)
 elif selected_job=="gunners":
  txt("FIELD SECURITY",x+24,y+470,13,ALARM,mono)
  wrapped("Gunners suppress local defence. Each deployed gunner delays the settlement response interval by 0.35 seconds.",x+24,y+499,w-48,14,SILT,18)
 else:
  txt("ENGINEERING SUPPORT",x+24,y+470,13,MINT,mono)
  wrapped("Each assigned engineer adds 3.5% extraction support. Synaptic Relay doubles this contribution.",x+24,y+499,w-48,14,SILT,18)
 rule_at(x+24,y+546,w-48,Color(PAPER,0.17))
 txt("SITE OPERATION",x+24,y+566,12,SILT,mono)
 var operation_summary="No crew deployed at this site."
 if op!=null:
  var total_assigned=0
  for assigned_job in Catalog.JOBS: total_assigned+=int(op.crew.get(assigned_job,0))
  operation_summary=str(op.state).to_upper()+"  ·  %d CREW ASSIGNED"%total_assigned
  if int(op.crew.get("extractors",0))>0:
   operation_summary+="  ·  %d/%d CUTS  ·  %.1f ORE PENDING"%[int(op.strokes),int(op.max_strokes),float(op.pending_ore)]
  elif int(op.crew.get("abductors",0))>0:
   operation_summary+="  ·  %.1f CAPTURES PENDING"%float(op.pending_captures)
 var summary_size=12
 while summary_size>9 and _width(operation_summary,summary_size)>w-48: summary_size-=1
 txt(operation_summary,x+24,y+586,summary_size,MINT,mono)
 if op==null:
  button("DEPLOY CREW",Rect2(x+24,y+610,w-48,42),"deploy",null,true,available>0)
 else:
  button("ADD CREW",Rect2(x+24,y+610,151,42),"deploy",null,true,available>0 and op.state!="return")
  button("EXTEND PASS",Rect2(x+184,y+610,151,42),"extend",null,false,op.state in ["complete","blocked"])
  button("RECALL",Rect2(x+344,y+610,176,42),"recall",null,false,op.state!="return")
func _crew():
 _cover()
 _seal(Vector2(96,78),20,MINT)
 txt("Rook / Crew manifest",130,86,29,PAPER,title_font)
 button("Close",Rect2(1412,50,119,48),"close_overlay")
 rule_at(73,116,1455)
 txt(str(game.total_workers()),76,262,119,PAPER,title_font)
 txt("Telepathic crew",82,297,27,PAPER)
 txt("%d aboard"%(game.total_workers()-game.deployed_workers()),82,359,25,MINT,title_font)
 txt("%d in the field"%game.deployed_workers(),82,394,22,COPPER,title_font)
 var gain=0
 for amount in recent_crew.values(): gain+=amount
 txt("+%d received this session"%gain if gain>0 else "No recent arrivals",82,450,20,SILT)
 rule_at(82,479,365)
 var descriptions=[
  "Extractors operate the boring equipment. Engineers sent with them increase output.",
  "Abductors collect new workers from inhabited locations. Recruits retain their original specialisations.",
  "Gunners operate onboard interceptors. Sending them to a location reduces onboard defence.",
  "Engineers repair the Rook aboard and support excavation when deployed.",
  "Navigators stay aboard to operate the foldspace drive and reduce warp transit time."
 ]
 wrapped(descriptions[crew_role],82,526,366,19,PAPER,29)
 var value=""
 match crew_role:
  0: value="Bore output ×%.2f"%game.extraction_multiplier()
  1: value="Acquisition ×%.2f"%pow(1.6,game.levels.get("abduct",0))
  2: value="%d intercept crew aboard"%game.available("gunners")
  3: value="%d repair crew aboard"%game.available("engineers")
  4: value="%d drive crew aboard"%game.available("navigators")
 txt(value,82,713,21,ROLE_COLORS[crew_role],title_font)
 txt("Specialisation",530,172,21,PAPER,title_font)
 for i in 3: right(["Aboard","Field","New"][i],[1328,1413,1508][i],172,17,SILT)
 for i in 5:
  var job=Catalog.JOBS[i]
  var y=192+i*78.0
  var fill=ROLE_COLORS[i]
  if crew_role==i:
   rectangle(520,y,997,71,Color(fill,0.14))
   rectangle(520,y,3,71,PAPER)
  rule_at(530,y+72,974)
  _equipment_symbol(i,Vector2(560,y+34),19,fill)
  txt(ROLES[i],596,y+42,26,PAPER,title_font)
  var share=float(game.workers[job])/maxi(1,game.total_workers())
  rectangle(798,y+33,352,5,Color(PAPER,0.09))
  rectangle(798,y+33,352*share,5,fill)
  right(str(game.available(job)),1328,y+43,22,PAPER,mono)
  right(str(game.workers[job]-game.available(job)),1413,y+43,22,COPPER,mono)
  right("+"+str(recent_crew.get(job,0)),1508,y+43,22,MINT,mono)
  _hit(Rect2(520,y,997,71),"crew_role",i)
 txt("Field assignments",530,630,25,PAPER,title_font)
 if game.operations.is_empty():
  txt("All crew are available aboard the Rook.",530,672,20,SILT)
 else:
  var pages=ceili(float(game.operations.size())/3.0)
  crew_page=mini(crew_page,pages-1)
  for i in mini(3,game.operations.size()-crew_page*3):
   var op=game.operations[crew_page*3+i]
   var spot=game.planet.hotspots[op.site]
   var y=648+i*50.0
   txt(spot.label,530,y+30,19,PAPER)
   txt(op.state.capitalize(),930,y+30,17,COPPER)
   button("Open assignment",Rect2(1117,y,211,42),"crew_assignment",op.site)
   button("Recall",Rect2(1335,y,166,42),"crew_recall",op.site,false,op.state!="return")
  if pages>1:
   right("%d / %d"%[crew_page+1,pages],1374,851,18,SILT,mono)
   button("‹",Rect2(1390,821,50,44),"crew_page",-1,false,crew_page>0)
   button("›",Rect2(1445,821,50,44),"crew_page",1,false,crew_page+1<pages)
 if game.mode=="ENCOUNTER" and not game.planet.hotspots.is_empty():
  button("Allocate at selected waypoint",Rect2(520,823,386,46),"crew_assignment",game.selected,true)
 rule_at(73,808,1455)

func _equipment_symbol(i: int,p: Vector2,s: float,color: Color):
 match i:
  0:
   for j in 3:
    var y=(float(j)-1)*s*.47
    draw_polyline(PackedVector2Array([p+Vector2(-s*.78,y-s*.18),p+Vector2(0,y+s*.23),p+Vector2(s*.78,y-s*.18)]),color,2.0,true)
  1:
   draw_arc(p,s*.68,-PI*0.92,PI*0.92,25,color,1.7,true)
   line(p+Vector2(-s*.43,0),p+Vector2(s*.42,0),color,1.4)
   draw_circle(p,s*.18,color,true,-1,true)
  2:
   var pts=PackedVector2Array([p+Vector2(-s*.63,-s*.68),p+Vector2(s*.63,-s*.68),p+Vector2(s*.51,s*.28),p+Vector2(0,s*.74),p+Vector2(-s*.51,s*.28),p+Vector2(-s*.63,-s*.68)])
   draw_polyline(pts,color,1.8,true)
   line(p-Vector2(0,s*.38),p+Vector2(0,s*.42),color,1.4)
  3:
   for j in [-1,1]: draw_arc(p+Vector2(j*s*.28,0),s*.49,-1.03,1.03,16,color,1.8,true)
   line(p-Vector2(s*.76,0),p+Vector2(s*.76,0),color,1.5)
  _: _seal(p,s*.64,color)

func _cover():
 rectangle(0,0,1600,900,SOOT)
 buttons.clear()

func _equipment(id: String, bounds: Rect2):
 var art: Texture2D=EQUIPMENT.get(id,EQUIPMENT.hull)
 var scale=minf(bounds.size.x/art.get_width(),bounds.size.y/art.get_height())
 var size=art.get_size()*scale
 draw_texture_rect(art,Rect2(bounds.get_center()-size*0.5,size),false)

func _ledger_action(label: String,rect: Rect2,action: String,payload=null,primary=false,enabled=true):
 if enabled and not primary: draw_rect(rect,Color("253339"))
 if not enabled: draw_rect(rect,Color("202b30"))
 button(label,rect,action,payload,primary,enabled)

func _reward():
 rectangle(0,0,1600,900,Color("10191e"))
 rectangle(64,47,4,100,COPPER)
 txt("ROOK  /  SERVICE DECK",91,72,16,COPPER,mono)
 txt("Equipment requisition",88,123,49,PAPER,title_font)
 txt("Review available modules and install one before the next jump.",92,155,17,SILT)
 button("CREW",Rect2(1172,54,86,42),"crew")
 draw_rect(Rect2(1280,42,255,91),Color("1c2a30"))
 txt("AVAILABLE CREDIT",1300,70,12,SILT,mono)
 right("%d cr"%game.credits,1515,112,31,PAPER,mono)
 rule_at(64,169,1472,Color("526368"))
 var from_cache=game.offer_price==55+game.route_step*8
 var source="MERCHANT CACHE" if from_cache else "PLANETARY SALE"
 var haul="—" if from_cache else "+%d cr"%game.last_sale
 var left_behind="—" if from_cache else str(game.last_abandoned)
 var trace="CLEAR" if game.last_clean else "RETAINED"
 var summary_labels=["SOURCE","HAUL RECOVERED","CREW LEFT BEHIND","ISP TRACE"]
 var summary_values=[source,haul,left_behind,trace]
 var summary_colors=[SILT,COPPER,ALARM if game.last_abandoned>0 else MINT,MINT if game.last_clean else ALARM]
 for i in 4:
  var sx=64+i*370.0
  draw_rect(Rect2(sx,187,352,59),Color("1a282e"))
  txt(summary_labels[i],sx+14,209,11,SILT,mono)
  txt(summary_values[i],sx+14,234,18,summary_colors[i],title_font)
 if game.offer.is_empty():
  txt("No equipment modules are available at this service point.",68,330,22,SILT)
  button("CONTINUE",Rect2(1332,760,190,58),"bank",null,true)
  return
 reward_selection=clampi(reward_selection,0,game.offer.size()-1)
 for i in game.offer.size():
  var candidate=game.offer[i]
  var x=64+i*496.0
  var y=270.0
  var w=472.0
  var h=432.0
  var selected=i==reward_selection
  var hover=Rect2(x,y,w,h).has_point(mouse)
  var ink=Color(candidate.color)
  var fill=Color("24343a") if selected else (Color("202d33") if hover else Color("19252b"))
  draw_rect(Rect2(x,y,w,h),fill)
  draw_rect(Rect2(x,y,w,h),ink if selected else Color("506166",0.62),false,2.0 if selected else 1.0)
  if selected: rectangle(x,y,5,h,ink)
  txt("ISSUE  0%d"%(i+1),x+22,y+31,14,ink,mono)
  right("SELECTED" if selected else "AVAILABLE",x+w-22,y+31,12,PAPER if selected else SILT,mono)
  var level=int(game.levels.get(candidate.id,0))
  txt("NEW INSTALL" if level==0 else "UPGRADE  /  LEVEL %d"%level,x+22,y+61,12,SILT,mono)
  _equipment(candidate.id,Rect2(x+22,y+76,116,99))
  var name=str(candidate.name).capitalize()
  var name_size=28
  while name_size>19 and _width(name,name_size,title_font)>w-172: name_size-=1
  txt(name,x+154,y+116,name_size,PAPER,title_font)
  txt(str(candidate.tag).to_upper(),x+155,y+145,13,ink,mono)
  rule_at(x+22,y+191,w-44,Color(ink,0.42))
  txt(str(candidate.stat).to_upper(),x+22,y+222,17,ink,title_font)
  wrapped(str(candidate.description),x+22,y+257,w-44,16,SILT,23)
  rule_at(x+22,y+359,w-44,Color("53666a",0.65))
  txt("CURRENT LEVEL",x+22,y+386,11,SILT,mono)
  txt("%02d"%level,x+22,y+416,22,PAPER,mono)
  txt("AFTER INSTALL",x+238,y+386,11,SILT,mono)
  txt("%02d"%(level+1),x+238,y+416,22,ink,mono)
  _hit(Rect2(x,y,w,h),"reward_select",i)
 var selected_item=game.offer[reward_selection]
 var shortfall=maxi(0,game.offer_price-game.credits)
 draw_rect(Rect2(64,730,1472,118),Color("1a282e"))
 rectangle(64,730,1472,1,Color("53666a"))
 txt("SELECTED FOR INSTALL",86,760,12,SILT,mono)
 var selected_name=str(selected_item.name).capitalize()
 var selected_size=26
 while selected_size>18 and _width(selected_name,selected_size,title_font)>490: selected_size-=1
 txt(selected_name,86,801,selected_size,PAPER,title_font)
 txt("LEVEL %d → %d"%[int(game.levels.get(selected_item.id,0)),int(game.levels.get(selected_item.id,0))+1],590,800,16,Color(selected_item.color),mono)
 txt("INSTALL COST",750,760,11,SILT,mono)
 txt("%d cr"%game.offer_price,750,801,25,COPPER,mono)
 txt("BALANCE AFTER",925,760,11,SILT,mono)
 if shortfall>0:
  txt("SHORT %d cr"%shortfall,925,801,18,ALARM,mono)
 else:
  txt("%d cr"%(game.credits-game.offer_price),925,801,22,MINT,mono)
 button("INSTALL MODULE",Rect2(1080,758,208,58),"upgrade",reward_selection,true,shortfall==0)
 button("CONTINUE",Rect2(1304,758,212,58),"bank")
func _merchant():
 rectangle(0,0,1600,900,Color("1b201f"))
 shade(Rect2(0,0,630,900),Color("2e2e24"),Color("1b201f"))
 txt("ASTEROID SERVICE BERTH",70,94,22,COPPER,title_font)
 txt("The Drifting",66,183,59,PAPER,title_font)
 txt("Exchange",66,244,59,PAPER,title_font)
 rule_at(70,284,427,Color("8d7660"))
 txt("Available balance",72,344,22,SILT)
 txt("%d cr"%game.credits,66,422,57,PAPER,mono)
 wrapped("A travelling dock for repairs, personnel and machinery.",72,500,394,24,PAPER,34)
 _ledger_action("Return to chart",Rect2(70,758,392,58),"map")
 button("Crew",Rect2(1412,56,110,47),"crew")
 txt("Service manifest",549,144,39,PAPER,title_font)
 var price=55+game.route_step*8
 var entries=[
  ["Hull restoration","Up to 60 hull restored.","hull",25,"repair",game.hull<game.max_hull],
  ["Compressed recruits","15 workers, three per specialisation.","abduct",40,"recruit",true],
  ["Equipment cache","Browse three upgrades. Pay when you install.","cargo",price,"cache",true]
 ]
 for i in entries.size():
  var item=entries[i]
  var y=183+i*190.0
  rule_at(549,y,973,Color("586359"))
  _equipment(item[2],Rect2(549,y+19,162,143))
  txt(item[0],730,y+63,30,PAPER,title_font)
  txt(item[1],730,y+106,20,SILT)
  var can_pay=game.credits>=item[3]
  var action="%d cr"%item[3]
  if not item[5]: action="Hull full"
  elif not can_pay: action="%d cr short"%(item[3]-game.credits)
  if item[4]=="cache" and can_pay: action="Inspect"
  _ledger_action(action,Rect2(1344,y+52,178,58),item[4],null,true,item[5] and can_pay)

func _signal():
 rectangle(0,0,1600,900,SOOT)
 _top("Distress recovered","Salvage encounter")
 for j in 9: draw_arc(Vector2(367,472),66+j*24.0,-2.35,0.17,42,Color(LILAC,0.13),1.1,true)
 _node_symbol("signal",Vector2(368,489),LILAC,4.3)
 txt("A silent convoy",738,342,49,PAPER,title_font)
 wrapped("The hold of an abandoned freighter yielded supplies and ten crew in compression.",743,392,620,24,SILT,37)
 txt("+%d credits"%(35+game.route_step*5),743,523,28,COPPER,title_font)
 txt("+10 crew",1041,523,28,MINT,title_font)
 txt("Up to +15 hull",1284,523,28,PAPER,title_font)
 rule_at(742,557,727)
 button("Continue expedition",Rect2(1138,644,332,54),"map",null,true)

func _warp():
 shade(Rect2(0,0,1600,151),Color(SOOT,0.94),Color(SOOT,0),true)
 txt("Foldspace transit",62,75,36,PAPER,title_font)
 txt("Signature cleared" if game.last_clean else "Lookout retained",64,111,18,COPPER)

func _lost():
 _cover()
 _seal(Vector2(114,204),36,ALARM)
 txt("Expedition lost",70,318,76,PAPER,title_font)
 txt("The ISP destroyed the Rook.",78,378,25,SILT)
 rule_at(79,431,1314)
 for i in 3:
  var x=80+i*475.0
  txt(str([game.planets_visited,game.lifetime_credits,game.abandoned_total][i]),x,570,60,PAPER,title_font)
  txt(["Planetary visits","Credits earned","Crew left behind"][i],x,610,23,SILT)
 button("New expedition",Rect2(79,713,339,55),"new",null,true)
 button("Return to title",Rect2(438,713,275,55),"title")

func _pause():
 buttons.clear()
 shade(Rect2(0,0,720,900),Color(SOOT,0.98),Color(SOOT,0))
 txt("Flight suspended",75,221,60,PAPER,title_font)
 txt(game.planet.get("name","Rook"),78,259,22,COPPER)
 button("Resume flight",Rect2(78,330,338,53),"resume",null,true)
 button("Crew manifest",Rect2(78,400,338,45),"crew")
 button("Settings",Rect2(78,455,338,45),"settings")
 button("Flight manual",Rect2(78,510,338,45),"help")
 button("Save and return to title",Rect2(78,570,339,48),"save_title")

func _settings():
 _cover()
 txt("Settings",65,110,59,PAPER,title_font)
 button("Close",Rect2(1380,59,152,53),"close_overlay")
 rule_at(66,141,1464)
 txt("Audio",71,225,31,PAPER,title_font)
 txt("Master volume",72,280,22,SILT)
 var width=537.0
 rectangle(581,260,width,8,LINE)
 rectangle(581,260,width*display_volume,8,COPPER)
 draw_circle(Vector2(581+width*display_volume,264),8,PAPER,true,-1,true)
 _hit(Rect2(567,232,width+28,64),"volume_slider",null)
 button("−",Rect2(1144,239,61,48),"volume_down")
 button("+",Rect2(1210,239,61,48),"volume_up")
 right("%d%%"%roundi(display_volume*100.0),1507,275,22,PAPER,mono)
 txt("Game audio",72,350,22,SILT)
 button("Muted" if game.muted else "Enabled",Rect2(581,320,294,49),"sound")
 rule_at(71,407,1454)
 txt("Display",71,472,31,PAPER,title_font)
 txt("Window mode",72,535,22,SILT)
 var fullscreen=DisplayServer.window_get_mode()==DisplayServer.WINDOW_MODE_FULLSCREEN
 button("Fullscreen" if fullscreen else "Windowed",Rect2(581,500,294,49),"fullscreen")
 txt("Reduced interface motion",72,612,22,SILT)
 button("Enabled" if _reduced_motion() else "Disabled",Rect2(581,577,294,49),"motion")
 txt("Interface text size",72,690,22,SILT)
 for i in 3:
  var scale=float([1.0,1.15,1.30][i])
  var label="%d%%"%roundi(scale*100)
  if is_equal_approx(text_scale,scale): label+=" · On"
  button(label,Rect2(581+i*159,655,142,49),"text_scale",scale,is_equal_approx(text_scale,scale))
 rule_at(71,750,1454)

func _help():
 _cover()
 txt("Flight manual",62,110,59,PAPER,title_font)
 button("Close",Rect2(1381,61,155,48),"help")
 rule_at(63,144,1473)
 var actions=[
  ["Flight", [["W A S D","Thrust and strafe"],["Mouse","Steer the Rook"],["Q / E","Descend or climb"],["Ctrl / B","Boost or latch cruise"],["X / Shift","Brake or fly with precision"],["O / Z","Orbit assistance or magnification"]]],
  ["Field operations", [["C","Survey local deposits and settlements"],["Right mouse","Allocate a crew to a waypoint"],["Left mouse","Fire the interceptor"],["P","Open the crew manifest"],["R","Recall the selected crew"],["Space / J","Warp to chart or current system"]]]
 ]
 for i in 2:
  var x=66+i*748.0
  txt(actions[i][0],x,229,32,COPPER,title_font)
  for j in actions[i][1].size():
   var y=272+j*66.0
   rule_at(x,y-14,665)
   txt(actions[i][1][j][0],x,y+17,21,PAPER,mono)
   txt(actions[i][1][j][1],x+219,y+17,20,SILT)
 txt("Routes and menus support Tab, arrow keys and Enter.",66,785,20,SILT)

func _set_overlay(next: String):
 overlay=next
 if overlay=="crew":
  crew_role=0
  crew_page=0
 game.set_context(game.context_open)

func record_arrival(job: String,count: int):
 recent_crew[job]=recent_crew.get(job,0)+count

func pointer_over_panel() -> bool:
 return overlay!="" or game.context_open or game.help_open or game.paused or game.mode!="ENCOUNTER"

func handle_keys(event: InputEventKey) -> bool:
 if not event.pressed or game.capture_path!="": return false
 if event.keycode==KEY_P and not game.help_open and game.mode in ["MAP","SYSTEM","ENCOUNTER","REWARD","MERCHANT","SIGNAL"]:
  if not event.echo: _set_overlay("" if overlay=="crew" else "crew")
  return true
 if event.keycode==KEY_ESCAPE and overlay!="":
  _set_overlay("")
  return true
 var screen=_visible_screen()
 if screen=="REWARD" and event.keycode in [KEY_1,KEY_2,KEY_3,KEY_LEFT,KEY_RIGHT]:
  var count=game.offer.size()
  if count==0: return true
  if event.keycode in [KEY_LEFT,KEY_RIGHT]:
   reward_selection=posmod(reward_selection+(-1 if event.keycode==KEY_LEFT else 1),count)
  else:
   reward_selection=mini(event.keycode-KEY_1,count-1)
  focus_action="upgrade" if game.credits>=game.offer_price else "bank"
  return true
 if screen in ["ENCOUNTER","APPROACH","WARP"]: return false
 if game.mode=="MAP" and screen=="MAP" and event.keycode in [KEY_LEFT,KEY_RIGHT]:
  chart_target=clampf(chart_target+(1 if event.keycode==KEY_RIGHT else -1)*SPACING*0.7,0,_chart_max())
  return true
 if buttons.is_empty(): return overlay!=""
 if event.keycode in [KEY_TAB,KEY_DOWN,KEY_UP]:
  var direction=-1 if event.keycode==KEY_UP or event.shift_pressed else 1
  if focus_index<0 and direction<0: focus_index=0
  for i in buttons.size():
   focus_index=posmod(focus_index+direction,buttons.size())
   var entry=buttons[focus_index]
   if entry.action=="volume_slider": continue
   if entry.action=="route_preview" and _route_status(entry.payload.x,entry.payload.y)!="accessible": continue
   break
  return true
 if event.keycode in [KEY_ENTER,KEY_KP_ENTER] and focus_index>=0 and focus_index<buttons.size():
  var entry=buttons[focus_index]
  _act(entry.action,entry.payload)
  return true
 return overlay!=""

func _gui_input(event):
 if game.capture_path!="": return
 if event is InputEventMouseMotion:
  focus_index=-1
  if chart_drag and game.mode=="MAP" and overlay=="":
   chart_target=clampf(chart_target-event.relative.x,0,_chart_max())
   accept_event()
  return
 if event is InputEventMouseButton and game.mode=="MAP" and overlay=="" and not game.help_open:
  if event.button_index in [MOUSE_BUTTON_MIDDLE,MOUSE_BUTTON_RIGHT]:
   chart_drag=event.pressed
   accept_event()
   return
  if event.pressed and event.button_index in [MOUSE_BUTTON_WHEEL_UP,MOUSE_BUTTON_WHEEL_DOWN]:
   chart_target=clampf(chart_target+(1 if event.button_index==MOUSE_BUTTON_WHEEL_DOWN else -1)*150.0,0,_chart_max())
   accept_event()
   return
 super._gui_input(event)

func _reduced_motion() -> bool:
 return settings.get_value("accessibility","reduce_motion",false)

func _save_settings():
 settings.set_value("audio","volume",display_volume)
 settings.set_value("display","fullscreen",DisplayServer.window_get_mode()==DisplayServer.WINDOW_MODE_FULLSCREEN)
 settings.save("user://interface.cfg")

func _change_volume(amount: float):
 display_volume=clampf(amount,0.0,1.0)
 AudioServer.set_bus_volume_db(0,linear_to_db(maxf(0.001,display_volume)))
 _save_settings()

func _act(action: String,payload):
 match action:
  "route_preview":
   chart_depth=payload.x;chart_lane=payload.y
   if focus_index>=0 and _route_status(chart_depth,chart_lane)=="accessible": focus_action="node"
  "chart_previous": chart_target=maxf(0,chart_target-SPACING*2.0)
  "chart_next": chart_target=minf(_chart_max(),chart_target+SPACING*2.0)
  "chart_center": _center_chart()
  "inspect_body":
   game.destination_index=payload
   if focus_index>=0 and not game.system_data.planets[payload].get("sky_body",false): focus_action="planet"
  "crew": _set_overlay("crew")
  "crew_role": crew_role=payload
  "crew_page": crew_page+=payload
  "crew_recall": game.recall(payload)
  "crew_assignment":
   if game.mode=="ENCOUNTER":
    game.selected=payload
    game.selected_job=Catalog.JOBS[mini(crew_role,3)]
    overlay=""
    game.paused=false
    game.set_context(true)
  "close_overlay": _set_overlay("")
  "settings": _set_overlay("settings")
  "volume_slider": _change_volume((mouse.x-581.0)/537.0)
  "volume_down": _change_volume(display_volume-0.1)
  "volume_up": _change_volume(display_volume+0.1)
  "fullscreen":
   var fullscreen=DisplayServer.window_get_mode()==DisplayServer.WINDOW_MODE_FULLSCREEN
   DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if fullscreen else DisplayServer.WINDOW_MODE_FULLSCREEN)
   _save_settings()
  "reward_select":
   reward_selection=int(payload)
   if focus_index>=0: focus_action="upgrade" if game.credits>=game.offer_price else "bank"
  "text_scale":
   text_scale=float(payload)
   settings.set_value("accessibility","text_scale",text_scale)
   _save_settings()
  "motion":
   settings.set_value("accessibility","reduce_motion",not _reduced_motion())
   _save_settings()
  "title": game.mode="TITLE";game.set_context(false)
  "reopen_system": game.reopen_system()
  "order": game.planet.hotspots[game.selected].order=payload
  "dispatch_less":
   var dispatch_cap_less=maxi(1,game.available(game.selected_job))
   game.dispatch_count=maxi(1,mini(game.dispatch_count,dispatch_cap_less)-5)
  "dispatch_more":
   var dispatch_cap_more=maxi(1,game.available(game.selected_job))
   game.dispatch_count=mini(dispatch_cap_more,mini(game.dispatch_count,dispatch_cap_more)+5)
  "extend": game.extend_order()
  "close_context": game.set_context(false)
  "deploy":
   game.dispatch_count=clampi(game.dispatch_count,1,maxi(1,game.available(game.selected_job)))
   if game.deploy(game.selected,game.selected_job,game.dispatch_count): game.set_context(false)
  "resume": game.paused=false;game.set_context(false)
  "help": game.help_open=not game.help_open;game.set_context(game.context_open)
  "recall": game.recall(game.selected)
  _:
   if action=="new" or action=="continue":
    overlay=""
    recent_crew.clear()
   super._act(action,payload)
   if action=="new" or action=="save_title": Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
