extends RefCounted

# Each form is [x, z, cross-section width, length, angle, height, shape].
# Positive forms build ranges and benches; negative forms cut connected basins.
# Shapes: 0 rounded hill, 1 mountain spine, 2 flat-topped escarpment.
const PROFILES=[
 {"name":"Rift valley","soil":Color("596858"),"low":Color("303f37"),"high":Color("aeb6a5"),"rock":Color("545c59"),"air":Color("799cae"),"forms":[[-1820,-2060,1510,3440,-0.17,920,1],[2080,-2380,1560,3520,0.18,1060,1],[-1480,-4700,1770,2300,-0.44,1050,1],[1750,-4950,2200,2600,0.5,920,1],[440,-2000,1160,1950,-0.25,-180,0],[-940,530,890,1250,0.38,150,0],[1510,770,940,1360,-0.5,245,0],[-1110,-2200,900,1170,-0.67,175,0],[1210,-3550,810,1300,0.72,235,1]]},
 {"name":"Sandstone mesas","soil":Color("97795a"),"low":Color("695442"),"high":Color("ba9e76"),"rock":Color("7b4937"),"air":Color("ae8d74"),"forms":[[-1730,-3120,860,1110,-0.28,660,2],[1680,-3350,930,1020,0.20,570,2],[2130,-3970,680,910,0.29,690,2],[-2660,-4540,1120,1370,-0.2,820,2],[170,-5250,1320,1250,0.38,620,2],[0,-1150,2570,380,-0.13,-88,0],[850,120,1320,1140,0.37,73,0],[-850,-2790,240,350,-0.1,214,2]]},
 {"name":"Glacial trough","soil":Color("8fa2ae"),"low":Color("506b7f"),"high":Color("dbe4e4"),"rock":Color("52626d"),"air":Color("84b7ce"),"forms":[[-1480,-2100,1400,4000,-0.19,1170,1],[1430,-2200,1280,4000,0.16,1000,1],[-1050,-4200,1600,1700,-0.52,1000,1],[950,-4700,1880,1700,0.47,1200,1],[0,-1800,1110,3100,0.05,-240,0],[-600,450,600,1500,-0.36,150,0],[850,350,740,1400,0.33,185,0]]},
 {"name":"Basalt caldera","soil":Color("555155"),"low":Color("313239"),"high":Color("827c81"),"rock":Color("3c3d47"),"air":Color("8985a2"),"forms":[[800,-3030,2900,3250,0.2,1450,0],[910,-3260,970,1160,0.2,-1070,0],[-1480,-2400,1050,2540,-0.3,490,1],[-1250,-420,780,1550,-0.3,300,1],[260,-850,640,2200,0.18,-165,0],[2100,-500,1150,1890,-0.62,270,0]]},
 {"name":"Chalk basin","soil":Color("a6a28f"),"low":Color("77796d"),"high":Color("ded8c1"),"rock":Color("898778"),"air":Color("a8b0b4"),"forms":[[0,-1550,4300,4500,0.13,950,0],[0,-1500,3400,3650,0.13,-1010,0],[-1290,-4200,900,1430,-0.47,430,2],[1650,-3930,1120,1330,0.45,420,2],[1100,-1450,970,1560,0.24,125,0],[-970,-720,950,1400,-0.64,140,0]]},
 {"name":"Wind-carved highlands","soil":Color("716678"),"low":Color("484455"),"high":Color("ac9fb4"),"rock":Color("565260"),"air":Color("8b8bb0"),"forms":[[-1350,-2200,1500,2370,-0.48,710,0],[1170,-1450,1310,2290,0.55,555,0],[-510,-4000,1730,1870,-0.55,850,1],[1410,-4600,1830,2180,0.65,670,0],[-950,-100,1040,1220,-0.55,245,0],[1060,500,1190,1950,0.7,365,0],[240,-1560,870,2390,-0.3,-240,0]]}
]

var forms=[]
var radius: float
var amplitude: float
var detail: FastNoiseLite
var continent: FastNoiseLite
var erosion: FastNoiseLite
var erosion_amount: float
var global_relief: bool
var continental_mask: FastNoiseLite
var mountain_belts: FastNoiseLite
var impact_basins: FastNoiseLite
var mountain_height: float
var authored: bool
var crater_fields=[]
var scarp_noise: FastNoiseLite
var hero_terraces=[]

func _init(body: Dictionary):
 radius=body.radius
 amplitude=body.get("landscape_relief",1.0)
 var profile=PROFILES[body.landscape]
 var scale_factor=body.get("landscape_scale",1.0)
 var yaw=body.get("landscape_yaw",0.0)
 var layout=RandomNumberGenerator.new();layout.seed=int(body.seed)+521287
 var variation=[0.11,0.30,0.15,0.18,0.18,0.24][body.landscape]
 for index in profile.forms.size():
  var form=profile.forms[index]
  # A basin or crater is a paired uplift and cut. Keep those layers registered.
  var spread=0.0 if index<2 and body.landscape in [3,4] else variation
  var offset=Vector2(layout.randf_range(-1,1)*form[2],layout.randf_range(-1,1)*form[3])*spread
  var center=(Vector2(form[0],form[1])+offset).rotated(yaw)*scale_factor
  var angle=form[4]+yaw+layout.randf_range(-spread,spread)*0.75
  var x_axis=Vector2(cos(angle),sin(angle))/(form[2]*scale_factor*layout.randf_range(1.0-spread,1.0+spread))
  var z_axis=Vector2(-sin(angle),cos(angle))/(form[3]*scale_factor*layout.randf_range(1.0-spread,1.0+spread))
  var relief=form[5]*amplitude*layout.randf_range(1.0-spread,1.0+spread)
  forms.append([center,x_axis,z_axis,relief,form[6]])
 continent=_noise(int(body.seed)+8227,0.00021,2)
 detail=_noise(int(body.seed)+443,0.00125,2)
 erosion=_noise(int(body.seed)+2173,0.00225,3)
 erosion.fractal_type=FastNoiseLite.FRACTAL_RIDGED
 erosion_amount=[0.17,0.055,0.22,0.13,0.095,0.16][body.landscape]
 global_relief=body.get("terrain_revision",0)>=4
 if global_relief:
  continental_mask=_noise(int(body.seed)+9613,3.8/radius,3)
  mountain_belts=_noise(int(body.seed)+20419,10.0/radius,3)
  mountain_belts.fractal_type=FastNoiseLite.FRACTAL_RIDGED
  impact_basins=_noise(int(body.seed)+3079,7.4/radius,1)
  impact_basins.noise_type=FastNoiseLite.TYPE_CELLULAR
  impact_basins.cellular_return_type=FastNoiseLite.RETURN_DISTANCE
  mountain_height=[1020.0,670.0,1210.0,960.0,750.0,860.0][body.landscape]*amplitude
 authored=body.get("terrain_revision",0)==5
 if authored:
  continental_mask=_noise(4117,2.6/radius,4)
  mountain_belts=_noise(25711,7.5/radius,4)
  mountain_belts.fractal_type=FastNoiseLite.FRACTAL_RIDGED
  erosion=_noise(90281,0.00039,4)
  erosion.fractal_type=FastNoiseLite.FRACTAL_RIDGED
  detail=_noise(3737,0.0048,3)
  scarp_noise=_noise(2037,0.00012,4)
  for item in [
   [Vector3(-0.48,0.89,-0.26),32200.0,3000.0],
   [Vector3(0.12,0.82,0.57),15500.0,1400.0],
   [Vector3(0.68,-0.48,-0.66),44200.0,3700.0],
   [Vector3(-0.33,-0.92,0.44),17500.0,1700.0],
   [Vector3(0.96,0.12,-0.34),7200.0,1100.0],
   [Vector3(-0.77,0.21,0.65),25300.0,2100.0]
  ]:
   var width: float=item[1]/radius
   crater_fields.append([item[0].normalized(),width*width*0.5,item[2]])
  for item in [
   [Vector2(-8500,-7500),Vector2(6200,14800),-0.36,2130.0],
   [Vector2(7900,-4700),Vector2(4700,12100),0.39,2860.0],
   [Vector2(14600,-13800),Vector2(10900,10200),0.1,2740.0],
   [Vector2(-4200,8700),Vector2(5200,4400),0.45,1020.0],
   [Vector2(0,-2700),Vector2(3300,5400),0.08,-210.0]
  ]:
   var angle: float=item[2]
   hero_terraces.append([item[0],Vector2(cos(angle),sin(angle))/item[1].x,
    Vector2(-sin(angle),cos(angle))/item[1].y,item[3]])

func _noise(seed_value: int,frequency: float,octaves: int) -> FastNoiseLite:
 var noise=FastNoiseLite.new()
 noise.seed=posmod(seed_value,2147483647)
 noise.noise_type=FastNoiseLite.TYPE_SIMPLEX_SMOOTH
 noise.frequency=frequency
 noise.fractal_octaves=octaves
 noise.fractal_type=FastNoiseLite.FRACTAL_FBM
 return noise

func height(unit: Vector3) -> float:
 var p=unit*radius
 if authored: return _hero_height(unit,p)
 var field=Vector2(p.x,p.z)+Vector2(1800,1200)*(1.0-unit.y)
 var terrain=0.0
 for form in forms:
  var local=field-form[0]
  var u=local.dot(form[1]);var v=local.dot(form[2])
  var cross=absf(u) if form[4]==1 else u*u
  var mask=1.0-cross-v*v
  terrain+=smoothstep(0.0,0.29 if form[4]==2 else 1.0,mask)*form[3]
 var gullies=erosion.get_noise_3dv(p*Vector3(0.73,0.81,1.52))
 var local_height=terrain*(1.0+gullies*erosion_amount)+continent.get_noise_3dv(p)*118.0+detail.get_noise_3dv(p)*8.0
 if not global_relief: return local_height
 var land=continental_mask.get_noise_3dv(p)
 var ridges=smoothstep(-0.55,0.92,mountain_belts.get_noise_3dv(p))
 var highlands=smoothstep(-0.24,0.43,land)
 var impact=impact_basins.get_noise_3dv(p)+1.0
 var basin=(smoothstep(0.09,0.29,impact)-1.0)*260.0
 var rim=(smoothstep(0.18,0.32,impact)-smoothstep(0.32,0.50,impact))*150.0
 var global_height=land*560.0+(ridges*ridges*mountain_height+gullies*95.0)*highlands+basin+rim
 # The surveyed landing region blends into the planet-wide field over several kilometres.
 return lerpf(global_height,local_height,smoothstep(0.76,0.94,unit.y))

func _hero_height(unit: Vector3,p: Vector3) -> float:
 var province=continental_mask.get_noise_3dv(p)
 var ridge=smoothstep(-0.55,0.78,mountain_belts.get_noise_3dv(p*Vector3(1.7,0.8,0.73)))
 var shelf=smoothstep(-0.32,0.36,province)
 var grain=erosion.get_noise_3dv(p*Vector3(0.81,1.0,1.29))
 var height_value=province*1730.0+shelf*(ridge*ridge*3870.0+grain*320.0)
 height_value+=scarp_noise.get_noise_3dv(p)*(120.0+shelf*470.0)
 for crater in crater_fields:
  var d=(1.0-unit.dot(crater[0]))/crater[1]
  height_value+=_impact_profile(d)*crater[2]
 var district=0.0
 for terrace in hero_terraces:
  var delta=Vector2(p.x,p.z)-terrace[0]
  var x=delta.dot(terrace[1]);var z=delta.dot(terrace[2])
  district+=smoothstep(0.0,0.85,1.0-x*x-z*z)*terrace[3]
 var basin_weight=smoothstep(0.995,0.9992,unit.y)
 var settled=smoothstep(2800000.0,10800000.0,p.x*p.x+p.z*p.z)
 var local=560.0+district*(1.0+grain*0.17)+grain*110.0
 var basin=lerpf(560.0,local,settled)
 return lerpf(height_value,basin,basin_weight)+detail.get_noise_3dv(p)*10.0

func _impact_profile(d: float) -> float:
 return smoothstep(0.12,0.75,d)-1.0+0.40*(smoothstep(0.64,0.96,d)-smoothstep(1.0,1.58,d))

func _op(g,kind: int,args: Array) -> Vector2i:
 var node=g.create_node(kind,Vector2.ZERO)
 for i in args.size():
  var arg=args[i]
  if arg is Vector2i: g.add_connection(arg.x,arg.y,node,i)
  else: g.set_node_default_input(node,i,float(arg))
 return Vector2i(node,0)

func _add(g,a,b) -> Vector2i: return _op(g,VoxelGraphFunction.NODE_ADD,[a,b])
func _sub(g,a,b) -> Vector2i: return _op(g,VoxelGraphFunction.NODE_SUBTRACT,[a,b])
func _mul(g,a,b) -> Vector2i: return _op(g,VoxelGraphFunction.NODE_MULTIPLY,[a,b])

func _smooth(g, value, start: float, finish: float) -> Vector2i:
 var node=_op(g,VoxelGraphFunction.NODE_SMOOTHSTEP,[value])
 g.set_node_param_by_name(node.x,"edge0",start)
 g.set_node_param_by_name(node.x,"edge1",finish)
 return node

func _noise_node(g, coordinates: Array, resource: FastNoiseLite) -> Vector2i:
 var node=_op(g,VoxelGraphFunction.NODE_NOISE_3D,coordinates)
 g.set_node_param_by_name(node.x,"noise",resource)
 return node

func density_graph(g,xyz: Array) -> int:
 var norm=_op(g,VoxelGraphFunction.NODE_NORMALIZE_3D,xyz.map(func(n):return Vector2i(n,0)))
 var projected=[]
 for axis in 3: projected.append(_mul(g,Vector2i(norm.x,axis),radius))
 if authored:
  var direction=[Vector2i(norm.x,0),Vector2i(norm.x,1),Vector2i(norm.x,2)]
  return _sub(g,_sub(g,Vector2i(norm.x,3),radius),_hero_height_graph(g,direction,projected)).x
 var hemisphere=_sub(g,1.0,Vector2i(norm.x,1))
 var px=_add(g,projected[0],_mul(g,hemisphere,1800.0))
 var pz=_add(g,projected[2],_mul(g,hemisphere,1200.0))
 var broad=_op(g,VoxelGraphFunction.NODE_NOISE_3D,projected)
 g.set_node_param_by_name(broad.x,"noise",continent)
 var small=_op(g,VoxelGraphFunction.NODE_NOISE_3D,projected)
 g.set_node_param_by_name(small.x,"noise",detail)
 var h: Variant=0.0
 for form in forms:
  var x=_sub(g,px,form[0].x);var z=_sub(g,pz,form[0].y)
  var u=_add(g,_mul(g,x,form[1].x),_mul(g,z,form[1].y))
  var v=_add(g,_mul(g,x,form[2].x),_mul(g,z,form[2].y))
  var cross=_op(g,VoxelGraphFunction.NODE_ABS,[u]) if form[4]==1 else _mul(g,u,u)
  var mask=_sub(g,_sub(g,1.0,cross),_mul(g,v,v))
  var profile=_op(g,VoxelGraphFunction.NODE_SMOOTHSTEP,[mask])
  g.set_node_param_by_name(profile.x,"edge1",0.29 if form[4]==2 else 1.0)
  h=_add(g,h,_mul(g,profile,form[3]))
 var channels=_op(g,VoxelGraphFunction.NODE_NOISE_3D,[_mul(g,projected[0],0.73),_mul(g,projected[1],0.81),_mul(g,projected[2],1.52)])
 g.set_node_param_by_name(channels.x,"noise",erosion)
 var shaped=_mul(g,h,_add(g,1.0,_mul(g,channels,erosion_amount)))
 var height_node=_add(g,shaped,_add(g,_mul(g,broad,118.0),_mul(g,small,8.0)))
 if global_relief:
  var land=_noise_node(g,projected,continental_mask)
  var ridges=_smooth(g,_noise_node(g,projected,mountain_belts),-0.55,0.92)
  var highlands=_smooth(g,land,-0.24,0.43)
  var impact=_add(g,_noise_node(g,projected,impact_basins),1.0)
  var basin=_mul(g,_sub(g,_smooth(g,impact,0.09,0.29),1.0),260.0)
  var rim=_mul(g,_sub(g,_smooth(g,impact,0.18,0.32),_smooth(g,impact,0.32,0.50)),150.0)
  var mountains=_mul(g,_mul(g,ridges,ridges),mountain_height)
  var belt=_mul(g,_add(g,mountains,_mul(g,channels,95.0)),highlands)
  var global_height=_add(g,_add(g,_mul(g,land,560.0),belt),_add(g,basin,rim))
  var blend=_smooth(g,Vector2i(norm.x,1),0.76,0.94)
  height_node=_add(g,global_height,_mul(g,_sub(g,height_node,global_height),blend))
 return _sub(g,_sub(g,Vector2i(norm.x,3),radius),height_node).x

func _hero_height_graph(g,unit: Array,p: Array) -> Vector2i:
 var province=_noise_node(g,p,continental_mask)
 var ridges=_noise_node(g,[_mul(g,p[0],1.7),_mul(g,p[1],0.8),_mul(g,p[2],0.73)],mountain_belts)
 var ridge=_smooth(g,ridges,-0.55,0.78)
 var shelf=_smooth(g,province,-0.32,0.36)
 var grain=_noise_node(g,[_mul(g,p[0],0.81),p[1],_mul(g,p[2],1.29)],erosion)
 var range_relief=_add(g,_mul(g,_mul(g,ridge,ridge),3870.0),_mul(g,grain,320.0))
 var world=_add(g,_mul(g,province,1730.0),_mul(g,shelf,range_relief))
 world=_add(g,world,_mul(g,_noise_node(g,p,scarp_noise),_add(g,120.0,_mul(g,shelf,470.0))))
 for crater in crater_fields:
  var direction: Vector3=crater[0]
  var dot_product=_add(g,_add(g,_mul(g,unit[0],direction.x),_mul(g,unit[1],direction.y)),_mul(g,unit[2],direction.z))
  var d=_mul(g,_sub(g,1.0,dot_product),1.0/crater[1])
  var pit=_sub(g,_smooth(g,d,0.12,0.75),1.0)
  var rim=_mul(g,_sub(g,_smooth(g,d,0.64,0.96),_smooth(g,d,1.0,1.58)),0.40)
  world=_add(g,world,_mul(g,_add(g,pit,rim),crater[2]))
 var district: Variant=0.0
 for terrace in hero_terraces:
  var dx=_sub(g,p[0],terrace[0].x);var dz=_sub(g,p[2],terrace[0].y)
  var x=_add(g,_mul(g,dx,terrace[1].x),_mul(g,dz,terrace[1].y))
  var z=_add(g,_mul(g,dx,terrace[2].x),_mul(g,dz,terrace[2].y))
  var mask=_sub(g,_sub(g,1.0,_mul(g,x,x)),_mul(g,z,z))
  district=_add(g,district,_mul(g,_smooth(g,mask,0.0,0.85),terrace[3]))
 var distance2=_add(g,_mul(g,p[0],p[0]),_mul(g,p[2],p[2]))
 var settled=_smooth(g,distance2,2800000.0,10800000.0)
 var local=_add(g,_mul(g,district,_add(g,1.0,_mul(g,grain,0.17))),_mul(g,grain,110.0))
 var basin=_add(g,560.0,_mul(g,local,settled))
 var height_value=_add(g,world,_mul(g,_sub(g,basin,world),_smooth(g,unit[1],0.995,0.9992)))
 return _add(g,height_value,_mul(g,_noise_node(g,p,detail),10.0))
