extends Node3D

const Catalog = preload("res://scripts/catalog.gd")
const SpaceWorld = preload("res://scripts/world_v2.gd")
const Interface = preload("res://scripts/interface_v2.gd")
const SAVE_PATH = "user://expedition-v5.save"
const PREVIOUS_SAVE = "user://expedition-v4.save"
const LEGACY_SAVE = "user://expedition-v3.save"
const Checkpoint = preload("res://scripts/run_checkpoint.gd")
const Route = preload("res://scripts/expedition_route.gd")
const Slice = preload("res://scripts/slice_system.gd")
const RUN_FIELDS = [
 "run_seed", "route_step", "lane", "route_log", "workers", "levels", "hull", "max_hull",
 "credits", "lifetime_credits", "planets_visited", "abandoned_total", "carried_stars", "mode",
 "system_data", "planet_index", "cargo", "operations", "detected", "police_arrived",
 "arrival_time", "alert_age", "encounter_age", "offer", "offer_price", "last_sale", "last_abandoned",
 "last_clean", "selected", "selected_job", "dispatch_count", "warp_destination", "destination_index",
 "detection_tick", "defence_tick"
]

var rng = RandomNumberGenerator.new()
var world
var ui
var mode = "TITLE"
var previous_mode = "ENCOUNTER"
var paused = false
var run_seed = 0
var route_step = 0
var lane = 1
var route_log = {}
var checkpoint_elapsed=0.0
var save_status=""
var system_data = {}
var planet = {}
var planet_index = 0
var workers = {}
var levels = {}
var hull = 100.0
var max_hull = 100.0
var credits = 0
var cargo = 0.0
var lifetime_credits = 0
var planets_visited = 0
var abandoned_total = 0
var last_abandoned = 0
var last_sale = 0
var last_clean = true
var selected = 0
var selected_job = "extractors"
var dispatch_count = 10
var operations = []
var detected = false
var police_arrived = false
var arrival_time = 0.0
var alert_age = 0.0
var encounter_age = 0.0
var detection_tick = 0.0
var defence_tick = 0.0
var stars = 0
var carried_stars = 0
var fire_timer = 0.0
var offer = []
var offer_price = 0
var warp_time = 0.0
var messages = []
var shot_count = 0
var muted = false
var volume = 0.65
var music
var sound_players = []
var help_open = false
var tutorial_open = false
var tests_running = false
var test_results = []
var capture_path = ""
var capture_frames = 0
var capture_started=0
var capture_target=300
var context_open=false
var destination_index=0
var warp_destination="MAP"
var order_names=["Expose", "Follow vein", "Bore tunnel"]

func _ready():
 rng.randomize()
 get_tree().auto_accept_quit = false
 world = SpaceWorld.new()
 world.game = self
 add_child(world)
 var layer = CanvasLayer.new()
 add_child(layer)
 ui = Interface.new()
 ui.game = self
 layer.add_child(ui)
 _audio_setup()
 system_data=Slice.build(2017)
 world.build_system(system_data)
 var args=OS.get_cmdline_user_args()
 if "--ui-test" in args:
  tests_running=true
  call_deferred("_ui_probe")
 elif "--self-test" in args:
  tests_running=true
  call_deferred("_self_test")
 elif "--checkpoint-write" in args or "--checkpoint-read" in args:
  tests_running=true
  call_deferred("_checkpoint_probe","--checkpoint-write" in args)
 if "--capture" in args:
  capture_started=Time.get_ticks_msec()
  capture_path=args[args.find("--capture")+1]
  if "--capture-size" in args:
   var pixels=args[args.find("--capture-size")+1].split("x")
   if pixels.size()==2:	call_deferred("_capture_viewport",Vector2i(int(pixels[0]),int(pixels[1])))
  new_run(2017)
  enter_node(1)
  var screen_name=args[args.find("--screen")+1] if "--screen" in args else "encounter"
  if "--ui-scale" in args: ui.text_scale=clampf(float(args[args.find("--ui-scale")+1])/100.0,1.0,1.30)
  capture_target=72
  if screen_name=="excavation": capture_target=300
  if screen_name=="map":
   route_log[1].status="completed"
   mode="MAP"
   enter_node(1)
   mode="MAP"
  elif screen_name in ["reward","reward-short"]:
   _demo_offers()
   credits=12 if screen_name=="reward-short" else 64
   mode="REWARD"
  elif screen_name=="system": mode="SYSTEM"
  elif screen_name=="title": mode="TITLE"
  elif screen_name=="crew": mode="MAP";ui.overlay="crew"
  elif screen_name=="settings": mode="TITLE";ui.overlay="settings"
  elif screen_name=="merchant": mode="MERCHANT";credits=115;hull=64
  elif screen_name=="signal": mode="SIGNAL";credits=51
  elif screen_name=="lost": mode="LOST"
  else:
   if "--landscape" in args:
    var landscape=int(args[args.find("--landscape")+1])
    system_data=Catalog.generate_system(node_seed(route_step,lane),0,landscape)
    world.build_system(system_data)
   enter_planet(0)
   mode="ENCOUNTER"
   world.use_local_planet(planet_index)
   if screen_name=="arrival":
    world.ship_position=world.arrival_position
    world.flight_pitch=world.arrival_pitch
   elif screen_name=="far-side":
    var far_side=Vector3(0.48,-0.77,0.42).normalized()
    world.ship_position=world.volume.geology.surface(far_side)+far_side*380.0
    world.flight_pitch=-0.24
   world._cockpit_pose()
   if screen_name=="cruise": world.cruise_boost=true;capture_target=235
   if screen_name=="hud": _demo_hud()
   if screen_name in ["allocation","excavation"]: world.scan()
   if screen_name=="excavation": call_deferred("_capture_excavation")
   elif screen_name=="allocation":
    world.target_hit={"position":planet.features[0].position,"normal":planet.features[0].normal}
    world.place_waypoint();set_context(true)
   elif screen_name=="approach": mode="APPROACH";world.approach_time=3;capture_target=120
   elif screen_name=="pause": paused=true
   elif screen_name=="manual": help_open=true

func _notification(what):
 if what==NOTIFICATION_WM_CLOSE_REQUEST:
  if mode!="TITLE" and not save_run(): return
  if world.volume!=null: await world.volume.flush()
  get_tree().quit()

func _audio_setup():
 if "--self-test" in OS.get_cmdline_user_args(): return
 music=AudioStreamPlayer.new()
 if ResourceLoader.exists("res://assets/ambience.wav"):
  music.stream=load("res://assets/ambience.wav")
  music.stream.loop_mode=AudioStreamWAV.LOOP_FORWARD
  music.stream.loop_end=int(music.stream.get_length()*music.stream.mix_rate)
  music.volume_db=-19.0
  add_child(music)
  music.play()
 for i in 8:
  var player = AudioStreamPlayer.new()
  add_child(player)
  sound_players.append(player)

func sound(name: String):
 if muted or tests_running: return
 var asset="res://assets/"+name+".wav"
 if not ResourceLoader.exists(asset): return
 for player in sound_players:
  if not player.playing:
   player.stream=load(asset)
   player.volume_db=-8.0+linear_to_db(volume)
   player.play()
   return

func toggle_sound():
 muted=not muted
 if music:
  music.volume_db=-80.0 if muted else -19.0

func new_run(seed_number=0):
 run_seed=seed_number if seed_number else int(rng.randi())
 rng.seed=run_seed
 route_step=0
 lane=1
 route_log={}
 warp_destination="MAP"
 destination_index=0
 planet_index=0
 workers={"extractors":38,"abductors":22,"gunners":20,"engineers":12,"navigators":8}
 levels={}
 hull=100.0
 max_hull=100.0
 credits=0
 cargo=0.0
 lifetime_credits=0
 planets_visited=0
 abandoned_total=0
 carried_stars=0
 stars=0
 operations.clear()
 system_data={}
 planet={}
 messages.clear()
 paused=false
 mode="MAP"
 save_run()

func node_type(depth: int, row: int) -> String:
 return Route.kind(depth,row)

func available_routes() -> Array:
 return Route.onward(route_step,lane)

func return_to_chart():
 if mode=="MERCHANT" and route_log.has(route_step): route_log[route_step].status="completed"
 mode="MAP"
 save_run()

func reopen_system():
 if mode!="MAP" or system_data.is_empty(): return
 mode="SYSTEM"
 world.build_system(system_data)
 save_run()

func node_seed(depth: int, row: int) -> int:
 return posmod(run_seed+depth*131071+row*8191,2147483647)

func node_name(depth: int, row: int) -> String:
 if depth==1 and row==1: return "Cinder Reach"
 var random=RandomNumberGenerator.new()
 random.seed=node_seed(depth,row)
 return Catalog.system_identity(random,depth-1).name

func enter_node(row: int):
 if mode!="MAP" or row not in available_routes(): return
 if route_log.has(route_step) and route_log[route_step].status=="entered":
  route_log[route_step].status="bypassed"
 lane=row
 route_step+=1
 var kind=node_type(route_step,row)
 route_log[route_step]={"lane":row,"kind":kind,"status":"entered","name":node_name(route_step,row)}
 system_data={}
 planet={}
 planet_index=0
 destination_index=0
 warp_destination="MAP"
 sound("select")
 if kind=="merchant":
  mode="MERCHANT"
  save_run()
  return
 if kind=="signal":
  credits+=35+route_step*5
  for job in Catalog.JOBS:
   workers[job]+=2
   ui.record_arrival(job,2)
  hull=minf(max_hull,hull+15.0)
  mode="SIGNAL"
  route_log[route_step].status="completed"
  save_run()
  return
 system_data=Slice.build(node_seed(route_step,row)) if route_step==1 and row==1 else Catalog.generate_system(node_seed(route_step,row),route_step-1)
 route_log[route_step].name=system_data.name
 mode="SYSTEM"
 destination_index=0
 world.build_system(system_data)
 save_run()

func enter_planet(index: int):
 if mode!="SYSTEM" or index<0 or index>=system_data.planets.size(): return
 if system_data.planets[index].get("sky_body",false): return
 if system_data.planets[index].get("fractured",false):
  notify("This world has become a debris field.")
  return
 planet_index=index
 planet=system_data.planets[index]
 selected=0
 operations.clear()
 cargo=0.0
 detected=false
 police_arrived=false
 alert_age=0.0
 encounter_age=0.0
 detection_tick=0.0
 defence_tick=0.0
 stars=carried_stars
 fire_timer=0.0
 mode="APPROACH"
 context_open=false
 paused=false
 world.build_planet(planet)
 world.begin_approach(index)
 world.clear_combat()
 tutorial_open=false
 notify("Approaching "+planet.name+" · atmospheric insertion")
 if carried_stars>0:
  notify("ISP LOOKOUT ACTIVE · extraction will expose you sooner.",Color("dfae6f"))
 sound("arrival")
 save_run()

func available(job: String) -> int:
 var n=int(workers.get(job,0))
 for op in operations: n-=int(op.crew.get(job,0))
 return maxi(0,n)

func total_workers() -> int:
 var n=0
 for job in Catalog.JOBS: n+=int(workers.get(job,0))
 return n

func deployed_workers() -> int:
 var n=0
 for op in operations:
  for job in Catalog.JOBS: n+=int(op.crew.get(job,0))
 return n

func operation_for(site: int):
 for op in operations:
  if op.site==site: return op
 return null

func deploy(site: int, job: String, count: int) -> bool:
 if mode!="ENCOUNTER" or site<0 or site>=planet.hotspots.size(): return false
 var spot=planet.hotspots[site]
 if job=="abductors" and spot.kind!="city":
  notify("Abductors require a population centre.")
  return false
 if job=="navigators":
  notify("Navigators remain aboard to operate warp propulsion.")
  return false
 if job=="extractors" and spot.kind=="city":
  notify("Excavating beneath a settlement will damage its environment.")
 var amount=mini(count,available(job))
 if amount<=0:
  notify("No available "+job+" aboard.")
  return false
 var op=operation_for(site)
 if op!=null and op.state=="return":
  notify("That operation is evacuating.")
  return false
 if op==null:
  var crew={}
  for j in Catalog.JOBS: crew[j]=0
  op={"site":site,"crew":crew,"state":"outbound","travel":travel_duration(),"travel_max":travel_duration(),"delivery":0.0,"pending_ore":0.0,"pending_captures":0.0,"launch_serial":int(rng.randi()),"age":0.0,"strokes":0,"max_strokes":12,"cut_clock":0.0,"head":spot.get("head",spot.position),"heading":spot.direction,"hardness":1.0,"order":spot.order}
  operations.append(op)
 op.crew[job]+=amount
 if op.state=="working" or op.state=="complete":
  op.state="outbound"
  op.travel=travel_duration()
  op.travel_max=op.travel
 world.volume.focus("operation-"+str(site),spot.position,false,1000)
 world.launch_effect(site,amount,false)
 notify(str(amount)+" "+job.to_upper()+" DISPATCHED",Color("79c5b5"))
 sound("launch")
 return true

func travel_duration() -> float:
 return maxf(0.8,4.5*pow(0.7,levels.get("shuttle",0)))

func recall(site: int) -> bool:
 var op=operation_for(site)
 if op==null or op.state=="return": return false
 op.state="return"
 op.travel=travel_duration()
 op.travel_max=op.travel
 world.launch_effect(site,20,true)
 notify("RECALL ORDERED · "+planet.hotspots[site].label,Color("dfae6f"))
 sound("select")
 return true

func extraction_multiplier() -> float:
 return pow(1.45,levels.get("drill",0))*pow(1.2,levels.get("link",0))*pow(1.15,levels.get("bore",0))

func damage_multiplier() -> float:
 return pow(2.4,levels.get("core",0))*pow(2.5,levels.get("bore",0))

func _process(delta):
 if tests_running: return
 var dt=minf(delta,0.05)
 for msg in messages: msg.time-=dt
 messages=messages.filter(func(m):return m.time>0.0)
 if mode=="ENCOUNTER" and not paused and not tutorial_open and not help_open:
  _encounter_step(dt)
 if mode=="WARP":
  warp_time+=dt
  if warp_time>maxf(1.35,2.92-available("navigators")*0.015): _finish_warp()
 world.step(dt if not paused and not tutorial_open and not help_open else 0.0)
 if mode=="ENCOUNTER" and not paused and capture_path=="":
  checkpoint_elapsed+=delta
  if checkpoint_elapsed>=12.0: save_run()
 ui.queue_redraw()
 if capture_path!="":
  capture_frames+=1
  if capture_frames==capture_target:
   await RenderingServer.frame_post_draw
   var shot=get_viewport().get_texture().get_image()
   var saved=shot.save_png(capture_path)
   if saved!=OK: push_error("CAPTURE_FAILED %d %s"%[saved,capture_path])
   else: print("CAPTURE_SAVED %s %s"%[capture_path,shot.get_size()])
   print("RENDER_CHECK "+JSON.stringify({"frames":capture_frames,"elapsed_ms":Time.get_ticks_msec()-capture_started,"fps":Engine.get_frames_per_second(),"draw_calls":RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)}))
   get_tree().quit()

func _encounter_step(dt: float):
 encounter_age+=dt
 fire_timer=maxf(0.0,fire_timer-dt)
 if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and not ui.pointer_over_panel() and not Input.is_key_pressed(KEY_SHIFT) and fire_timer<=0.0:
  fire(Vector2(800,450))
 _tick_operations(dt)
 if not detected:
  detection_tick+=dt
  if detection_tick>=1.0:
   detection_tick-=1.0
   var active=0
   for op in operations:
    if op.state=="working":
     for job in Catalog.JOBS: active+=op.crew[job]
   if active>0:
    var chance=0.009*planet.risk*(1.0+active/65.0)*pow(0.72,levels.get("cloak",0))*(1.0+carried_stars*0.65)
    if rng.randf()<chance: alert_police()
 else:
  alert_age+=dt
  if not police_arrived:
   stars=clampi(1+int(alert_age/maxf(1.0,arrival_time)*3.0),1,4)
   if alert_age>=arrival_time:
    police_arrived=true
    stars=5
    notify("ISP ARRIVAL · YOU HAVE BEEN IDENTIFIED · WARP NOW",Color("e9826c"))
    sound("alarm")
    world.spawn_police()
  else:
   hull-=dt*(21.0+route_step*1.3)
 if planet.inhabited and detected and not police_arrived:
  _local_defence_step(dt)
 var repair=available("engineers")*0.008*pow(3.0,levels.get("repair",0))
 hull=minf(max_hull,hull+dt*repair)
 if hull<=0.0:
  hull=0.0
  mode="LOST"
  save_run()
  sound("alarm")

func _local_defence_step(dt: float):
 if alert_age<22.0: return
 defence_tick+=dt
 var suppression=0
 for op in operations:
  if op.state in ["working","complete"]: suppression+=op.crew.gunners
 var interval=22.0-float(planet.risk)*1.25+suppression*0.35
 if defence_tick<interval: return
 defence_tick=0.0
 var fighters=0
 var missiles=0
 for hostile in world.combat:
  if hostile.type=="fighter": fighters+=1
  else: missiles+=1
 if missiles<2: world.spawn_missile()
 if alert_age>=65.0 and fighters==0 and rng.randf()<0.35: world.spawn_fighter()

func police_response_seconds(risk: int,lookout: int) -> float:
 return 210.0-15.0*clampi(risk,1,5)-15.0*clampi(lookout,0,1)

func _tick_operations(dt: float):
 var completed=[]
 for op in operations:
  op.age+=dt
  if op.state=="outbound" or op.state=="return":
   op.travel-=dt
   if op.travel<=0:
    if op.state=="return":
     _deliver(op);completed.append(op)
     world.volume.release_focus("operation-"+str(op.site))
     notify("Crew recovered · "+planet.hotspots[op.site].label)
    else: op.state="working"
   continue
  var spot=planet.hotspots[op.site]
  if op.state=="working":
   var support=1.0+op.crew.engineers*0.035*(2.0 if levels.get("link",0)>0 else 1.0)
   if op.crew.extractors>0:
    op.cut_clock+=dt
    var interval=maxf(0.30,3.0*op.hardness/(maxf(1.0,op.crew.extractors/10.0)*extraction_multiplier()*support))
    if op.cut_clock>=interval:
     var radius=minf(32.0,3.4*pow(1.22,levels.get("bore",0))*pow(1.13,levels.get("core",0)))
     var cost=bore_cost(radius)
     if credits<cost:
      op.state="blocked";spot.status="Bore energy exhausted"
      notify("Advanced bore needs %d cr per cut · recall or fund another pass"%cost)
      continue
     var direction=-spot.normal
     if op.order==1:
      var deposit=world.volume.geology.nearest_deposit(op.head)
      if deposit!=null:
       var target=deposit.centers[mini(deposit.centers.size()-1,int(op.strokes/4))]
       if target.distance_to(op.head)>radius: direction=(target-op.head).normalized()
     elif op.order==2:
      direction=(op.heading-spot.normal*0.3).normalized()
     var center=op.head+direction*radius*0.62
     world.volume.focus("operation-"+str(op.site),center,false,1000)
     var result=world.volume.excavate(center,radius)
     if result.ready:
      op.cut_clock=0
      op.head=center;spot.head=center
      op.strokes+=1
      op.hardness=maxf(0.65,result.get("hardness",1.0))
      op.pending_ore+=result.yield
      spot.extracted+=result.yield
      for m in 4: spot.materials[m]+=result.get("materials",[0,0,0,0])[m]
      if result.volume>0:
       credits-=cost
       world.excavation_effect(center,radius)
       world.settlement_damage(center,radius)
       if planet.inhabited: alert_police()
       if op.strokes%4==0: world.volume.detach_local(center,minf(26.0,radius*4))
      _check_fracture(center)
      if op.strokes>=op.max_strokes:
       op.state="complete";spot.status="Pass complete"
       _deliver(op)
       notify("Excavation pass complete · inspect, extend or recall")
   if op.crew.abductors>0 and spot.kind=="city":
    var city=null
    for feature in planet.features:
     if feature.kind=="city" and feature.position.distance_to(spot.position)<feature.radius: city=feature;break
    if city!=null and city.population>0:
     alert_police()
     var count=minf(city.population,dt*op.crew.abductors*0.075*pow(1.6,levels.get("abduct",0))*pow(1.2,levels.get("link",0)))
     city.population-=count;planet.population=maxf(0,planet.population-count)
     op.pending_captures+=count
     if op.age>24.0: op.state="complete";_deliver(op);notify("Abduction pass complete · recall crew")
   if op.crew.gunners>0 and planet.inhabited: alert_police()
  op.delivery+=dt
  if op.delivery>=5.0:
   op.delivery=0.0
   _deliver(op)
   if op.state=="working": world.launch_effect(op.site,4,true)
 for op in completed: operations.erase(op)

func extend_order():
 var op=operation_for(selected)
 if op==null or op.state not in ["complete","blocked"]: return
 op.state="working";op.strokes=0;op.age=0.0
 op.order=planet.hotspots[selected].order
 notify("New bounded excavation pass ordered")

func bore_cost(radius: float) -> int:
 return int(ceil(pow(maxf(0,radius-7.0),2)*0.08))

func _check_fracture(center: Vector3):
 if levels.get("core",0)<3 or levels.get("bore",0)<3 or world.shattered: return
 var depth=-world.volume.geology.base_sdf(center)
 if depth<planet.radius*0.06: return
 if not planet.has("fracture_sectors"): planet.fracture_sectors=[]
 var normal=center.normalized()
 var sector=int((atan2(normal.z,normal.x)+PI)/TAU*8)%8+ (8 if normal.y>0 else 0)
 if sector not in planet.fracture_sectors:
  planet.fracture_sectors.append(sector)
  notify("Deep crustal fault opened · %d / 8 sectors destabilised"%planet.fracture_sectors.size())
 if planet.fracture_sectors.size()>=8:
  world.shatter_planet()
  for op in operations:
   if op.state!="return": recall(op.site)
  notify("Crustal network failed · planetary fragmentation",Color("dfae6f"))
  sound("fracture")

func _deliver(op):
 cargo+=op.pending_ore
 op.pending_ore=0.0
 var count=int(op.pending_captures)
 op.pending_captures-=count
 for i in count:
  var roll=rng.randf()
  var cumulative=0.0
  for job in Catalog.JOBS:
   cumulative+=planet.skills[job]
   if roll<=cumulative:
    workers[job]+=1
    ui.record_arrival(job,1)
    break

func alert_police():
 if detected: return
 detected=true
 alert_age=0.0
 arrival_time=police_response_seconds(planet.risk,carried_stars)
 stars=maxi(1,carried_stars)
 notify("DISTRESS REPORT RECEIVED" if planet.inhabited else "EXTRACTION SIGNATURE DETECTED",Color("dfae6f"))
 sound("alert")

func damage(amount: float):
 if mode!="ENCOUNTER": return
 hull=maxf(0.0,hull-amount)
 world.hit_flash=0.5
 sound("impact")
 if hull<=0.0:
  mode="LOST"
  save_run()

func fire(screen_position: Vector2):
 if mode!="ENCOUNTER" or paused or tutorial_open: return
 fire_timer=0.18
 shot_count+=1
 world.fire_at(screen_position)
 sound("shot")

func warp(destination="MAP"):
 if mode!="ENCOUNTER" or paused or tutorial_open: return
 warp_destination=destination
 context_open=false
 if world.volume!=null: world.volume.save_edits()
 last_clean=not police_arrived
 carried_stars=0 if last_clean else 1
 stars=carried_stars
 last_abandoned=deployed_workers()
 for op in operations:
  for job in Catalog.JOBS: workers[job]=maxi(0,workers[job]-int(op.crew[job]))
 abandoned_total+=last_abandoned
 operations.clear()
 last_sale=int(cargo*3.0*pow(1.35,levels.get("cargo",0)))
 credits+=last_sale
 lifetime_credits+=last_sale
 cargo=0.0
 planets_visited+=1
 planet.visited=true
 if route_log.has(route_step): route_log[route_step].status="completed"
 offer=Catalog.upgrade_offer(rng,levels)
 offer_price=25+route_step*8
 mode="WARP"
 warp_time=0.0
 world.begin_warp()
 sound("warp")
 save_run()

func _finish_warp():
 mode="REWARD"
 world.end_warp()
 save_run()

func choose_upgrade(index: int) -> bool:
 if mode!="REWARD" or index<0 or index>=offer.size(): return false
 if credits<offer_price:
  notify("Insufficient credits. Bank this haul and continue.")
  return false
 credits-=offer_price
 apply_upgrade(offer[index].id)
 _after_reward()
 sound("upgrade")
 save_run()
 return true

func apply_upgrade(id: String):
 levels[id]=int(levels.get(id,0))+1
 if id=="hull":
  max_hull+=40.0
  hull=minf(max_hull,hull+40.0)

func _after_reward():
 mode=warp_destination
 if mode=="SYSTEM":
  world.build_system(system_data)
  if not last_clean: system_data.alert={"lookout":true}

func bank_reward():
 _after_reward()
 save_run()

func merchant_repair():
 if credits<25 or hull>=max_hull: return
 credits-=25
 hull=minf(max_hull,hull+60.0)
 sound("collect")
 save_run()

func merchant_recruit():
 if credits<40: return
 credits-=40
 for job in Catalog.JOBS:
  workers[job]+=3
  ui.record_arrival(job,3)
 sound("collect")
 save_run()

func merchant_offer():
 var cost=55+route_step*8
 if credits<cost: return
 mode="REWARD"
 warp_destination="MAP"
 if route_log.has(route_step): route_log[route_step].status="completed"
 offer=Catalog.upgrade_offer(rng,levels)
 offer_price=cost
 last_sale=0
 last_abandoned=0
 last_clean=carried_stars==0
 save_run()

func notify(message: String, color=Color("c6cbd0")):
 messages.append({"text":message,"time":5.0,"color":color})
 if messages.size()>3: messages.pop_front()

func set_context(opened: bool):
 context_open=opened
 var pointer_open=opened or (ui!=null and ui.overlay!="")
 if pointer_open and world!=null: world.cruise_boost=false;world.boost_active=false;world.ship_velocity=Vector3.ZERO
 Input.mouse_mode=Input.MOUSE_MODE_VISIBLE if pointer_open or paused or help_open or mode!="ENCOUNTER" else Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event):
 if capture_path!="": return
 if event is InputEventKey and ui.handle_keys(event):
  get_viewport().set_input_as_handled()
  return
 if ui.overlay!="": return
 if event is InputEventKey and event.pressed and not event.echo:
  if event.keycode==KEY_F1: help_open=not help_open;set_context(context_open);return
  if event.keycode==KEY_M: toggle_sound();return
  if event.keycode==KEY_ESCAPE:
   if help_open: help_open=false
   elif context_open: set_context(false)
   elif mode=="ENCOUNTER": paused=not paused
   set_context(context_open)
   return
  if mode=="ENCOUNTER" and not paused and not help_open:
   match event.keycode:
    KEY_SPACE: warp()
    KEY_J: warp("SYSTEM")
    KEY_C: world.scan()
    KEY_O: world.orbit_assist=not world.orbit_assist
    KEY_B:
     if not context_open: world.cruise_boost=not world.cruise_boost
    KEY_R: recall(selected)
    KEY_TAB:
     if not planet.hotspots.is_empty(): selected=(selected+1)%planet.hotspots.size();set_context(true)
    KEY_ENTER: deploy(selected,selected_job,dispatch_count)
 if event is InputEventMouseMotion:
  if mode=="ENCOUNTER" and not context_open and not paused and not help_open: world.steer(event.relative)
  elif mode=="SYSTEM" and (Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT) or Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)):
   world.view_yaw-=event.relative.x*0.004
   world.view_pitch=clampf(world.view_pitch+event.relative.y*0.004,0.1,1.45)
 if event is InputEventMouseButton and event.pressed:
  if mode=="ENCOUNTER" and not paused and not help_open:
   if event.button_index==MOUSE_BUTTON_RIGHT:
    if context_open: set_context(false)
    else:
     if world.place_waypoint(): set_context(true)
   elif event.button_index==MOUSE_BUTTON_LEFT and event.shift_pressed: world.scan()
  elif mode=="SYSTEM":
   if event.button_index==MOUSE_BUTTON_WHEEL_UP: world.system_zoom=maxf(0.4,world.system_zoom*0.9)
   elif event.button_index==MOUSE_BUTTON_WHEEL_DOWN: world.system_zoom=minf(2.5,world.system_zoom*1.1)

func has_checkpoint() -> bool:
 for path in [SAVE_PATH,SAVE_PATH+".bak",SAVE_PATH+".tmp",PREVIOUS_SAVE,PREVIOUS_SAVE+".bak",LEGACY_SAVE]:
  if FileAccess.file_exists(path): return true
 return false

func save_run(save_path=SAVE_PATH) -> bool:
 if (tests_running or capture_path!="") and save_path==SAVE_PATH: return true
 checkpoint_elapsed=0.0
 var data={"version":4,"rng_state":rng.state}
 for field in RUN_FIELDS: data[field]=get(field)
 data["ship_position"]=world.ship_position
 data["ship_velocity"]=world.ship_velocity
 data["flight_yaw"]=world.flight_yaw
 data["flight_pitch"]=world.flight_pitch
 data["orbit_assist"]=world.orbit_assist
 data["system_clock"]=world.clock
 data["system_view"]=Vector3(world.view_yaw,world.view_pitch,world.system_zoom)
 if data.mode=="APPROACH":
  data.mode="ENCOUNTER"
  data.ship_position=world.arrival_position
  data.flight_pitch=world.arrival_pitch
  data.ship_velocity=Vector3.ZERO
 if data.mode=="WARP": data.mode="REWARD"
 if world.volume!=null: world.volume.save_edits()
 var error=Checkpoint.write(save_path,data)
 save_status="" if error==OK else "Checkpoint failed · "+error_string(error)
 if error!=OK: push_warning(save_status)
 return error==OK

func load_run(save_path=SAVE_PATH) -> bool:
 var data=Checkpoint.read(save_path)
 if data.is_empty(): data=Checkpoint.read(save_path+".bak")
 if data.is_empty(): data=Checkpoint.read(save_path+".tmp")
 if data.is_empty() and save_path==SAVE_PATH:
  for path in [PREVIOUS_SAVE,PREVIOUS_SAVE+".bak",LEGACY_SAVE]:
   data=Checkpoint.read(path)
   if not data.is_empty(): break
 if data.is_empty():
  save_status="Could not read the expedition checkpoint."
  return false
 route_log={}
 for property in RUN_FIELDS:
  if data.has(property): set(property,data[property])
 if data.version==3 and route_step>0:
  var roll=posmod(run_seed+route_step*17+lane*23,13)
  var kind="system"
  if route_step>1:
   if roll in [0,7]: kind="merchant"
   elif roll==3: kind="signal"
  if kind!="system":
   system_data={}
   warp_destination="MAP"
  var completed=mode in ["REWARD","SIGNAL"] or (mode=="MAP" and kind!="system")
  for body in system_data.get("planets",[]): completed=completed or body.get("visited",false)
  route_log[route_step]={"lane":lane,"kind":kind,"status":"completed" if completed else "entered","name":system_data.get("name",node_name(route_step,lane))}
 rng.seed=run_seed
 rng.state=data.get("rng_state",rng.state)
 paused=false
 tutorial_open=false
 stars=carried_stars
 planet={}
 world.clock=data.get("system_clock",0.0)
 world.orbit_assist=data.get("orbit_assist",true)
 var view=data.get("system_view",Vector3(0.25,0.72,1.0))
 world.view_yaw=view.x
 world.view_pitch=view.y
 world.system_zoom=view.z
 if system_data.has("planets") and planet_index>=0 and planet_index<system_data.planets.size():
  destination_index=clampi(destination_index,0,system_data.planets.size()-1)
  planet=system_data.planets[planet_index]
  if mode in ["SYSTEM","ENCOUNTER"]: world.build_system(system_data)
  if mode=="ENCOUNTER":
   world.clear_combat()
   world.build_planet(planet)
   world.ship_position=data.get("ship_position",world.surface_start)
   world.ship_velocity=data.get("ship_velocity",Vector3.ZERO)
   world.flight_yaw=data.get("flight_yaw",0.0)
   world.flight_pitch=data.get("flight_pitch",world.flight_pitch)
   world.use_local_planet(planet_index)
   world._cockpit_pose()
   for op in operations:
    world.volume.focus("operation-"+str(op.site),planet.hotspots[op.site].position,false,1000)
   if police_arrived: world.spawn_police()
 set_context(false)
 checkpoint_elapsed=0.0
 save_status=""
 return true

func _assert_test(condition: bool, label: String):
 test_results.append({"test":label,"passed":condition})
 print(("PASS " if condition else "FAIL ")+label)

func _checkpoint_probe(write: bool):
 const ARRIVAL_TEST="user://qa-v4-arrival.save"
 const DEPARTURE_TEST="user://qa-v4-departure.save"
 if write:
  new_run(56173)
  enter_node(1)
  enter_planet(0)
  _assert_test(save_run(ARRIVAL_TEST),"checkpoint an interrupted approach")
  world._approach_step(12.0)
  cargo=12.0
  workers.extractors-=3
  warp("SYSTEM")
  _assert_test(mode=="WARP" and save_run(DEPARTURE_TEST),"checkpoint a departure before the animation finishes")
 else:
  _assert_test(load_run(ARRIVAL_TEST) and mode=="ENCOUNTER" and route_step==1 and route_log[1].status=="entered","restart restores the active system and visited route")
  _assert_test(world.volume!=null and world.volume.geology.base_sdf(world.ship_position)>8000.0,"restart resumes above the atmosphere")
  _assert_test(load_run(DEPARTURE_TEST) and mode=="REWARD" and credits==36 and workers.extractors==35,"restart preserves sold cargo and crew after departure")
  _assert_test(offer.size()==3 and route_log[1].status=="completed" and planet.visited,"restart retains offers and completed destinations")
  bank_reward()
  _assert_test(mode=="SYSTEM" and planet.visited and available_routes()==[1,2],"banking the saved reward returns to the same system with valid onward routes")
 var failures=test_results.filter(func(test):return not test.passed).size()
 get_tree().quit(1 if failures else 0)

func _capture_excavation():
 for i in 120: await get_tree().process_frame
 var spot=planet.features[0]
 world.target_hit={"position":spot.position,"normal":spot.normal}
 world.place_waypoint()
 deploy(0,"extractors",18)
 _tick_operations(5)
 for i in 12:
  _tick_operations(8)
  await get_tree().process_frame

func _self_test():
 await preload("res://scripts/integration_tests.gd").new().run(self)


func _demo_offers():
 offer=[]
 for id in ["hull","thruster","repair"]:
  for item in Catalog.UPGRADES:
   if item.id==id: offer.append(item)
 offer_price=33
 last_sale=12
 last_clean=true

func _demo_hud():
 var spot: Vector3=planet.features[0].position
 var up=(spot+Vector3.BACK*1800.0).normalized()
 world.ship_position=world.volume.geology.surface(up)+up*670.0
 var aim=(spot-(world.ship_position+up*30.0)).normalized()
 world.flight_pitch=asin(aim.dot(up))
 world.flight_yaw=Vector3.FORWARD.slide(up).normalized().signed_angle_to(aim.slide(up).normalized(),up)
 world._cockpit_pose()
 world.scan()
 for i in 4:
  var feature=planet.features[i]
  world.target_hit={"position":feature.position,"normal":feature.normal}
  world.place_waypoint()
  deploy(i,"extractors",3)
  var op=operation_for(i)
  if op==null: continue
  op.state="working" if i==0 else "complete"
  op.strokes=7 if i==0 else 12
  op.cut_clock=-30
  if i==0: planet.hotspots[i].extracted=4.3
 selected=0
 hull=92
 stars=2
 detected=true
 arrival_time=150.0
 alert_age=123.0
 messages.clear()

func _ui_probe():
 await preload("res://scripts/ui_probe.gd").new().run(self)


func _capture_viewport(pixels: Vector2i):
 # The desktop can clamp an oversized native window. Capture the release
 # scene at the exact requested pixels without changing the monitor mode.
 var target=SubViewport.new()
 target.size=pixels
 target.size_2d_override=Vector2i(1600,900)
 target.size_2d_override_stretch=true
 target.msaa_3d=get_viewport().msaa_3d
 target.render_target_update_mode=SubViewport.UPDATE_ALWAYS
 get_tree().root.add_child(target)
 reparent(target)
