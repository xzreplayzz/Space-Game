extends Node3D
const Geology=preload("res://scripts/geology.gd")
var data: Dictionary
var geology
var terrain: VoxelLodTerrain
var tool
var viewers={}
var stream
var replay_queue=[]
var replay_index=0
var store_path=""
var ready_seconds=0.0

func setup(body: Dictionary, save_folder: String):
 data=body
 if not data.has("edits"): data.edits=[]
 geology=Geology.new(data)
 terrain=VoxelLodTerrain.new()
 terrain.name="EditablePlanet"
 terrain.visible=false
 terrain.lod_count=11
 terrain.lod_distance=56.0
 terrain.secondary_lod_distance=48.0
 terrain.view_distance=70000
 terrain.mesh_block_size=16
 terrain.collision_lod_count=3
 terrain.collision_margin=0.01
 terrain.collision_update_delay=60
 terrain.streaming_system=VoxelLodTerrain.STREAMING_SYSTEM_LEGACY_OCTREE
 terrain.threaded_update_enabled=false
 terrain.cache_generated_blocks=false
 terrain.full_load_mode_enabled=true
 terrain.voxel_bounds=AABB(Vector3.ONE*-32768.0,Vector3.ONE*65536.0)
 var harrow=data.get("terrain_revision",0)==5
 if harrow:
  terrain.lod_count=6
  terrain.mesh_block_size=32
  terrain.lod_distance=67.0
  terrain.view_distance=950
  terrain.voxel_bounds=AABB(Vector3.ONE*-262144.0,Vector3.ONE*524288.0)
 var format=VoxelFormat.new()
 format.indices_depth=VoxelBuffer.DEPTH_8_BIT
 format.sdf_depth=VoxelBuffer.DEPTH_16_BIT
 terrain.format=format
 var mesher=VoxelMesherTransvoxel.new()
 mesher.texturing_mode=VoxelMesherTransvoxel.TEXTURES_SINGLE_S4
 terrain.mesher=mesher
 terrain.generator=geology.graph()
 var mat=ShaderMaterial.new()
 mat.shader=load("res://shaders/terrain.gdshader")
 var profile=Geology.Landscape.PROFILES[data.landscape]
 mat.set_shader_parameter("dust_color",profile.soil)
 mat.set_shader_parameter("low_color",profile.low)
 mat.set_shader_parameter("high_color",profile.high)
 mat.set_shader_parameter("bedrock_color",profile.rock)
 mat.set_shader_parameter("base_radius",data.radius)
 mat.set_shader_parameter("strata_strength",0.59 if data.landscape in [1,4] else 0.10)
 terrain.material=harrow_material(true) if harrow else mat
 if save_folder!="":
  DirAccess.make_dir_recursive_absolute(save_folder)
  store_path=save_folder+"/planet-"+str(data.seed)+".sqlite"
  stream=VoxelStreamSQLite.new()
  stream.database_path=store_path
  terrain.stream=stream
 add_child(terrain)
 tool=terrain.get_voxel_tool()
 tool.channel=VoxelBuffer.CHANNEL_SDF
 tool.mode=VoxelTool.MODE_REMOVE
 tool.sdf_strength=1.0
 tool.set_raycast_binary_search_iterations(8)
 # The edit ledger also makes saves portable if a terrain database is missing.
 replay_queue=data.edits.duplicate()

static func harrow_material(native: bool) -> ShaderMaterial:
 var mat=ShaderMaterial.new()
 mat.shader=preload("res://shaders/harrow.gdshader")
 mat.set_shader_parameter("voxel_surface",native)
 mat.set_shader_parameter("rock_albedo",preload("res://assets/slice/aerial_rock_diff.jpg"))
 mat.set_shader_parameter("rock_normal",preload("res://assets/slice/aerial_rock_nor_gl.jpg"))
 mat.set_shader_parameter("rock_roughness",preload("res://assets/slice/aerial_rock_rough.jpg"))
 return mat

func mesh_excavation(site: Vector3,radius: float) -> Dictionary:
 var half_size=ceili(radius)+10
 if not can_edit(site,half_size): return {}
 var mesher=terrain.mesher
 var padding: int=mesher.get_minimum_padding()
 var dimension=2*half_size+padding+mesher.get_maximum_padding()
 var corner=Vector3i(site.floor())-Vector3i.ONE*(half_size+padding)
 var buffer=VoxelBuffer.new()
 buffer.create(dimension,dimension,dimension)
 buffer.set_channel_depth(VoxelBuffer.CHANNEL_SDF,VoxelBuffer.DEPTH_16_BIT)
 buffer.set_channel_depth(VoxelBuffer.CHANNEL_INDICES,VoxelBuffer.DEPTH_8_BIT)
 var channels=(1<<VoxelBuffer.CHANNEL_SDF)|(1<<VoxelBuffer.CHANNEL_INDICES)
 tool.copy(corner,buffer,channels)
 var mesh=mesher.build_mesh(buffer,[])
 if mesh==null or mesh.get_surface_count()==0: return {}
 return {"mesh":mesh,"position":Vector3(corner+Vector3i.ONE*padding)}

func focus(key: String,p: Vector3,visuals=true,distance=70000):
 if not viewers.has(key):
  var viewer=VoxelViewer.new()
  viewer.requires_visuals=visuals
  viewer.requires_collisions=visuals
  viewer.view_distance=distance
  add_child(viewer)
  viewers[key]=viewer
 viewers[key].position=p

func release_focus(key: String):
 if viewers.has(key): viewers[key].queue_free();viewers.erase(key)

func has_surface_coverage(up: Vector3) -> bool:
 var axis=Vector3.UP if absf(up.y)<0.95 else Vector3.RIGHT
 var east=axis.cross(up).normalized()
 var north=up.cross(east)
 # Check beneath the ship and around the visible hemisphere. Coarse meshes
 # count as coverage while the finer LODs are still being generated.
 for direction in [up,up+east,up-east,up+north,up-north]:
  var ground=geology.surface(direction.normalized())
  var covered=false
  for lod in range(terrain.lod_count-1,-1,-1):
   var block=terrain.voxel_to_mesh_block_position(ground,lod)
   var status=terrain.debug_get_mesh_block_info(block,lod)
   if status.meshed and status.visual_active:
    covered=true
    break
  if not covered: return false
 return true

func can_edit(p: Vector3,r: float) -> bool:
 return tool!=null and tool.is_area_editable(AABB(p-Vector3.ONE*(r+3.0),Vector3.ONE*(r+3.0)*2.0))

func excavate(p: Vector3,r: float) -> Dictionary:
 if not can_edit(p,r): return {"ready":false,"volume":0.0,"yield":0.0}
 var result=geology.sample_cut(p,r)
 result.ready=true
 if result.volume<=0.01: return result
 tool.do_sphere(p,r)
 geology.record_cut(p,r,result)
 return result

func raycast(origin: Vector3,direction: Vector3,distance=2200.0) -> Dictionary:
 # Analytic density includes the same cuts as the native editable volume.
 var t=0.0
 var previous=0.0
 for i in 750:
  if t>distance: break
  var p=origin+direction*t
  var d=geology.density(p)
  if d<0.08:
   var low=previous
   var high=t
   for j in 10:
    var mid=(low+high)*0.5
    if geology.density(origin+direction*mid)<0.0: high=mid
    else: low=mid
   var hit=origin+direction*((low+high)*0.5)
   var epsilon=0.6
   var normal=Vector3(geology.density(hit+Vector3.RIGHT*epsilon)-geology.density(hit-Vector3.RIGHT*epsilon),geology.density(hit+Vector3.UP*epsilon)-geology.density(hit-Vector3.UP*epsilon),geology.density(hit+Vector3.BACK*epsilon)-geology.density(hit-Vector3.BACK*epsilon)).normalized()
   return {"position":hit,"normal":normal,"distance":t,"material":geology.material_at(hit-normal*0.5)}
  previous=t
  t+=clampf(d*0.65,0.65,25.0)
 return {}

func tick(dt: float):
 ready_seconds+=dt
 if replay_queue.is_empty(): return
 # Replay only loaded regions; remote crews keep their own editable focus.
 var budget=8
 for i in range(replay_queue.size()-1,-1,-1):
  var cut=replay_queue[i]
  if can_edit(cut.center,cut.radius):
   tool.do_sphere(cut.center,cut.radius)
   replay_queue.remove_at(i)
   budget-=1
   if budget==0: break

func save_edits():
 if terrain!=null and stream!=null: return terrain.save_modified_blocks()
 return null

func flush():
 var tracker=save_edits()
 if tracker!=null:
  while not tracker.is_complete(): await get_tree().process_frame

func detach_local(p: Vector3,size=26.0) -> Array:
 if not can_edit(p,size): return []
 return tool.separate_floating_chunks(AABB(p-Vector3.ONE*size*0.5,Vector3.ONE*size),get_parent())
