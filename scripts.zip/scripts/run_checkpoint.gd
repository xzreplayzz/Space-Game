extends RefCounted

static func read(path: String) -> Dictionary:
 var file=FileAccess.open(path,FileAccess.READ)
 if file==null: return {}
 if file.get_length()<8 or file.get_32()!=file.get_length()-4: return {}
 file.seek(0)
 var data=file.get_var(false)
 if not data is Dictionary or data.get("version") not in [3,4]: return {}
 if not data.get("workers") is Dictionary or not data.get("system_data") is Dictionary: return {}
 if data.get("mode") not in ["MAP","SYSTEM","ENCOUNTER","MERCHANT","SIGNAL","REWARD","LOST"]: return {}
 return data

static func write(path: String, data: Dictionary) -> Error:
 var pending=path+".tmp"
 var backup=path+".bak"
 var file=FileAccess.open(pending,FileAccess.WRITE)
 if file==null: return FileAccess.get_open_error()
 file.store_var(data)
 file.flush()
 var error=file.get_error()
 file.close()
 if error!=OK: return error
 if read(pending).is_empty(): return ERR_FILE_CORRUPT
 if FileAccess.file_exists(path):
  if not read(path).is_empty():
   error=DirAccess.rename_absolute(path,backup)
   if error!=OK: return error
  else:
   error=DirAccess.remove_absolute(path)
   if error!=OK: return error
 return DirAccess.rename_absolute(pending,path)
