extends RefCounted

const Geology=preload("res://scripts/geology.gd")
const Landscape=preload("res://scripts/landscape.gd")

static func build(seed_number: int) -> Dictionary:
 var harrow=_body(703719,"Harrow",240000.0,3,2080000.0,0.69,0.06,0.65,1)
 harrow.merge({
  "terrain_revision":5,"inhabited":true,"population":3820.0,"species":"Venn",
  "skills":{"extractors":0.35,"abductors":0.08,"gunners":0.12,"engineers":0.37,"navigators":0.08},
  "top_job":"engineers","risk":3,"landscape_name":"Basalt shelves","air_color":Color("a6b7bb"),
  "atmosphere_density":0.70
 },true)
 var geology=Geology.new(harrow)
 _deposit(harrow,geology,"Rook Shelf",Vector2(-510,180),2,6.0)
 _deposit(harrow,geology,"Talon Cut",Vector2(660,-820),3,11.0)
 _deposit(harrow,geology,"North Scarp",Vector2(-1900,-3800),2,17.0)
 for site in [
  ["Harrow Works","City",Vector2(1050,70),340.0,3820.0],
 ]:
  var up=_normal(site[2],harrow.radius)
  harrow.features.append({"name":site[0],"type":site[1],"kind":"city","position":geology.surface(up),
   "normal":up,"radius":site[3],"population":site[4],"scanned":false})
 # Outer regions carry survey targets of their own.
 for i in 18:
  var y=1.0-2.0*(i+0.5)/18.0
  var r=sqrt(1.0-y*y)
  var angle=float(i)*2.39996323
  var up=Vector3(r*cos(angle),y,r*sin(angle))
  _deposit_at(harrow,geology,"Traverse %02d"%(i+1),up,3 if i%4==0 else 2,11.0+float(i%5))
 var lucent=_body(116023,"Lucent",153000.0,2,3230000.0,3.04,0.16,-0.12,0)
 lucent.merge({"sky_body":true,"landscape_name":"Icebound moonlets","atmosphere_density":0.43},true)
 var ilex=_body(472913,"Ilex",410000.0,5,5230000.0,-1.31,0.23,0.09,2)
 ilex.merge({"sky_body":true,"gas_giant":true,"rings":true,"landscape_name":"Ringed gas giant",
  "ground_color":Color("a69c85"),"air_color":Color("e1c4a2"),"atmosphere_density":0.86},true)
 return {"name":"Cinder Reach","seed":seed_number,"count":3,"depth":0,"planets":[harrow,lucent,ilex],
  "slice":true,"star_name":"Sere","star_color":Color("ffab58"),"star_radius":438000.0,"alert":{},"time":0.0}

static func _body(seed_number: int,body_name: String,radius: float,profile: int,orbit: float,phase: float,eccentricity: float,inclination: float,moons: int) -> Dictionary:
 var art=Landscape.PROFILES[profile]
 return {"seed":seed_number,"name":body_name,"radius":radius,"relief":850.0,"biome":profile,"landscape":profile,
  "landscape_name":art.name,"landscape_scale":1.0,"landscape_relief":1.0,"landscape_yaw":0.0,
  "terrain_revision":4,"orbit_radius":orbit,"orbit_phase":phase,"orbit_speed":0.0045/sqrt(orbit/2080000.0),
  "eccentricity":eccentricity,"orbit_tilt":inclination,"rings":false,"moons":moons,
  "ground_color":art.soil,"air_color":art.air,"atmosphere_density":0.5,
  "inhabited":false,"population":0.0,"species":"","skills":{},"top_job":"","risk":1,"integrity":1.0,
  "visited":false,"edits":[],"deposits":[],"features":[],"hotspots":[],"removed_volume":0.0,
  "ore_recovered":0.0,"fractured":false}

static func _normal(offset: Vector2,radius: float) -> Vector3:
 return Vector3(offset.x,radius,offset.y).normalized()

static func _deposit(body: Dictionary,geo,name: String,offset: Vector2,material: int,cover: float):
 _deposit_at(body,geo,name,_normal(offset,body.radius),material,cover)

static func _deposit_at(body: Dictionary,geo,name: String,up: Vector3,material: int,cover: float):
 var ground=geo.surface(up)
 var east=up.cross(Vector3.FORWARD).normalized()
 var width=16.0 if material==2 else 21.0
 var centers=[]
 for segment in [-1,0,1]:
  var direction=(ground+east*float(segment)*width*0.95).normalized()
  centers.append(geo.surface(direction)-direction*(cover+width+absf(segment)*2.0))
 body.deposits.append({"name":name,"material":material,"width":width,"centers":centers,"surface":ground,"normal":up,"cover":cover})
 body.features.append({"name":name,"type":"Ferrite seam" if material==2 else "Cobalt pocket",
  "kind":"mineral","position":ground,"normal":up,"material":material,"scanned":false,"cover":cover})
