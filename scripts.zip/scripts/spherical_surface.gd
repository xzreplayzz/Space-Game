extends Node3D

const CELLS=18
const MAX_DEPTH=12
var geology
var material: ShaderMaterial
var radius: float
var patches=[]
var refinement=[]

func setup(terrain_field,shared_material: ShaderMaterial):
 geology=terrain_field
 material=shared_material
 radius=geology.data.radius
 for normal in [Vector3.RIGHT,Vector3.LEFT,Vector3.UP,Vector3.DOWN,Vector3.FORWARD,Vector3.BACK]:
  var reference=Vector3.UP if absf(normal.y)<0.9 else Vector3.FORWARD
  var tangent=reference.cross(normal).normalized()
  patches.append(_build(normal,tangent,normal.cross(tangent),Vector2.ZERO,1.0,0))

func update_view(view: Vector3):
 refinement.clear()
 var up=view.normalized()
 var limb=radius/maxf(view.length(),radius)
 for patch in patches: _visit(patch,view,up,limb)
 if refinement.is_empty(): return
 var nearest=refinement[0]
 for candidate in refinement:
  if candidate.score<nearest.score: nearest=candidate
 _split(nearest.patch)

func _visit(patch: Dictionary,view: Vector3,up: Vector3,limb: float):
 var width=patch.half*radius*1.8
 var distance=view.distance_to(patch.center)
 var on_screen=patch.center.normalized().dot(up)>limb-patch.half*2.2-0.13
 if patch.children.is_empty():
  if on_screen and patch.depth<MAX_DEPTH and distance<width*2.45:
   refinement.append({"patch":patch,"score":distance/width})
  return
 if (not on_screen and distance>width*2.8) or distance>width*4.0:
  _merge(patch)
  return
 for child in patch.children: _visit(child,view,up,limb)

func _split(patch: Dictionary):
 var half=patch.half*0.5
 for delta in [Vector2(-half,-half),Vector2(half,-half),Vector2(-half,half),Vector2(half,half)]:
  patch.children.append(_build(patch.normal,patch.east,patch.north,patch.mid+delta,half,patch.depth+1))
 patch.node.hide()

func _merge(patch: Dictionary):
 for child in patch.children:
  _merge(child)
  child.node.queue_free()
 patch.children.clear()
 patch.node.show()

func _build(normal: Vector3,east: Vector3,north: Vector3,mid: Vector2,half: float,depth: int) -> Dictionary:
 var samples=PackedVector3Array()
 var row=CELLS+3
 samples.resize(row*row)
 for y in range(-1,CELLS+2):
  for x in range(-1,CELLS+2):
   var uv=mid+Vector2(2.0*x/CELLS-1.0,2.0*y/CELLS-1.0)*half
   samples[(y+1)*row+x+1]=geology.surface((normal+east*uv.x+north*uv.y).normalized())
 var vertices=PackedVector3Array()
 var normals=PackedVector3Array()
 var indices=PackedInt32Array()
 var stride=CELLS+1
 var origin=geology.surface((normal+east*mid.x+north*mid.y).normalized())
 for y in stride:
  for x in stride:
   var i=(y+1)*row+x+1
   vertices.append(samples[i]-origin)
   normals.append((samples[i+1]-samples[i-1]).cross(samples[i+row]-samples[i-row]).normalized())
   if x==CELLS or y==CELLS: continue
   var a=y*stride+x
   var b=a+1
   var c=a+stride
   var d=c+1
   indices.append_array(PackedInt32Array([a,c,b,b,c,d]))
 # Skirts cover differences between the sampled edges of neighbouring LODs.
 var skirt=maxf(3.0,half*radius*0.16)
 for edge in 4:
  for i in CELLS:
   var a: int
   var b: int
   match edge:
    0: a=i;b=i+1
    1: a=(i+1)*stride-1;b=a+stride
    2: a=CELLS*stride+CELLS-i;b=a-1
    _: a=(CELLS-i)*stride;b=a-stride
   var first=vertices.size()
   vertices.append(vertices[a]-(origin+vertices[a]).normalized()*skirt)
   vertices.append(vertices[b]-(origin+vertices[b]).normalized()*skirt)
   normals.append(normals[a]);normals.append(normals[b])
   indices.append_array(PackedInt32Array([a,b,first,b,first+1,first]))
 var arrays=[]
 arrays.resize(Mesh.ARRAY_MAX)
 arrays[Mesh.ARRAY_VERTEX]=vertices
 arrays[Mesh.ARRAY_NORMAL]=normals
 arrays[Mesh.ARRAY_INDEX]=indices
 var mesh=ArrayMesh.new()
 mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
 var node=MeshInstance3D.new()
 node.mesh=mesh
 node.material_override=material
 node.position=origin
 node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 add_child(node)
 return {"normal":normal,"east":east,"north":north,"mid":mid,"half":half,
  "depth":depth,"node":node,"center":origin,"children":[]}
