extends RefCounted

var game
var tree: SceneTree

func render():
 game.ui.queue_redraw()
 await tree.process_frame
 await RenderingServer.frame_post_draw

func key(code: Key):
 var ev=InputEventKey.new()
 ev.keycode=code
 ev.pressed=true
 Input.parse_input_event(ev)
 Input.flush_buffered_events()
 ev=ev.duplicate()
 ev.pressed=false
 Input.parse_input_event(ev)
 Input.flush_buffered_events()
 await render()

func click(action: String,payload=null):
 for entry in game.ui.buttons:
  if entry.action!=action or (payload!=null and entry.payload!=payload): continue
  var pos: Vector2=tree.root.get_final_transform()*entry.rect.get_center()
  var ev=InputEventMouseButton.new()
  ev.button_index=MOUSE_BUTTON_LEFT
  ev.position=pos
  ev.global_position=pos
  ev.pressed=true
  Input.parse_input_event(ev)
  Input.flush_buffered_events()
  ev=ev.duplicate()
  ev.pressed=false
  Input.parse_input_event(ev)
  Input.flush_buffered_events()
  await render()
  return
 game._assert_test(false,"pointer action available: "+action)

func has_action(action: String) -> bool:
 return game.ui.buttons.any(func(entry): return entry.action==action)

func run(root):
 game=root
 tree=game.get_tree()
 game.new_run(2017)
 await render()
 await key(KEY_TAB)
 game._assert_test(game.ui.focus_index>=0,"keyboard Tab reaches an actionable route")
 var routes=game.available_routes().duplicate()
 await click("route_preview",Vector2i(1,1))
 game._assert_test(game.route_step==0 and game.ui.chart_lane==1 and game.available_routes()==routes,"pointer previews Harrow without committing a route")
 await click("node")
 game._assert_test(game.mode=="SYSTEM" and game.route_step==1,"separate course action enters the selected system")
 game._demo_offers()
 game.credits=12
 game.mode="REWARD"
 game.warp_destination="MAP"
 await render()
 await click("reward_select",1)
 game._assert_test(game.ui.reward_selection==1 and game.credits==12 and not has_action("upgrade"),"12 cr can preview a 33 cr item; Install has no hit target")
 await key(KEY_3)
 game._assert_test(game.mode=="REWARD" and game.ui.reward_selection==2 and game.credits==12,"number keys browse without charging or exiting")
 await key(KEY_ENTER)
 game._assert_test(game.mode=="MAP" and game.credits==12 and game.levels.is_empty(),"keyboard banks the haul and keeps the full balance")
 game._demo_offers()
 game.credits=64
 game.mode="REWARD"
 await render()
 await key(KEY_2)
 game._assert_test(game.mode=="REWARD" and game.ui.reward_selection==1 and game.credits==64,"funded equipment selection requires separate confirmation")
 await key(KEY_ENTER)
 game._assert_test(game.mode=="MAP" and game.credits==31 and game.levels.get("thruster",0)==1,"confirm installs exactly one selected upgrade for 33 cr")
 await key(KEY_P)
 game._assert_test(game.ui.overlay=="crew","P opens the crew manifest")
 await click("crew_role",3)
 game._assert_test(game.ui.crew_role==3,"crew roles can be inspected with the pointer")
 await key(KEY_ESCAPE)
 game._assert_test(game.ui.overlay=="","Escape closes the manifest")
 game.ui._set_overlay("settings")
 await render()
 await click("text_scale",1.30)
 var settings=ConfigFile.new()
 game._assert_test(is_equal_approx(game.ui.text_scale,1.3) and settings.load("user://interface.cfg")==OK and is_equal_approx(settings.get_value("accessibility","text_scale",0.0),1.3),"text size setting applies and persists")
 var failures=game.test_results.filter(func(test):return not test.passed).size()
 tree.quit(1 if failures else 0)
