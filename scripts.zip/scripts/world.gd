extends Node3D

const Catalog=preload("res://scripts/catalog.gd")
var game
var camera: Camera3D
var planet_root: Node3D
var sphere: MeshInstance3D
var planet_material: ShaderMaterial
var ship: Node3D
var planet_radius=32.0
var azimuth=0.05
var elevation=0.12
var distance_factor=1.0
var ship_normal=Vector3(0,0,1)
var ship_position=Vector3(0,0,80)
var clock=0.0
var hit_flash=0.0
var shattered=false
var combat=[]
var projectiles=[]
var effects=[]
var chunks=[]
var police=[]
var turret_timer=0.0
var warp_root: Node3D
var stars_root: Node3D
var trails=[]
var local_rng=RandomNumberGenerator.new()
var current_planet={}

func _ready():
 local_rng.seed=8195
 camera=Camera3D.new()
 camera.fov=60.0
 camera.far=2200.0
 camera.near=0.15
 add_child(camera)
 camera.current=true
 var environment=WorldEnvironment.new()
 var env=Environment.new()
 env.background_mode=Environment.BG_COLOR
 env.background_color=Color("030811")
 env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
 env.ambient_light_color=Color("728aa5")
 env.ambient_light_energy=0.24
 env.tonemap_mode=Environment.TONE_MAPPER_FILMIC
 environment.environment=env
 add_child(environment)
 var sun=DirectionalLight3D.new()
 sun.rotation_degrees=Vector3(-24,-65,-12)
 sun.light_color=Color("ffe2b4")
 sun.light_energy=1.4
 add_child(sun)
 var fill=DirectionalLight3D.new()
 fill.rotation_degrees=Vector3(20,140,0)
 fill.light_color=Color("6588aa")
 fill.light_energy=0.16
 add_child(fill)
 stars_root=Node3D.new()
 add_child(stars_root)
 _build_stars()
 ship=_build_ship()
 ship.scale=Vector3.ONE*0.65
 add_child(ship)
 warp_root=Node3D.new()
 add_child(warp_root)
 for i in 130:
  var streak=MeshInstance3D.new()
  var box=BoxMesh.new()
  box.size=Vector3(0.025,0.025,local_rng.randf_range(3,16))
  streak.mesh=box
  streak.material_override=material(Color("83a9b5"),true)
  streak.position=Vector3(local_rng.randf_range(-35,35),local_rng.randf_range(-22,22),local_rng.randf_range(-170,-8))
  warp_root.add_child(streak)
 warp_root.visible=false

func material(color: Color, emissive=false, metallic=0.0) -> StandardMaterial3D:
 var mat=StandardMaterial3D.new()
 mat.albedo_color=color
 mat.roughness=0.66
 mat.metallic=metallic
 if emissive:
  mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
 return mat

func box(parent: Node3D, position: Vector3, size: Vector3, mat: Material) -> MeshInstance3D:
 var mesh=MeshInstance3D.new()
 var shape=BoxMesh.new()
 shape.size=size
 mesh.mesh=shape
 mesh.material_override=mat
 parent.add_child(mesh)
 mesh.position=position
 return mesh

func ball(parent: Node3D, position: Vector3, radius: float, mat: Material, segments=16) -> MeshInstance3D:
 var mesh=MeshInstance3D.new()
 var shape=SphereMesh.new()
 shape.radius=radius
 shape.height=radius*2.0
 shape.radial_segments=segments
 shape.rings=maxi(6,int(segments/2))
 mesh.mesh=shape
 mesh.material_override=mat
 parent.add_child(mesh)
 mesh.position=position
 return mesh

func _build_stars():
 var stars=MultiMeshInstance3D.new()
 var multimesh=MultiMesh.new()
 multimesh.transform_format=MultiMesh.TRANSFORM_3D
 multimesh.use_colors=true
 var shape=SphereMesh.new()
 shape.radius=0.18
 shape.height=0.36
 shape.radial_segments=4
 shape.rings=2
 multimesh.mesh=shape
 multimesh.instance_count=1700
 for i in multimesh.instance_count:
  var direction=Vector3(local_rng.randfn(),local_rng.randfn(),local_rng.randfn()).normalized()
  var scale_value=local_rng.randf_range(0.3,1.9)
  var transform=Transform3D(Basis().scaled(Vector3.ONE*scale_value),direction*local_rng.randf_range(600,1000))
  multimesh.set_instance_transform(i,transform)
  var brightness=local_rng.randf_range(0.17,0.9)
  multimesh.set_instance_color(i,Color(brightness*0.92,brightness*0.96,brightness))
 stars.multimesh=multimesh
 var mat=material(Color.WHITE,true)
 mat.vertex_color_use_as_albedo=true
 stars.material_override=mat
 stars_root.add_child(stars)
 # A sparse dust plane gives the sky depth without obscuring the encounter.
 for i in 32:
  var p=Vector3(local_rng.randf_range(-400,400),local_rng.randf_range(-45,45),-650)
  ball(stars_root,p,local_rng.randf_range(0.4,1.0),material(Color("334a65"),true),6)

func _build_ship() -> Node3D:
 var root=Node3D.new()
 var hull_mat=material(Color("495763"),false,0.65)
 var dark=material(Color("17232d"),false,0.45)
 var edge=material(Color("8c9797"),false,0.7)
 var gold=material(Color("b18a57"),false,0.5)
 var glass=material(Color("78adbd"),true)
 var blue=material(Color("83d0db"),true)
 _armoured_hull(root,hull_mat,0.0,0.0,1.0)
 box(root,Vector3(0,-0.45,-0.3),Vector3(1.9,0.45,7.4),dark)
 box(root,Vector3(0,0.96,1.0),Vector3(1.6,0.52,2.5),dark)
 box(root,Vector3(0,1.28,0.7),Vector3(1.55,0.12,2.2),edge)
 box(root,Vector3(0,1.05,-0.28),Vector3(1.3,0.22,0.06),glass)
 for side in [-1,1]:
  var pod=Node3D.new()
  root.add_child(pod)
  pod.position=Vector3(side*2.4,-0.1,1.8)
  pod.scale=Vector3(0.52,0.70,0.56)
  _armoured_hull(pod,hull_mat,0.0,0.0,1.0)
  box(root,Vector3(side*1.8,-0.2,0.5),Vector3(2.0,0.4,3.4),dark)
  box(root,Vector3(side*2.4,0.48,0.7),Vector3(1.2,0.10,2.4),gold)
  box(root,Vector3(side*2.4,0.2,2.0),Vector3(0.9,0.28,2.0),dark)
  box(root,Vector3(side*2.4,0.05,4.49),Vector3(1.0,0.6,0.12),blue)
  box(root,Vector3(side*2.4,0.05,5.05),Vector3(0.7,0.35,0.85),material(Color("3b818f"),true))
  for i in 5:
   box(root,Vector3(side*1.53,0.12,-2.5+i*0.8),Vector3(0.045,0.2,0.30),glass)
  for i in 3:
   box(root,Vector3(side*2.4,0.61,1.9+i*0.6),Vector3(0.85,0.08,0.2),edge)
  box(root,Vector3(side*1.0,0.9,-2.3),Vector3(0.7,0.45,1.0),dark)
  box(root,Vector3(side*1.0,1.0,-3.1),Vector3(0.13,0.13,1.2),edge)
 box(root,Vector3(0,0.79,-0.2),Vector3(0.22,0.10,4.4),gold)
 return root

func _armoured_hull(parent: Node3D, mat: Material, offset_x: float, offset_z: float, size_factor: float):
 var tool=SurfaceTool.new()
 tool.begin(Mesh.PRIMITIVE_TRIANGLES)
 var rings=[]
 var sections=[[-7.0,0.22,0.12],[-4.3,1.25,0.46],[-1.5,1.50,0.66],[3.6,1.50,0.66],[4.5,1.10,0.49]]
 for section in sections:
  var z=section[0]+offset_z
  var w=section[1]
  var h=section[2]
  var ring=[]
  for p in [Vector2(-w*0.7,h),Vector2(w*0.7,h),Vector2(w,h*0.45),Vector2(w,-h*0.45),Vector2(w*0.7,-h),Vector2(-w*0.7,-h),Vector2(-w,-h*0.45),Vector2(-w,h*0.45)]:
   ring.append(Vector3(p.x+offset_x,p.y,z)*size_factor)
  rings.append(ring)
 for r in range(rings.size()-1):
  for j in 8:
   var k=(j+1)%8
   for p in [rings[r][j],rings[r+1][k],rings[r+1][j],rings[r][j],rings[r][k],rings[r+1][k]]: tool.add_vertex(p)
 for j in range(1,7):
  tool.add_vertex(rings[0][0]);tool.add_vertex(rings[0][j]);tool.add_vertex(rings[0][j+1])
  tool.add_vertex(rings[-1][0]);tool.add_vertex(rings[-1][j+1]);tool.add_vertex(rings[-1][j])
 tool.generate_normals()
 var instance=MeshInstance3D.new()
 instance.mesh=tool.commit()
 instance.material_override=mat
 parent.add_child(instance)

func build_planet(data: Dictionary):
 if planet_root!=null:
  planet_root.free()
 for piece in chunks:
  if is_instance_valid(piece.node): piece.node.queue_free()
 chunks.clear()
 current_planet=data
 planet_radius=data.radius
 shattered=data.get("integrity",1.0)<=0.0
 planet_root=Node3D.new()
 add_child(planet_root)
 var biome=Catalog.BIOMES[data.biome]
 planet_material=ShaderMaterial.new()
 planet_material.shader=load("res://shaders/planet.gdshader")
 planet_material.set_shader_parameter("land_color",biome.land)
 planet_material.set_shader_parameter("low_color",biome.low)
 planet_material.set_shader_parameter("high_color",biome.high)
 planet_material.set_shader_parameter("core_color",Color("dd783b") if data.biome!=2 else Color("6ec9dc"))
 planet_material.set_shader_parameter("ocean",biome.ocean)
 planet_material.set_shader_parameter("seed_value",float(data.seed%1000)/13.0)
 sphere=ball(planet_root,Vector3.ZERO,planet_radius,planet_material,160)
 var air=ShaderMaterial.new()
 air.shader=load("res://shaders/atmosphere.gdshader")
 air.set_shader_parameter("tint",biome.air)
 ball(planet_root,Vector3.ZERO,planet_radius*1.025,air,96)
 if data.rings: _build_rings(biome)
 var rng=RandomNumberGenerator.new()
 rng.seed=data.seed
 for spot in data.hotspots:
  if spot.kind=="city":
   var normal=spot.normal
   var city=Node3D.new()
   city.position=normal*planet_radius*1.007
   city.quaternion=Quaternion(Vector3.UP,normal)
   planet_root.add_child(city)
   for i in 18:
    var height=rng.randf_range(0.12,0.65)
    var pos=Vector3(rng.randf_range(-1.2,1.2),height*0.5,rng.randf_range(-1.2,1.2))
    box(city,pos,Vector3(rng.randf_range(0.1,0.3),height,rng.randf_range(0.1,0.3)),material(Color("7c817a"),false,0.2))
    box(city,pos+Vector3(0,height*0.5,0),Vector3(0.08,0.03,0.08),material(Color("d9ad71"),true))
 _update_scars()
 if shattered: planet_root.visible=false

func _build_rings(biome):
 var surface=SurfaceTool.new()
 surface.begin(Mesh.PRIMITIVE_TRIANGLES)
 var random=RandomNumberGenerator.new()
 random.seed=current_planet.seed+91
 for band in 12:
  if band==4 or band==9: continue
  var inner=planet_radius*(1.28+band*0.053)
  var outer=inner+planet_radius*0.042
  var col=biome.high*random.randf_range(0.38,0.8)
  col.a=1.0
  for i in 180:
   var a=float(i)*TAU/180.0
   var b=float(i+1)*TAU/180.0
   var points=[Vector3(cos(a)*inner,0,sin(a)*inner),Vector3(cos(a)*outer,0,sin(a)*outer),Vector3(cos(b)*outer,0,sin(b)*outer),Vector3(cos(a)*inner,0,sin(a)*inner),Vector3(cos(b)*outer,0,sin(b)*outer),Vector3(cos(b)*inner,0,sin(b)*inner)]
   for p in points:
    surface.set_color(col)
    surface.set_normal(Vector3.UP)
    surface.add_vertex(p)
 var mesh=MeshInstance3D.new()
 mesh.mesh=surface.commit()
 var mat=material(Color.WHITE)
 mat.vertex_color_use_as_albedo=true
 mat.cull_mode=BaseMaterial3D.CULL_DISABLED
 mesh.material_override=mat
 mesh.rotation_degrees=Vector3(12,0,-17)
 planet_root.add_child(mesh)

func _update_scars():
 if not current_planet.has("hotspots"): return
 var array=PackedVector4Array()
 for i in 12:
  if i<current_planet.hotspots.size():
   var spot=current_planet.hotspots[i]
   var normal=spot.normal
   var depth=clampf(sqrt(spot.extracted/maxf(1,spot.reserve))*1.4,0,1)
   array.append(Vector4(normal.x,normal.y,normal.z,depth))
  else: array.append(Vector4(0,0,0,0))
 planet_material.set_shader_parameter("scars",array)

func set_orbit(yaw: float, pitch: float, distance: float):
 azimuth=yaw
 elevation=pitch
 distance_factor=distance
 _position_ship(1.0,true)

func rotate_orbit(relative: Vector2):
 azimuth-=relative.x*0.003
 elevation=clampf(elevation+relative.y*0.003,-1.15,1.15)

func _position_ship(dt: float, immediate=false):
 ship_normal=Vector3(sin(azimuth)*cos(elevation),sin(elevation),cos(azimuth)*cos(elevation))
 ship_position=ship_normal*(planet_radius+37.0)*distance_factor
 ship.position=ship_position
 ship.look_at(Vector3.ZERO,Vector3.UP)
 ship.rotate_object_local(Vector3.FORWARD,sin(clock*0.5)*0.015)
 var up=Vector3.UP.slide(ship_normal).normalized()
 var camera_target=ship_position+ship_normal*16.0+up*7.0
 camera.position=camera_target if immediate else camera.position.lerp(camera_target,1.0-exp(-dt*8.0))
 camera.look_at(ship_position-ship_normal*48.0,up)

func step(dt: float):
 clock+=dt
 hit_flash=maxf(0.0,hit_flash-dt)
 var active=game.mode=="ENCOUNTER"
 ship.visible=active
 warp_root.visible=game.mode=="WARP"
 planet_root.visible=(active or game.mode=="TITLE" or game.mode=="SYSTEM") and not shattered
 if active:
  planet_root.position=Vector3.ZERO
  var enabled=not game.paused and not game.tutorial_open and not game.help_open
  if enabled:
   var speed=0.36*pow(1.3,game.levels.get("thruster",0))
   if Input.is_key_pressed(KEY_SHIFT): speed*=2.1
   if Input.is_key_pressed(KEY_A): azimuth-=dt*speed
   if Input.is_key_pressed(KEY_D): azimuth+=dt*speed
   if Input.is_key_pressed(KEY_Q): elevation=clampf(elevation-dt*speed,-1.15,1.15)
   if Input.is_key_pressed(KEY_E): elevation=clampf(elevation+dt*speed,-1.15,1.15)
   if Input.is_key_pressed(KEY_W): distance_factor=maxf(0.80,distance_factor-dt*0.16)
   if Input.is_key_pressed(KEY_S): distance_factor=minf(1.50,distance_factor+dt*0.16)
  _position_ship(dt)
  for spot in current_planet.hotspots:
   if spot.normal.dot(ship_normal)>0.35: spot.revealed=true
  _update_scars()
  _combat_step(dt)
 elif game.mode=="WARP":
  camera.position=Vector3.ZERO
  camera.rotation=Vector3.ZERO
  for streak in warp_root.get_children():
   streak.position.z+=dt*(55.0+game.warp_time*70.0)
   if streak.position.z>1.0: streak.position.z=-170.0
 else:
  planet_root.position=Vector3(40,0,-28)
  camera.position=Vector3(0,8,135)
  camera.look_at(Vector3.ZERO)
  if game.mode=="TITLE": planet_root.rotation.y+=dt*0.018
 _effects_step(dt)
 for chunk in chunks:
  chunk.node.position+=chunk.velocity*dt
  chunk.node.rotate_y(dt*chunk.spin)

func site_position(index: int) -> Vector3:
 return current_planet.hotspots[index].normal*(planet_radius*1.02)

func site_screen(index: int) -> Vector2:
 return camera.unproject_position(site_position(index))

func site_visible(index: int) -> bool:
 var spot=current_planet.hotspots[index]
 return spot.revealed and spot.normal.dot(ship_normal)>0.17 and not camera.is_position_behind(site_position(index)) and not shattered

func launch_effect(site: int, count: int, returning: bool):
 if game.tests_running: return
 var destination=site_position(site)
 var start=ship_position
 if returning:
  start=destination
  destination=ship_position
 for i in mini(7,maxi(1,int(count/4))):
  var rocket=box(self,start,Vector3(0.12,0.12,0.65),material(Color("c8b38f")))
  ball(rocket,Vector3(0,0,0.4),0.07,material(Color("8ac8d1"),true),6)
  var offset=Vector3(local_rng.randf_range(-1.5,1.5),local_rng.randf_range(-0.6,0.6),0)
  effects.append({"node":rocket,"kind":"rocket","from":start+offset,"to":destination+offset*0.15,"time":game.travel_duration()+i*0.10,"max":game.travel_duration()+i*0.10,"arc":Vector3.UP*local_rng.randf_range(2,6)})

func beam(start: Vector3, end: Vector3, color: Color, lifetime=0.12, thickness=0.035):
 var length=start.distance_to(end)
 if length<0.01: return
 var node=MeshInstance3D.new()
 var shape=BoxMesh.new()
 shape.size=Vector3(thickness,thickness,length)
 node.mesh=shape
 node.material_override=material(color,true)
 add_child(node)
 node.position=(start+end)*0.5
 node.look_at(end)
 effects.append({"node":node,"kind":"flash","time":lifetime,"max":lifetime})

func _effects_step(dt: float):
 var expired=[]
 for effect in effects:
  effect.time-=dt
  if effect.time<=0.0:
   effect.node.queue_free()
   expired.append(effect)
   continue
  if effect.kind=="rocket":
   var progress=1.0-effect.time/effect.max
   effect.node.position=effect.from.lerp(effect.to,progress)+effect.arc*sin(progress*PI)
   var direction=effect.to-effect.node.position
   if direction.length_squared()>0.001:
    var up=Vector3.RIGHT if absf(direction.normalized().y)>0.995 else Vector3.UP
    effect.node.quaternion=Basis.looking_at(direction,up).get_rotation_quaternion()
 for effect in expired: effects.erase(effect)

func clear_combat():
 for entity in combat:
  if is_instance_valid(entity.node): entity.node.queue_free()
 combat.clear()
 for node in police:
  if is_instance_valid(node): node.queue_free()
 police.clear()
 turret_timer=0.0

func spawn_missile():
 var start=ship_normal.rotated(Vector3.UP,local_rng.randf_range(-0.5,0.5))*planet_radius*1.05
 start.y+=local_rng.randf_range(-8,8)
 var root=Node3D.new()
 add_child(root)
 root.position=start
 box(root,Vector3.ZERO,Vector3(0.28,0.28,1.0),material(Color("b76b58")))
 ball(root,Vector3.ZERO,0.24,material(Color("f3ad77"),true),8)
 combat.append({"node":root,"type":"missile","velocity":(ship_position-start).normalized()*16.0,"health":1,"life":11.0,"age":0.0})

func spawn_fighter():
 if combat.size()>14: return
 var root=Node3D.new()
 add_child(root)
 var start=ship_position+Vector3(local_rng.randf_range(-25,25),10,-30)
 root.position=start
 box(root,Vector3.ZERO,Vector3(1.6,0.4,2.8),material(Color("8e6555"),false,0.5))
 box(root,Vector3.ZERO,Vector3(4.0,0.1,0.8),material(Color("403f45")))
 combat.append({"node":root,"type":"fighter","velocity":Vector3.ZERO,"health":4,"life":35.0,"age":0.0,"phase":local_rng.randf()*TAU,"fire":3.0})

func _combat_step(dt: float):
 var expired=[]
 for entity in combat:
  entity.life-=dt
  entity.age+=dt
  if entity.type=="missile":
   var desired=(ship_position-entity.node.position).normalized()*19.0
   entity.velocity=entity.velocity.lerp(desired,dt*0.35)
   entity.node.position+=entity.velocity*dt
   if entity.node.position.distance_to(ship_position)<3.0:
    game.damage(8.0)
    entity.life=0.0
   if entity.velocity.length_squared()>0.01: entity.node.look_at(entity.node.position+entity.velocity)
  else:
   var phase=entity.age*0.6+entity.phase
   var target=ship_position+Vector3(cos(phase)*25.0,sin(phase*0.7)*9.0,-12.0+sin(phase)*16.0)
   entity.node.position=entity.node.position.lerp(target,dt*0.6)
   entity.node.look_at(ship_position)
   entity.fire-=dt
   if entity.fire<=0.0:
    entity.fire=5.5
    beam(entity.node.position,ship_position+Vector3.UP*2,Color("d68e70"),0.2)
    game.damage(3.0)
  if entity.life<=0.0: expired.append(entity)
 for entity in expired:
  entity.node.queue_free()
  combat.erase(entity)
 turret_timer-=dt
 var gunners=game.available("gunners")
 if turret_timer<=0 and gunners>0 and combat.size()>0:
  turret_timer=maxf(0.4,5.0/(1.0+game.levels.get("turret",0))*20.0/maxf(5,gunners))
  var target=combat[0]
  beam(ship_position+Vector3.UP,target.node.position,Color("80c8c4"),0.14)
  target.health-=1
  if target.health<=0: destroy_entity(target)
 if game.police_arrived and police.size()>0 and fmod(clock,0.13)<dt:
  var node=police[local_rng.randi_range(0,police.size()-1)]
  beam(node.position,ship_position+Vector3(local_rng.randf_range(-3,3),local_rng.randf_range(-2,2),0),Color("df755c"),0.10,0.09)
  hit_flash=maxf(hit_flash,0.12)

func destroy_entity(entity):
 for i in 4:
  var end=entity.node.position+Vector3(local_rng.randfn(),local_rng.randfn(),local_rng.randfn())*1.2
  beam(entity.node.position,end,Color("e8bc83"),0.18,0.08)
 entity.node.queue_free()
 combat.erase(entity)

func fire_at(screen_position: Vector2):
 var target=null
 var closest=55.0
 for entity in combat:
  if camera.is_position_behind(entity.node.position): continue
  var projected=camera.unproject_position(entity.node.position)
  var distance=projected.distance_to(screen_position)
  if distance<closest:
   closest=distance
   target=entity
 var direction=camera.project_ray_normal(screen_position)
 var destination=camera.project_ray_origin(screen_position)+direction*160.0
 if target!=null:
  destination=target.node.position
  target.health-=1
 beam(ship_position+Vector3(0,1,-2),destination,Color("c6e1df"),0.09)
 if target!=null and target.health<=0:
  destroy_entity(target)
  game.sound("collect")

func spawn_police():
 for i in 7:
  var node=_build_ship()
  add_child(node)
  var angle=float(i)*TAU/7.0
  node.position=ship_position+Vector3(cos(angle)*45.0,local_rng.randf_range(8,25),sin(angle)*30.0-20)
  node.scale=Vector3.ONE*local_rng.randf_range(1.2,2.0)
  node.look_at(ship_position)
  police.append(node)

func shatter_planet():
 shattered=true
 planet_root.visible=false
 var mat=material(Catalog.BIOMES[current_planet.biome].land)
 for i in 65:
  var normal=Vector3(local_rng.randfn(),local_rng.randfn(),local_rng.randfn()).normalized()
  var fragment=box(self,normal*planet_radius*local_rng.randf_range(0.3,0.9),Vector3.ONE*local_rng.randf_range(2,6),mat)
  fragment.rotation=Vector3(local_rng.randf()*PI,local_rng.randf()*PI,local_rng.randf()*PI)
  chunks.append({"node":fragment,"velocity":normal*local_rng.randf_range(1.5,5.0),"spin":local_rng.randf_range(-0.5,0.5)})

func begin_warp():
 clear_combat()
 for effect in effects:
  if is_instance_valid(effect.node): effect.node.queue_free()
 effects.clear()
 warp_root.visible=true

func end_warp():
 warp_root.visible=false
