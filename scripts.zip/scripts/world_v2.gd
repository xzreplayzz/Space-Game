extends "res://scripts/world.gd"
const Volume=preload("res://scripts/planet_volume.gd")
const Geology=preload("res://scripts/geology.gd")
const SphericalSurface=preload("res://scripts/spherical_surface.gd")
const ROOK=preload("res://assets/slice/rook.glb")
const LANDER=preload("res://assets/slice/lander.glb")
const BORE=preload("res://assets/slice/bore.glb")
const PROCESSOR=preload("res://assets/slice/processor.glb")
const HABITAT=preload("res://assets/slice/habitat.glb")
const PAD=preload("res://assets/slice/pad.glb")
var solar_root: Node3D
var solar_planets=[]
var solar_positions=[]
var star_corona: MeshInstance3D
var local_atmosphere: MeshInstance3D
var solar_moons=[]
var orbit_lines=[]
var volume
var spherical_surface
var cut_patch: MeshInstance3D
var cut_site=Vector3.ZERO
var cut_version=-1
var cut_replays=-1
var cut_radius=0.0
var cut_retry_at=0.0
var cockpit: Node3D
var sky_material: ShaderMaterial
var environment: Environment
var sunlight: DirectionalLight3D
var ship_velocity=Vector3.ZERO
var flight_yaw=0.0
var flight_pitch=-0.52
var steer_input=Vector2.ZERO
var orbit_assist=true
var cruise_boost=false
var boost_active=false
const NORMAL_SPEED=40.0
const BOOST_MULTIPLIER=10.0
const MIN_CLEARANCE=60.0
const SURFACE_HANDOFF_ALTITUDE=3800.0
var view_yaw=0.25
var view_pitch=0.72
var system_zoom=1.0
var approach_time=0.0
var approach_start=Vector3.ZERO
var surface_start=Vector3.ZERO
var arrival_position=Vector3.ZERO
const ARRIVAL_PITCH=-1.30
var arrival_pitch=ARRIVAL_PITCH
var harrow=false
var industrial_traffic=[]
var surface_normal=Vector3.UP
var target_hit={}
var aim_clock=0.0
var scan_wave=0.0
var city_nodes=[]
var buildings=[]
var lander_nodes={}
var bore_nodes={}
var fragment_nodes=[]
var fragment_clock=0.0
var fracture_level=0
var volume_ready=false
var solar_target=-1
var screen_shake=0.0

func _ready():
 super._ready()
 camera.far=3000000.0
 camera.near=100.0
 camera.fov=70.0
 stars_root.scale=Vector3.ONE*1400
 for child in get_children():
  if child is WorldEnvironment:
   environment=child.environment
   var sky=Sky.new()
   sky_material=ShaderMaterial.new()
   sky_material.shader=load("res://shaders/sky.gdshader")
   sky.sky_material=sky_material
   environment.sky=sky
   environment.background_mode=Environment.BG_SKY
   environment.ambient_light_energy=0.44
   environment.fog_sky_affect=0.0
  if child is DirectionalLight3D:
   if child.light_energy>1.0:
    sunlight=child
    child.rotation_degrees=Vector3(-32,-36,0)
    child.light_energy=1.7
    child.shadow_enabled=true
    child.directional_shadow_max_distance=2200
 ship.free()
 ship=ROOK.instantiate()
 add_child(ship)
 ship.hide()
 cockpit=_build_cockpit()
 camera.add_child(cockpit)
 cockpit.visible=false

func _build_cockpit() -> Node3D:
 var root=preload("res://scripts/cockpit.gd").new()
 root.game=game
 return root

func build_system(data: Dictionary):
 _clear_fragments()
 if solar_root!=null: solar_root.free()
 solar_root=Node3D.new();add_child(solar_root)
 solar_planets.clear();solar_positions.clear();solar_moons.clear()
 orbit_lines.clear()
 var star_mat=ShaderMaterial.new()
 star_mat.shader=load("res://shaders/star.gdshader")
 star_mat.set_shader_parameter("tint",data.star_color)
 ball(solar_root,Vector3.ZERO,data.star_radius,star_mat,80)
 star_corona=MeshInstance3D.new()
 var corona_quad=QuadMesh.new()
 corona_quad.size=Vector2.ONE*data.star_radius*4.5
 star_corona.mesh=corona_quad
 var corona_material=ShaderMaterial.new()
 corona_material.shader=load("res://shaders/corona.gdshader")
 corona_material.set_shader_parameter("tint",data.star_color)
 star_corona.material_override=corona_material
 star_corona.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 solar_root.add_child(star_corona)
 for i in data.planets.size():
  var body=data.planets[i]
  var root=Node3D.new();solar_root.add_child(root)
  var mesh=MeshInstance3D.new()
  var is_harrow=body.get("terrain_revision",0)==5
  if body.get("sky_body",false):
   var globe=SphereMesh.new();globe.radius=body.radius;globe.height=body.radius*2.0
   globe.radial_segments=144;globe.rings=72
   mesh.mesh=globe
   var mat=ShaderMaterial.new();mat.shader=preload("res://shaders/distant_world.gdshader")
   mat.set_shader_parameter("gas_giant",body.get("gas_giant",false))
   mesh.material_override=mat
  else:
   var geo=Geology.new(body)
   mesh.mesh=_planet_mesh(geo,240 if is_harrow else 112,120 if is_harrow else 56)
   mesh.material_override=Volume.harrow_material(false) if is_harrow else _orbital_material(body)
  root.add_child(mesh)
  root.set_meta("surface_mesh",mesh)
  if body.get("fractured",false):
   mesh.visible=false
   for part in _fracture_parts(Geology.new(body)):
    var debris=MeshInstance3D.new();debris.mesh=part.mesh;debris.material_override=material(body.ground_color)
    root.add_child(debris);debris.position=part.center*1.15
  var air=ShaderMaterial.new();air.shader=load("res://shaders/atmosphere.gdshader")
  air.set_shader_parameter("tint",body.air_color)
  air.set_shader_parameter("density",body.get("atmosphere_density",0.65))
  root.set_meta("air_shell",ball(root,Vector3.ZERO,_atmosphere_radius(body),air,64))
  if body.rings: _system_ring(root,body.radius,body.ground_color)
  for m in body.moons:
   var moon_mat=ShaderMaterial.new();moon_mat.shader=preload("res://shaders/distant_world.gdshader")
   moon_mat.set_shader_parameter("rocky_moon",true)
   var moon=ball(root,Vector3.ZERO,body.radius*(0.105+m*0.038),moon_mat,40)
   solar_moons.append({"node":moon,"planet":i,"orbit":body.radius*(2.0+m*0.65),"phase":m*2.5+i})
  solar_planets.append(root)
  solar_positions.append(Vector3.ZERO)
  _orbit_path(body)
 _move_system(0.0)

func _atmosphere_radius(body: Dictionary) -> float:
 if body.get("terrain_revision",0)==5: return body.radius+8200.0
 return body.radius+maxf(body.radius*0.055,1300.0*body.landscape_relief)

func _orbital_material(body: Dictionary) -> ShaderMaterial:
 var profile=Geology.Landscape.PROFILES[body.landscape]
 var mat=ShaderMaterial.new();mat.shader=load("res://shaders/orbital_landscape.gdshader")
 mat.set_shader_parameter("base_radius",body.radius)
 mat.set_shader_parameter("soil",profile.soil)
 mat.set_shader_parameter("shadow_tone",profile.low)
 mat.set_shader_parameter("high_tone",profile.high)
 mat.set_shader_parameter("world_seed",float(body.seed%4096))
 return mat

func use_local_planet(index: int):
 solar_root.position=-solar_positions[index]
 solar_target=index
 var proxy=solar_planets[index]
 proxy.rotation.y=0.0
 proxy.get_meta("air_shell").visible=false
 if local_atmosphere!=null: local_atmosphere.material_override.set_shader_parameter("star_position",solar_root.global_position)
 var star_vector=solar_root.position.normalized()
 RenderingServer.global_shader_parameter_set("harrow_sun",star_vector)
 if sunlight!=null and harrow:
  sunlight.light_energy=1.20
  sunlight.look_at(-star_vector,Vector3.UP)

func _planet_mesh(geo,segments: int,rings: int) -> ArrayMesh:
 var shape=SphereMesh.new();shape.radius=1;shape.height=2;shape.radial_segments=segments;shape.rings=rings
 var arrays=shape.get_mesh_arrays()
 var vertices: PackedVector3Array=arrays[Mesh.ARRAY_VERTEX]
 var normals: PackedVector3Array=arrays[Mesh.ARRAY_NORMAL]
 for i in vertices.size():
  var normal=vertices[i].normalized()
  var surface=geo.edited_surface(normal)
  var axis=Vector3.UP if absf(normal.y)<0.97 else Vector3.RIGHT
  var east=axis.cross(normal).normalized()
  var north=normal.cross(east)
  var normal_step=1.0/float(segments)
  var tangent_x=geo.surface((normal+east*normal_step).normalized())-geo.surface((normal-east*normal_step).normalized())
  var tangent_y=geo.surface((normal+north*normal_step).normalized())-geo.surface((normal-north*normal_step).normalized())
  vertices[i]=surface
  normals[i]=normal.lerp(tangent_x.cross(tangent_y).normalized(),0.58).normalized()
 arrays[Mesh.ARRAY_VERTEX]=vertices
 arrays[Mesh.ARRAY_NORMAL]=normals
 var mesh=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
 return mesh

func _orbit_path(body):
 var tool=SurfaceTool.new();tool.begin(Mesh.PRIMITIVE_TRIANGLES)
 var width=body.orbit_radius*0.008+800.0
 for i in 256:
  var a=float(i)*TAU/256.0;var b=float(i+1)*TAU/256.0
  for index in [0,1,2,0,2,3]:
   var angle=a if index in [0,1] else b
   var outside=index in [1,2]
   tool.set_uv(Vector2(float(i)/256.0,1.0 if outside else 0.0))
   tool.add_vertex(_orbit_position(body,angle,width if outside else -width))
 var node=MeshInstance3D.new();node.mesh=tool.commit()
 var mat=ShaderMaterial.new();mat.shader=load("res://shaders/orbit.gdshader")
 node.material_override=mat;solar_root.add_child(node)
 orbit_lines.append(node)

func _system_ring(root: Node3D,radius: float,color: Color):
 var tool=SurfaceTool.new();tool.begin(Mesh.PRIMITIVE_TRIANGLES)
 for i in 256:
  for point in [Vector2(0,0),Vector2(0,1),Vector2(1,1),Vector2(0,0),Vector2(1,1),Vector2(1,0)]:
   var angle=(float(i)+point.x)*TAU/256.0
   var ring_radius=lerpf(1.25,2.14,point.y)
   tool.set_normal(Vector3.UP)
   tool.set_uv(Vector2((float(i)+point.x)/256.0,point.y))
   tool.add_vertex(Vector3(cos(angle)*ring_radius,0,sin(angle)*ring_radius))
 var node=MeshInstance3D.new();node.mesh=tool.commit()
 var mat=ShaderMaterial.new();mat.shader=preload("res://shaders/planet_rings.gdshader")
 mat.set_shader_parameter("tint",color.lerp(Color("dfc8a5"),0.45))
 node.material_override=mat;node.rotation_degrees=Vector3(8,0,16);node.scale=Vector3.ONE*radius
 root.add_child(node)
 root.set_meta("rings",node)

func _orbit_position(body: Dictionary,angle: float,offset=0.0) -> Vector3:
 var radius: float=body.orbit_radius
 var e: float=body.get("eccentricity",0.0)
 var plane=Vector3((radius+offset)*cos(angle)-radius*e,0,(radius+offset)*sqrt(1.0-e*e)*sin(angle))
 return plane.rotated(Vector3.RIGHT,body.orbit_tilt)

func _move_system(dt: float):
 if solar_root==null or game.system_data.is_empty(): return
 for i in solar_planets.size():
  var body=game.system_data.planets[i]
  var angle=body.orbit_phase+clock*body.orbit_speed
  var position=_orbit_position(body,angle)
  solar_positions[i]=position
  solar_planets[i].position=position
  solar_planets[i].rotate_y(dt*0.008)
 for moon in solar_moons:
  var angle=clock*0.035+moon.phase
  moon.node.position=Vector3(cos(angle)*moon.orbit,sin(angle)*moon.orbit*0.12,sin(angle)*moon.orbit)

func build_planet(data: Dictionary):
 _clear_fragments()
 if planet_root!=null: planet_root.free()
 planet_root=Node3D.new();add_child(planet_root)
 current_planet=data
 harrow=data.get("terrain_revision",0)==5
 arrival_pitch=ARRIVAL_PITCH
 planet_radius=data.radius
 shattered=data.get("fractured",false)
 var terrain_folder="terrain-v4" if data.get("terrain_revision",0)>=4 else "terrain-v3"
 if harrow: terrain_folder="terrain-harrow"
 var save_folder="user://"+terrain_folder+"/"+str(game.run_seed)
 if game.tests_running or game.capture_path!="": save_folder=""
 volume=Volume.new();planet_root.add_child(volume)
 volume.setup(data,save_folder)
 spherical_surface=null
 cut_patch=null
 cut_site=Vector3.ZERO
 cut_version=-1
 cut_replays=-1
 cut_retry_at=0.0
 RenderingServer.global_shader_parameter_set("harrow_cut",Vector4.ZERO)
 if harrow:
  var shared_material=Volume.harrow_material(false)
  shared_material.set_shader_parameter("local_surface",true)
  spherical_surface=SphericalSurface.new()
  planet_root.add_child(spherical_surface)
  spherical_surface.setup(volume.geology,shared_material)
  cut_patch=MeshInstance3D.new()
  cut_patch.material_override=Volume.harrow_material(true)
  cut_patch.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
  planet_root.add_child(cut_patch)
  cut_patch.hide()
 var air=ShaderMaterial.new();air.shader=load("res://shaders/atmosphere.gdshader")
 air.set_shader_parameter("tint",data.air_color)
 air.set_shader_parameter("density",data.get("atmosphere_density",0.65))
 local_atmosphere=ball(planet_root,Vector3.ZERO,_atmosphere_radius(data),air,64)
 surface_normal=data.features[0].normal
 var ground=volume.geology.surface(surface_normal)
 var tangent=Vector3.FORWARD.slide(surface_normal).normalized()
 var landing_up=(ground-tangent*660.0).normalized()
 surface_start=volume.geology.surface(landing_up)+landing_up*124.0
 var arrival_up=landing_up
 if harrow:
  arrival_pitch=-0.86
  arrival_up=(ground-tangent*9400.0).normalized()
 elif game.planet_index>=0 and game.planet_index<solar_positions.size():
  var index=game.planet_index
  var toward_star=-solar_positions[index].normalized()
  arrival_up=(landing_up+toward_star*0.51).normalized()
  var orbital_mesh=solar_planets[index].get_meta("surface_mesh")
  orbital_mesh.mesh=_planet_mesh(volume.geology,224,112)
 var arrival_ground=volume.geology.surface(arrival_up).length()
 var extra=1700.0 if harrow else 8200.0
 arrival_position=arrival_up*maxf(_atmosphere_radius(data)+extra,arrival_ground+9000.0)
 ship_position=surface_start
 ship_normal=landing_up
 ship_velocity=Vector3.ZERO
 cruise_boost=false;boost_active=false
 flight_yaw=0.0
 flight_pitch=asin((ground-(surface_start+landing_up*30.0)).normalized().dot(landing_up))
 volume.focus("pilot",volume.geology.surface(arrival_up),true,volume.terrain.view_distance)
 _build_settlements()
 city_nodes.clear()
 lander_nodes.clear()
 bore_nodes.clear()
 fracture_level=0
 target_hit={}
 for region in data.get("fractures",[]):
  fracture_level=maxi(fracture_level,int(region.get("level",0)))
 _cockpit_pose()

func _build_settlements():
 buildings.clear()
 industrial_traffic.clear()
 var rng=RandomNumberGenerator.new();rng.seed=current_planet.seed+71
 for feature in current_planet.features:
  if feature.kind!="city": continue
  if harrow:
   _build_works(feature)
   continue
  var city=Node3D.new();planet_root.add_child(city)
  city.position=feature.position
  city.quaternion=Quaternion(Vector3.UP,feature.normal)
  var steel=material(Color("8a8981"),false,0.35)
  var dark=material(Color("313b42"),false,0.3)
  var windows=material(Color("baaa75"),true)
  for row in range(-3,4):
   for column in range(-3,4):
    if row==0 or column==0 or rng.randf()<0.15: continue
    var building_id=str(row)+":"+str(column)
    var height=rng.randf_range(8,42) if feature.type=="City" else rng.randf_range(4,14)
    if building_id in feature.get("destroyed_buildings",[]): continue
    var building=Node3D.new();city.add_child(building)
    var radial=(feature.position+city.basis*Vector3(row*19,0,column*19)).normalized()
    var base=volume.geology.surface(radial)
    building.global_position=base
    var pos=Vector3(0,height*0.5,0)
    box(building,pos,Vector3(13,height,12),steel)
    box(building,pos+Vector3(0,height*0.5+0.3,0),Vector3(10,0.7,9),dark)
    for floor_index in range(1,int(height/4)):
     box(building,Vector3(0,floor_index*4,6.05),Vector3(9,0.6,0.1),windows)
    buildings.append({"node":building,"base":base,"height":height,"feature":feature,"fallen":false,"id":building_id})
  var beacon=ball(city,Vector3(0,4,0),1.2,windows,8)

func _build_works(feature: Dictionary):
 var site: Vector3=feature.position
 var east=feature.normal.cross(Vector3.BACK).normalized()
 var south=east.cross(feature.normal).normalized()
 var district=Node3D.new()
 planet_root.add_child(district)
 for module in [
  [PROCESSOR,Vector2(0,-70),0.0,34.0,Vector2(58,72)],
  [PROCESSOR,Vector2(-108,-32),0.4,34.0,Vector2(58,72)],
  [HABITAT,Vector2(75,-12),0.0,20.0,Vector2(28,39)],
  [HABITAT,Vector2(119,8),0.0,20.0,Vector2(28,39)],
  [HABITAT,Vector2(68,45),0.12,20.0,Vector2(28,39)],
  [HABITAT,Vector2(117,65),0.12,20.0,Vector2(28,39)],
  [HABITAT,Vector2(-73,46),-0.19,20.0,Vector2(28,39)],
  [PAD,Vector2(-15,95),0.0,2.0,Vector2(57,57)],
  [PAD,Vector2(-92,118),0.0,2.0,Vector2(57,57)]
 ]:
  var offset: Vector2=module[1]
  var building_id="works-%d-%d"%[int(offset.x),int(offset.y)]
  if building_id in feature.get("destroyed_buildings",[]): continue
  var normal=(site+east*offset.x+south*offset.y).normalized()
  var base=volume.geology.surface(normal)
  var building=module[0].instantiate()
  district.add_child(building)
  building.position=base+normal*(2.3 if module[0]==PAD else -0.72)
  building.quaternion=Quaternion(Vector3.UP,normal)
  building.rotate_object_local(Vector3.UP,module[2])
  buildings.append({"node":building,"base":base,"height":module[3],"footprint":module[4],
   "feature":feature,"fallen":false,"id":building_id})
  if module[0]==PAD:
   var courier=LANDER.instantiate()
   building.add_child(courier)
   courier.position=Vector3(0,1.2,0)
   industrial_traffic.append(courier)

func _traffic_step():
 for i in industrial_traffic.size():
  var craft=industrial_traffic[i]
  if not is_instance_valid(craft): continue
  var phase=fposmod(clock*0.072+float(i)*0.52,1.0)
  var lift=smoothstep(0.16,0.44,phase)*(1.0-smoothstep(0.55,0.91,phase))
  craft.position=Vector3(sin(phase*TAU)*60.0*lift,1.2+lift*84.0,-sin(phase*TAU)*91.0*lift)
  craft.rotation.y=lift*PI*0.42

func settlement_damage(center: Vector3,radius: float):
 for building in buildings:
  var footprint: Vector2=building.get("footprint",Vector2(13,12))
  if building.fallen or building.base.distance_to(center)>radius+footprint.length()*0.5: continue
  if volume.geology.density(building.base+building.base.normalized()*0.5)<0.5: continue
  building.fallen=true
  if not building.feature.has("destroyed_buildings"): building.feature.destroyed_buildings=[]
  building.feature.destroyed_buildings.append(building.id)
  var body=RigidBody3D.new();planet_root.add_child(body)
  body.global_transform=building.node.global_transform
  building.node.reparent(body);building.node.transform=Transform3D.IDENTITY
  var collider=CollisionShape3D.new();var shape=BoxShape3D.new()
  shape.size=Vector3(footprint.x,building.height,footprint.y);collider.shape=shape;collider.position.y=building.height*0.5;body.add_child(collider)
  body.gravity_scale=0.0
  body.linear_velocity=-building.base.normalized()*3.0
  body.angular_velocity=Vector3(0.1,0.04,0.16)
  var casualties=minf(building.feature.population,building.feature.population*0.035)
  building.feature.population-=casualties
  current_planet.population=maxf(0,current_planet.population-casualties)

func begin_approach(index: int):
 approach_time=0.0
 approach_start=camera.position
 solar_target=index
 ship.visible=true
 # Shift the system into the planet frame while the voxel globe streams.
 solar_root.position=-solar_positions[index]
 if harrow: use_local_planet(index)
 camera.position=approach_start-solar_positions[index]
 approach_start=camera.position
 ship.position=_approach_origin()
 ship.look_at(Vector3.ZERO,Vector3.FORWARD)

func _approach_origin() -> Vector3:
 if harrow:
  return (arrival_position.normalized()+Vector3.BACK*0.21).normalized()*(planet_radius+69000.0)
 return surface_normal*(planet_radius*2.6)

func _approach_step(dt: float):
 approach_time+=dt
 var t=clampf(approach_time/12.0,0,1)
 var cruise=smoothstep(0.16,1.0,t)
 var start=_approach_origin()
 var end=arrival_position
 ship_position=start.lerp(end,cruise)
 ship.position=ship_position
 var forward=(end-ship_position).normalized()
 if forward.length_squared()<0.1: forward=Vector3.FORWARD
 var up=Vector3.FORWARD if abs(forward.dot(surface_normal))>0.95 else surface_normal
 ship.basis=Basis.looking_at(forward,up)
 var camera_side=lerpf(-271.0,-94.0,smoothstep(0.19,0.87,t))
 var chase=ship_position-forward*361.0+Vector3.RIGHT*camera_side+up*146
 if t<0.22:
  var blend=smoothstep(0.0,0.22,t)
  camera.position=approach_start.lerp(chase,blend)
  camera.look_at(ship_position,up)
 elif t<0.87:
  camera.position=chase
  camera.look_at(ship_position+forward*44.0,up)
 else:
  var blend=smoothstep(0.87,1.0,t)
  flight_pitch=arrival_pitch
  var basis=_flight_basis()
  camera.position=chase.lerp(end+end.normalized()*30.0,blend)
  camera.quaternion=camera.quaternion.slerp(basis.get_rotation_quaternion(),blend*0.12+0.06)
 if t>=0.57: use_local_planet(solar_target)
 if t>=1.0:
  game.mode="ENCOUNTER"
  ship_position=arrival_position
  flight_pitch=arrival_pitch
  ship.visible=false
  Input.mouse_mode=Input.MOUSE_MODE_CAPTURED
  _cockpit_pose()

func _flight_basis() -> Basis:
 var up=ship_position.normalized()
 var north=Vector3.FORWARD.slide(up).normalized()
 if north.length_squared()<0.1: north=Vector3.RIGHT.slide(up).normalized()
 var flat=north.rotated(up,flight_yaw)
 var right=flat.cross(up).normalized()
 var forward=flat.rotated(right,flight_pitch)
 return Basis.looking_at(forward,up)

func _cockpit_pose():
 camera.position=ship_position+ship_position.normalized()*30.0
 camera.basis=_flight_basis()

func steer(relative: Vector2):
 steer_input+=relative*0.00145

func _flight_step(dt: float):
 var up=ship_position.normalized()
 ship_normal=up
 var amount=1.0-exp(-dt*10.0)
 var movement=steer_input*amount
 steer_input-=movement
 flight_yaw-=movement.x
 flight_pitch=clampf(flight_pitch-movement.y,-1.35,1.35)
 var thrust=Vector2(float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A)),float(Input.is_physical_key_pressed(KEY_W))-float(Input.is_physical_key_pressed(KEY_S)))
 var lift=float(Input.is_physical_key_pressed(KEY_E))-float(Input.is_physical_key_pressed(KEY_Q))
 var precision=Input.is_key_pressed(KEY_SHIFT)
 var brake=Input.is_physical_key_pressed(KEY_X)
 if brake or thrust.y<0: cruise_boost=false
 var boost=not brake and not precision and (Input.is_key_pressed(KEY_CTRL) or cruise_boost)
 if cruise_boost and boost and thrust.y==0: thrust.y=1.0
 _propulsion(dt,thrust,lift,precision,boost,brake)
 _cockpit_pose()
 var target_fov=39.0 if Input.is_key_pressed(KEY_Z) else 70.0
 camera.fov=lerpf(camera.fov,target_fov,dt*7)
 aim_clock-=dt
 if aim_clock<=0:
  aim_clock=0.09
  target_hit=volume.raycast(camera.position,-camera.basis.z)
 scan_wave=maxf(0,scan_wave-dt*0.33)

func _propulsion(dt: float,thrust: Vector2,lift: float,precision: bool,boost: bool,brake: bool):
 var up=ship_position.normalized()
 var basis=_flight_basis()
 var normal_speed=(34.0 if harrow else NORMAL_SPEED)*pow(1.3,mini(10,int(game.levels.get("thruster",0))))
 boost_active=boost and thrust.length_squared()>0.0 and not brake
 if brake:
  ship_velocity*=exp(-dt*8.0)
 elif boost_active:
  # Look direction gives heading; cruise stays tangent to the planet.
  var heading=(-basis.z*thrust.y+basis.x*thrust.x).slide(up).normalized()
  var target_speed=normal_speed*BOOST_MULTIPLIER
  var altitude=volume.geology.base_sdf(ship_position)
  if harrow: target_speed=lerpf(minf(135.0,normal_speed*4.0),minf(560.0,target_speed),smoothstep(450.0,2600.0,altitude))
  var approach=smoothstep(330.0,2400.0,altitude)
  var aim=(-basis.z*thrust.y+basis.x*thrust.x).normalized()
  var vertical_fraction=aim.dot(up)*approach
  var climb=lift*80.0+target_speed*vertical_fraction
  var horizontal_speed=target_speed*sqrt(maxf(0.0,1.0-vertical_fraction*vertical_fraction))
  for seconds in [0.45,1.0,1.8]:
   var ahead=ship_position+heading*horizontal_speed*seconds
   var floor_radius=volume.geology.surface(ahead.normalized()).length()+100.0
   climb=maxf(climb,(floor_radius-ship_position.length())/seconds)
  # Start climbing before the ridge; slow only for unusually steep walls.
  var speed_factor=clampf(210.0/maxf(210.0,climb),0.28,1.0)
  var tangent_velocity=ship_velocity.slide(up).move_toward(heading*horizontal_speed*speed_factor,dt*185.0)
  var vertical=move_toward(ship_velocity.dot(up),clampf(climb,-maxf(80.0,target_speed*approach),maxf(210.0,target_speed*approach)),dt*280.0)
  ship_velocity=tangent_velocity+up*vertical
 else:
  var direction=-basis.z*thrust.y+basis.x*thrust.x+up*lift
  var speed=normal_speed*(0.325 if precision else 1.0)
  if direction.length_squared()>0:
   var acceleration=125.0 if ship_velocity.length()>normal_speed*1.2 else 14.0
   ship_velocity=ship_velocity.move_toward(direction.normalized()*speed,dt*acceleration)
  else: ship_velocity*=exp(-dt*(1.65 if ship_velocity.length()>normal_speed*1.2 else 0.65))
  if orbit_assist and lift==0.0: ship_velocity-=up*ship_velocity.dot(up)*(1.0-exp(-dt*1.1))
 # Sweep the flight in short steps even when cruise upgrades increase speed.
 var steps=clampi(int(ceil(ship_velocity.length()*dt/12.0)),1,32)
 for i in steps:
  var next=ship_position+ship_velocity*(dt/steps)
  var radial=next.normalized()
  var clearance=volume.geology.base_sdf(next)
  if clearance<MIN_CLEARANCE:
   next+=radial*(MIN_CLEARANCE-clearance)
   var downward=minf(ship_velocity.dot(radial),0.0)
   ship_velocity=(ship_velocity-radial*downward)*0.88
  ship_position=next

func scan():
 if volume==null: return
 scan_wave=1.0
 var count=0
 for feature in current_planet.features:
  if feature.position.distance_to(ship_position)<(3200.0 if harrow else 1800.0):
   feature.scanned=true
   count+=1
 game.notify("Survey resolved "+str(count)+" nearby deposits / settlements")
 game.sound("select")

func place_waypoint() -> bool:
 if target_hit.is_empty(): game.notify("Aim at terrain within 2.2 km");return false
 var hit=target_hit.position
 var kind="mineral"
 var name="Unsurveyed ground"
 var feature_type="Regolith / rock"
 var nearest=volume.geology.nearest_deposit(hit)
 if nearest!=null and nearest.surface.distance_to(hit)<(36.0 if harrow else 160.0):
  name=nearest.name;feature_type=Geology.MATERIALS[nearest.material]+" seam"
  if harrow: feature_type+=" · %.0f m cover"%nearest.cover
 for feature in current_planet.features:
  if feature.kind=="city" and feature.position.distance_to(hit)<feature.radius:
   kind="city";name=feature.name;feature_type=feature.type
 var waypoint={"position":hit,"normal":target_hit.normal,"label":name,"type":feature_type,"kind":kind,"revealed":true,"extracted":0.0,"reserve":0.0,"order":0,"direction":(-camera.basis.z).normalized(),"materials":[0.0,0.0,0.0,0.0],"status":"Ready"}
 if harrow and kind=="mineral" and name!="Unsurveyed ground": waypoint.order=1
 current_planet.hotspots.append(waypoint)
 game.selected=current_planet.hotspots.size()-1
 return true

func site_position(index: int) -> Vector3:
 return current_planet.hotspots[index].position

func site_visible(index: int) -> bool:
 var p=site_position(index)
 return p.distance_to(ship_position)<2500 and not camera.is_position_behind(p)

func site_screen(index: int) -> Vector2:
 return camera.unproject_position(site_position(index))

func spawn_missile():
 var root=Node3D.new();add_child(root)
 root.position=ship_position-camera.basis.z*650+camera.basis.x*local_rng.randf_range(-260,260)+Vector3.UP*100
 box(root,Vector3.ZERO,Vector3(1.4,1.4,6),material(Color("a55943"),false,0.5))
 ball(root,Vector3.ZERO,1.1,material(Color("f8c382"),true),8)
 combat.append({"node":root,"type":"missile","velocity":(ship_position-root.position).normalized()*115.0,"health":1,"life":15.0,"age":0.0})

func spawn_fighter():
 if combat.size()>12: return
 var root=_build_ship();add_child(root);root.scale=Vector3.ONE*1.7
 root.position=ship_position-camera.basis.z*450+camera.basis.x*200
 combat.append({"node":root,"type":"fighter","velocity":Vector3.ZERO,"health":4,"life":40.0,"age":0.0,"phase":local_rng.randf()*TAU,"fire":3.0})

func _combat_step(dt: float):
 var expired=[]
 for entity in combat:
  entity.life-=dt;entity.age+=dt
  if entity.type=="missile":
   var desired=(ship_position-entity.node.position).normalized()*115
   entity.velocity=entity.velocity.lerp(desired,dt*0.18)
   entity.node.position+=entity.velocity*dt
   entity.node.look_at(entity.node.position+entity.velocity)
   if entity.node.position.distance_to(ship_position)<16: game.damage(8.0);entity.life=0
  else:
   var angle=entity.age*0.28+entity.phase
   var destination=ship_position+camera.basis.x*cos(angle)*360-camera.basis.z*300+ship_normal*(80+sin(angle)*65)
   entity.node.position=entity.node.position.lerp(destination,dt*0.5)
   entity.node.look_at(ship_position,ship_normal)
   entity.fire-=dt
   if entity.fire<=0:
    entity.fire=11.0;beam(entity.node.position,ship_position,Color("df9978"),0.18,0.6);game.damage(3)
  if entity.life<=0: expired.append(entity)
 for entity in expired: entity.node.queue_free();combat.erase(entity)
 turret_timer-=dt
 var gunners=game.available("gunners")
 if turret_timer<=0 and gunners>0 and combat.size()>0:
  turret_timer=maxf(0.5,4.5/(1+game.levels.get("turret",0))*20.0/maxf(5,gunners))
  var target=combat[0]
  beam(ship_position,target.node.position,Color("83c6bc"),0.12,0.35)
  target.health-=1
  if target.health<=0: destroy_entity(target)
 if game.police_arrived and police.size()>0 and fmod(clock,0.12)<dt:
  beam(police[local_rng.randi_range(0,police.size()-1)].position,ship_position,Color("e48162"),0.12,1.2)
  hit_flash=0.15

func fire_at(screen_position: Vector2):
 var center=get_viewport().get_visible_rect().size*0.5
 var target=null;var nearest=65.0
 for entity in combat:
  if camera.is_position_behind(entity.node.position): continue
  var distance=camera.unproject_position(entity.node.position).distance_to(center)
  if distance<nearest: target=entity;nearest=distance
 var destination=camera.position-camera.basis.z*1800
 if target!=null: destination=target.node.position;target.health-=1
 beam(camera.position+camera.basis.x*8-camera.basis.y*4,destination,Color("dce6d8"),0.08,0.25)
 if target!=null and target.health<=0: destroy_entity(target)

func spawn_police():
 for i in 6:
  var root=_build_ship();add_child(root);root.scale=Vector3.ONE*26.0
  var angle=float(i)*TAU/6
  root.position=ship_position+camera.basis.x*cos(angle)*1400-camera.basis.z*1800+ship_normal*(400+sin(angle)*450)
  root.look_at(ship_position,ship_normal);police.append(root)

func launch_effect(site: int,count: int,returning: bool):
 if game.tests_running: return
 var start=ship_position-camera.basis.x*40
 var destination=site_position(site)+current_planet.hotspots[site].normal*3
 if returning:
  var swap=start;start=destination;destination=swap
 for i in mini(5,maxi(1,int(count/7))):
  var rocket=LANDER.instantiate()
  add_child(rocket)
  rocket.position=start
  var offset=camera.basis.x*(i-2)*4.0
  effects.append({"node":rocket,"kind":"rocket","from":start+offset,"to":destination+offset*0.25,"time":game.travel_duration(),"max":game.travel_duration(),"arc":ship_normal*20})

func excavation_effect(position: Vector3,radius: float):
 var up=position.normalized()
 for i in (12 if harrow else 5):
  var chip=box(self,position,Vector3.ONE*local_rng.randf_range(0.24,0.69),material(current_planet.ground_color.lightened(0.16)))
  var offset=Vector3(local_rng.randfn(),local_rng.randfn(),local_rng.randfn())*radius*2
  effects.append({"node":chip,"kind":"rocket","from":position,"to":position+offset+up*2,"time":1.1,"max":1.1,"arc":up*radius*2.0})

func _lander_step():
 var active={}
 for op in game.operations:
  active[op.site]=true
  if not lander_nodes.has(op.site):
   var lander=LANDER.instantiate()
   planet_root.add_child(lander)
   var site=site_position(op.site)
   var up=site.normalized()
   var offset=Vector3(0.87,0,0.48).slide(up).normalized()
   var placement=volume.geology.surface((site+offset*10.4).normalized())
   lander.position=placement+up*0.38
   lander.basis=Basis.looking_at(-offset,up)
   lander_nodes[op.site]=lander
  lander_nodes[op.site].visible=op.state=="working" or op.state=="complete"
  if harrow and op.crew.extractors>0 and not bore_nodes.has(op.site):
   var mount=Node3D.new()
   planet_root.add_child(mount)
   mount.position=site_position(op.site)
   mount.quaternion=Quaternion(Vector3.UP,mount.position.normalized())
   var bit=BORE.instantiate()
   mount.add_child(bit)
   bore_nodes[op.site]=mount
  if bore_nodes.has(op.site):
   var mount=bore_nodes[op.site]
   mount.visible=op.state=="working"
   var bit=mount.get_child(0)
   bit.position.y=0.8-1.45*smoothstep(0.0,2.0,op.cut_clock)
   if op.state=="working": bit.rotation.y=clock*9.0
 for key in lander_nodes.keys():
  if not active.has(key): lander_nodes[key].queue_free();lander_nodes.erase(key)
 for key in bore_nodes.keys():
  if not active.has(key): bore_nodes[key].queue_free();bore_nodes.erase(key)

func _clear_fragments():
 for part in fragment_nodes:
  if is_instance_valid(part.node): part.node.queue_free()
 fragment_nodes.clear()

func _fracture_parts(geo) -> Array:
 var parts=[]
 var source=_planet_mesh(geo,48,24)
 var arrays=source.surface_get_arrays(0)
 var vertices=arrays[Mesh.ARRAY_VERTEX];var indices=arrays[Mesh.ARRAY_INDEX]
 var buckets=[]
 for i in 48: buckets.append([])
 for tri in range(0,indices.size(),3):
  var a=vertices[indices[tri]];var b=vertices[indices[tri+1]];var c=vertices[indices[tri+2]]
  var center=(a+b+c)/3.0
  var normal=center.normalized()
  var longitude=atan2(normal.z,normal.x)+PI
  var latitude=asin(normal.y)+PI*0.5
  var sector=clampi(int(longitude/TAU*8),0,7)+clampi(int(latitude/PI*6),0,5)*8
  buckets[sector].append_array([a,b,c])
 for bucket in buckets:
  if bucket.is_empty(): continue
  var center=Vector3.ZERO
  for p in bucket: center+=p
  center/=bucket.size()
  var tool=SurfaceTool.new();tool.begin(Mesh.PRIMITIVE_TRIANGLES)
  for triangle in range(0,bucket.size(),3):
   var a=bucket[triangle]-center;var b=bucket[triangle+1]-center;var c=bucket[triangle+2]-center
   for p in [a,b,c]: tool.add_vertex(p)
   var inner=-center*0.65
   for p in [a,inner,b,b,inner,c,c,inner,a]: tool.add_vertex(p)
  tool.generate_normals()
  parts.append({"center":center,"mesh":tool.commit()})
 return parts

func shatter_planet():
 if shattered: return
 shattered=true;current_planet.fractured=true
 planet_root.visible=false
 fragment_clock=0
 for part in _fracture_parts(volume.geology):
  var piece=MeshInstance3D.new();piece.mesh=part.mesh;piece.material_override=material(current_planet.ground_color)
  add_child(piece);piece.position=part.center
  fragment_nodes.append({"node":piece,"velocity":part.center.normalized()*local_rng.randf_range(55,130),"spin":local_rng.randf_range(-0.04,0.04)})

func begin_warp():
 cruise_boost=false;boost_active=false
 clear_combat()
 Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
 warp_root.scale=Vector3.ONE
 warp_root.visible=true
 ship.visible=true

func end_warp():
 warp_root.visible=false
 ship.hide()

func _harrow_surface_step(mode: String,altitude: float,up: Vector3):
 var local_view=mode=="ENCOUNTER" or approach_time>=1.45
 if not shattered:
  var view=arrival_position if mode=="APPROACH" and approach_time<3.0 else camera.position
  spherical_surface.update_view(view)
 var spot=Vector3.ZERO
 var radius=32.0
 var nearest=1500.0
 var ground=volume.geology.surface(up)
 if mode=="ENCOUNTER" and altitude<1200.0 and not shattered:
  for waypoint in current_planet.hotspots:
   if not waypoint.has("head"): continue
   var distance=ground.distance_to(waypoint.position)
   if distance<nearest:
    nearest=distance
    spot=waypoint.position
    radius=clampf(waypoint.head.distance_to(spot)+9.0,32.0,58.0)
  volume.focus("pilot",spot if spot!=Vector3.ZERO else ground)
 if spot!=cut_site: cut_patch.hide()
 var version: int=current_planet.edits.size()
 var replays: int=volume.replay_queue.size()
 if spot!=Vector3.ZERO and (spot!=cut_site or version!=cut_version or replays!=cut_replays) and clock>=cut_retry_at:
  var snapshot=volume.mesh_excavation(spot,radius)
  cut_retry_at=clock+0.12
  if not snapshot.is_empty():
   cut_patch.mesh=snapshot.mesh
   cut_patch.position=snapshot.position
   cut_site=spot
   cut_radius=radius
   cut_version=version
   cut_replays=replays
 var active=spot!=Vector3.ZERO and spot==cut_site and cut_patch.mesh!=null
 var window=Vector4(spot.x,spot.y,spot.z,cut_radius) if active else Vector4.ZERO
 RenderingServer.global_shader_parameter_set("harrow_cut",window)
 cut_patch.visible=active
 spherical_surface.visible=local_view and not shattered
 if local_view and not shattered: planet_root.show()
 solar_planets[solar_target].get_meta("surface_mesh").visible=not local_view and not shattered

func step(dt: float):
 clock+=dt;hit_flash=maxf(0,hit_flash-dt);screen_shake=maxf(0,screen_shake-dt)
 var mode=game.mode
 var in_flight=mode=="ENCOUNTER" or mode=="APPROACH"
 cockpit.visible=mode=="ENCOUNTER"
 warp_root.visible=mode=="WARP"
 ship.visible=mode in ["APPROACH","WARP"]
 if planet_root!=null: planet_root.visible=in_flight and not shattered and (mode!="APPROACH" or approach_time>=(1.45 if harrow else 6.84))
 if solar_root!=null: solar_root.visible=mode in ["SYSTEM","TITLE","APPROACH","ENCOUNTER"]
 if mode in ["SYSTEM","TITLE"]:
  var slice=game.system_data.get("slice",false)
  camera.near=2400.0 if slice else 100.0
  camera.far=27000000.0 if slice else 3000000.0
  _move_system(dt)
  solar_root.position=Vector3.ZERO
  for i in solar_planets.size():
   var node=solar_planets[i]
   node.get_meta("surface_mesh").visible=not game.system_data.planets[i].fractured
   node.get_meta("air_shell").visible=true
  var radius=game.system_data.planets[-1].orbit_radius if not game.system_data.is_empty() else 500000.0
  var distance=radius*1.36*system_zoom
  camera.position=Vector3(sin(view_yaw)*cos(view_pitch),sin(view_pitch),cos(view_yaw)*cos(view_pitch))*distance
  camera.look_at(Vector3.ZERO)
  camera.fov=65.0
  sky_material.set_shader_parameter("air",0.0)
  environment.fog_enabled=false
 elif mode=="APPROACH":
  camera.near=10.0
  camera.far=14500000.0 if harrow else 1100000.0
  _approach_step(dt)
 elif mode=="ENCOUNTER":
  camera.near=0.80 if harrow else 0.15
  camera.far=780000.0 if harrow else 52000.0
  if dt>0 and not game.ui.pointer_over_panel(): _flight_step(dt)
  _combat_step(dt)
  _lander_step()
  _traffic_step()
 elif mode=="WARP":
  var pull=smoothstep(0.65,2.3,game.warp_time)
  ship.position=Vector3(-72,0,-238.0-pull*990.0)
  ship.rotation=Vector3(0.02,-0.14-pull*0.08,0.04)
  camera.near=1.0;camera.far=10000.0;camera.fov=53.0
  camera.position=Vector3(330-170.0*pull,104-45.0*pull,206)
  camera.look_at(Vector3(-49,3,-288.0-pull*410.0))
  warp_root.transform=camera.transform
  sky_material.set_shader_parameter("air",0.0)
  environment.fog_enabled=false
  for streak in warp_root.get_children():
   streak.position.z+=dt*(12+pull*210)
   if streak.position.z>1: streak.position.z=-170
 if solar_root!=null and solar_root.visible:
  if star_corona.global_position.distance_squared_to(camera.position)>1.0:
   star_corona.look_at(camera.position)
  for root in solar_planets:
   var surface_material=root.get_meta("surface_mesh").material_override
   var direction=(solar_root.global_position-root.global_position).normalized()
   if surface_material.shader==preload("res://shaders/harrow.gdshader"):
    surface_material.set_shader_parameter("orbital_sun",direction)
   else:
    surface_material.set_shader_parameter("star_position",solar_root.global_position)
   root.get_meta("air_shell").material_override.set_shader_parameter("star_position",solar_root.global_position)
   if root.has_meta("rings"):
    var ring=root.get_meta("rings")
    ring.material_override.set_shader_parameter("sun_direction",ring.global_basis.orthonormalized().inverse()*direction)
  for moon in solar_moons:
   moon.node.material_override.set_shader_parameter("star_position",solar_root.global_position)
 for line in orbit_lines: line.visible=mode in ["SYSTEM","TITLE"]
 if not in_flight and volume!=null: volume.terrain.hide()
 if in_flight and volume!=null:
  volume.tick(dt)
  var altitude=maxf(0,volume.geology.base_sdf(ship_position))
  var up=ship_position.normalized()
  if harrow: _harrow_surface_step(mode,altitude,up)
  elif mode=="ENCOUNTER" and not shattered:
   # Keep streaming near the ground at high altitude, then move the viewer
   # smoothly onto the ship for low-altitude flight.
   var ground=volume.geology.surface(up)
   var focus_height=altitude*(1.0-smoothstep(500.0,SURFACE_HANDOFF_ALTITUDE,altitude))
   volume.focus("pilot",ground+up*focus_height)
  var show_surface=mode=="ENCOUNTER" and not shattered and altitude<=SURFACE_HANDOFF_ALTITUDE
  if not harrow:
   if show_surface and not volume.terrain.visible: show_surface=volume.has_surface_coverage(up)
   volume.terrain.visible=show_surface
   if mode=="ENCOUNTER" and solar_target>=0 and solar_target<solar_planets.size():
    solar_planets[solar_target].get_meta("surface_mesh").visible=not shattered and not show_surface
  var air=clampf(1.0-altitude/(8200.0 if harrow else 6500.0),0,1)*current_planet.get("atmosphere_density",0.65)
  sky_material.set_shader_parameter("air",air)
  sky_material.set_shader_parameter("local_up",ship_position.normalized())
  sky_material.set_shader_parameter("air_color",current_planet.air_color)
  if solar_root!=null: sky_material.set_shader_parameter("sun_direction",solar_root.position.normalized())
  environment.fog_enabled=show_surface and air>0.02 and not harrow
  environment.fog_light_color=current_planet.air_color
  environment.fog_density=0.00013*air
 _effects_step(dt)
 for fragment in fragment_nodes:
  fragment.node.position+=fragment.velocity*dt;fragment.node.rotate_y(fragment.spin*dt)
 fragment_clock+=dt
